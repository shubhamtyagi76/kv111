/*
  # Create business inquiries table

  1. New Tables
    - `business_inquiries`
      - `id` (uuid, primary key)
      - `business_name` (text)
      - `business_idea` (text)
      - `niche` (text)
      - `industry` (text)
      - `service_type` (text)
      - `brand_tone` (text)
      - `primary_color` (text)
      - `secondary_color` (text)
      - `target_audience` (text)
      - `unique_value` (text)
      - `goals` (text array)
      - `contact_email` (text)
      - `contact_phone` (text, optional)
      - `budget` (text)
      - `timeline` (text)
      - `status` (text, default 'inquiry')
      - `website_generated` (boolean, default false)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `business_inquiries` table
    - Add policy for service role to manage all data
    - Add policy for authenticated users to read their own data
*/

CREATE TABLE IF NOT EXISTS business_inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name text NOT NULL,
  business_idea text NOT NULL,
  niche text NOT NULL,
  industry text NOT NULL,
  service_type text NOT NULL CHECK (service_type IN ('product', 'service', 'both')),
  brand_tone text NOT NULL CHECK (brand_tone IN ('professional', 'friendly', 'bold', 'minimalist')),
  primary_color text NOT NULL DEFAULT '#0db2e9',
  secondary_color text NOT NULL DEFAULT '#b2fefa',
  target_audience text NOT NULL,
  unique_value text,
  goals text[] NOT NULL DEFAULT '{}',
  contact_email text NOT NULL,
  contact_phone text,
  budget text NOT NULL,
  timeline text NOT NULL,
  status text NOT NULL DEFAULT 'inquiry' CHECK (status IN ('inquiry', 'in_progress', 'completed', 'cancelled')),
  website_generated boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE business_inquiries ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Service role can manage all business inquiries"
  ON business_inquiries
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can read business inquiries"
  ON business_inquiries
  FOR SELECT
  TO authenticated
  USING (true);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_business_inquiries_updated_at
    BEFORE UPDATE ON business_inquiries
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_business_inquiries_email ON business_inquiries(contact_email);
CREATE INDEX IF NOT EXISTS idx_business_inquiries_status ON business_inquiries(status);
CREATE INDEX IF NOT EXISTS idx_business_inquiries_created_at ON business_inquiries(created_at);
CREATE INDEX IF NOT EXISTS idx_business_inquiries_industry ON business_inquiries(industry);