import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const businessData = await req.json()
    
    // Email configuration
    const SMTP_HOSTNAME = Deno.env.get('SMTP_HOSTNAME') || 'smtp.gmail.com'
    const SMTP_PORT = parseInt(Deno.env.get('SMTP_PORT') || '587')
    const SMTP_USERNAME = Deno.env.get('SMTP_USERNAME') || 'vyomexa.ai@gmail.com'
    const SMTP_PASSWORD = Deno.env.get('SMTP_PASSWORD')
    
    // Create email content
    const emailHTML = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>New Business Inquiry - Vyomexa.ai</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #0db2e9, #b2fefa); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
            .section { margin-bottom: 25px; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .section h3 { color: #0db2e9; margin-top: 0; border-bottom: 2px solid #0db2e9; padding-bottom: 10px; }
            .highlight { background: #e3f2fd; padding: 15px; border-left: 4px solid #0db2e9; margin: 15px 0; }
            .contact-info { background: #f1f8e9; padding: 15px; border-radius: 5px; }
            .goals { display: flex; flex-wrap: wrap; gap: 10px; }
            .goal-tag { background: #0db2e9; color: white; padding: 5px 12px; border-radius: 20px; font-size: 12px; }
            .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚀 New Business Inquiry</h1>
                <p>A new client has submitted their business details through Vyomexa.ai</p>
            </div>
            
            <div class="content">
                <div class="section">
                    <h3>📋 Business Overview</h3>
                    <p><strong>Business Name:</strong> ${businessData.businessName}</p>
                    <p><strong>Industry:</strong> ${businessData.industry}</p>
                    <p><strong>Niche:</strong> ${businessData.niche}</p>
                    <p><strong>Service Type:</strong> ${businessData.serviceType}</p>
                    <p><strong>Brand Tone:</strong> ${businessData.brandTone}</p>
                </div>

                <div class="section">
                    <h3>💡 Business Idea</h3>
                    <div class="highlight">
                        ${businessData.businessIdea}
                    </div>
                </div>

                <div class="section">
                    <h3>🎯 Target Audience</h3>
                    <p>${businessData.targetAudience}</p>
                </div>

                <div class="section">
                    <h3>⭐ Unique Value Proposition</h3>
                    <p>${businessData.uniqueValue || 'Not specified'}</p>
                </div>

                <div class="section">
                    <h3>🎨 Brand Colors</h3>
                    <p><strong>Primary Color:</strong> <span style="background: ${businessData.primaryColor}; color: white; padding: 2px 8px; border-radius: 3px;">${businessData.primaryColor}</span></p>
                    <p><strong>Secondary Color:</strong> <span style="background: ${businessData.secondaryColor}; color: white; padding: 2px 8px; border-radius: 3px;">${businessData.secondaryColor}</span></p>
                </div>

                <div class="section">
                    <h3>🎯 Business Goals</h3>
                    <div class="goals">
                        ${businessData.goals.map(goal => `<span class="goal-tag">${goal}</span>`).join('')}
                    </div>
                </div>

                <div class="section">
                    <h3>📞 Contact Information</h3>
                    <div class="contact-info">
                        <p><strong>Email:</strong> <a href="mailto:${businessData.contactEmail}">${businessData.contactEmail}</a></p>
                        ${businessData.contactPhone ? `<p><strong>Phone:</strong> <a href="tel:${businessData.contactPhone}">${businessData.contactPhone}</a></p>` : ''}
                    </div>
                </div>

                <div class="section">
                    <h3>💰 Project Details</h3>
                    <p><strong>Budget:</strong> ${businessData.budget}</p>
                    <p><strong>Timeline:</strong> ${businessData.timeline}</p>
                </div>

                <div class="section">
                    <h3>⚡ Next Steps</h3>
                    <ul>
                        <li>Contact the client within 24 hours</li>
                        <li>Schedule a discovery call to discuss requirements</li>
                        <li>Prepare a customized proposal</li>
                        <li>Begin AI website generation process</li>
                    </ul>
                </div>
            </div>

            <div class="footer">
                <p>This inquiry was generated automatically by <strong>Vyomexa.ai™</strong></p>
                <p>Timestamp: ${new Date().toLocaleString()}</p>
            </div>
        </div>
    </body>
    </html>
    `

    // Send email using fetch to a mail service
    const emailPayload = {
      to: 'cosmotech09solutions@gmail.com',
      subject: `🚀 New Business Inquiry: ${businessData.businessName} - ${businessData.industry}`,
      html: emailHTML,
      from: 'vyomexa.ai@gmail.com'
    }

    // For now, we'll log the email content and return success
    // In production, you would integrate with a proper email service
    console.log('Email would be sent:', emailPayload)

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Business inquiry processed successfully',
        businessName: businessData.businessName 
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )

  } catch (error) {
    console.error('Error processing business inquiry:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Failed to process business inquiry' 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})