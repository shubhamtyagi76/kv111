import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const data = await req.json()
    
    // Create website generation notification email
    const emailHTML = `
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>Website Generated - Vyomexa.ai</title>
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #0db2e9, #b2fefa); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
            .section { margin-bottom: 25px; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .section h3 { color: #0db2e9; margin-top: 0; border-bottom: 2px solid #0db2e9; padding-bottom: 10px; }
            .success-badge { background: #4caf50; color: white; padding: 10px 20px; border-radius: 25px; display: inline-block; margin: 10px 0; }
            .website-preview { background: #e8f5e8; padding: 20px; border-radius: 8px; border-left: 4px solid #4caf50; }
            .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🎉 Website Successfully Generated!</h1>
                <p>AI has completed building the website for ${data.businessName}</p>
            </div>
            
            <div class="content">
                <div class="section">
                    <h3>✅ Generation Complete</h3>
                    <div class="success-badge">Website Ready for Review</div>
                    <p><strong>Business:</strong> ${data.businessName}</p>
                    <p><strong>Industry:</strong> ${data.industry}</p>
                    <p><strong>Generated At:</strong> ${new Date(data.generatedAt).toLocaleString()}</p>
                </div>

                <div class="section">
                    <h3>🌐 Website Features Generated</h3>
                    <ul>
                        <li>✅ Responsive homepage with hero section</li>
                        <li>✅ About us page with business story</li>
                        <li>✅ Services section tailored to ${data.niche}</li>
                        <li>✅ Contact form and information</li>
                        <li>✅ Mobile-optimized design</li>
                        <li>✅ SEO-friendly structure</li>
                        <li>✅ Brand colors: ${data.primaryColor} & ${data.secondaryColor}</li>
                        <li>✅ ${data.brandTone} brand tone implementation</li>
                    </ul>
                </div>

                <div class="section">
                    <h3>📧 Client Information</h3>
                    <p><strong>Email:</strong> ${data.contactEmail}</p>
                    ${data.contactPhone ? `<p><strong>Phone:</strong> ${data.contactPhone}</p>` : ''}
                    <p><strong>Budget:</strong> ${data.budget}</p>
                    <p><strong>Timeline:</strong> ${data.timeline}</p>
                </div>

                <div class="section">
                    <h3>🚀 Next Steps</h3>
                    <ul>
                        <li>Review the generated website</li>
                        <li>Contact client for feedback and revisions</li>
                        <li>Prepare for website deployment</li>
                        <li>Begin marketing strategy development</li>
                        <li>Schedule follow-up call</li>
                    </ul>
                </div>

                <div class="website-preview">
                    <h4>🎨 Website Preview Available</h4>
                    <p>The client can now preview their website in the Vyomexa.ai platform. The website includes all requested features and is ready for final review and deployment.</p>
                </div>
            </div>

            <div class="footer">
                <p>This notification was generated automatically by <strong>Vyomexa.ai™</strong></p>
                <p>Website Generation System</p>
            </div>
        </div>
    </body>
    </html>
    `

    // Log the notification (in production, send actual email)
    console.log('Website generation notification:', {
      to: 'cosmotech09solutions@gmail.com',
      subject: `🎉 Website Generated: ${data.businessName}`,
      html: emailHTML
    })

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Website generation notification sent',
        businessName: data.businessName 
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )

  } catch (error) {
    console.error('Error sending website notification:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Failed to send notification' 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})