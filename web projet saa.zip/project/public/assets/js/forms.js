// Enhanced Form Handling for InfinityFree

// Update the form handlers to use PHP endpoints
function handleContactForm(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = {
        name: formData.get('name'),
        email: formData.get('email'),
        message: formData.get('message')
    };

    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="loading"></span> Sending...';
    submitBtn.disabled = true;

    // Send to PHP endpoint
    fetch('contact.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            // Reset form
            e.target.reset();
            showNotification('Message sent successfully! We\'ll get back to you soon.', 'success');
        } else {
            showNotification('Failed to send message. Please try again.', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    })
    .finally(() => {
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

function handleBusinessForm(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const data = {
        businessName: formData.get('businessName'),
        businessIdea: formData.get('businessIdea'),
        industry: formData.get('industry'),
        budget: formData.get('budget'),
        email: formData.get('email'),
        phone: formData.get('phone')
    };

    // Show loading state
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="loading"></span> Processing...';
    submitBtn.disabled = true;

    // Send to PHP endpoint
    fetch('business-inquiry.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            // Close business modal and show success
            closeBusinessModal();
            showSuccessModal();
        } else {
            showNotification('Failed to submit inquiry. Please try again.', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    })
    .finally(() => {
        // Reset button
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
}

// Enhanced form validation
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;

    inputs.forEach(input => {
        const value = input.value.trim();
        
        // Remove previous error states
        input.classList.remove('form-error');
        const existingError = input.parentNode.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }

        // Validate based on input type
        if (!value) {
            showFieldError(input, 'This field is required');
            isValid = false;
        } else if (input.type === 'email' && !validateEmail(value)) {
            showFieldError(input, 'Please enter a valid email address');
            isValid = false;
        } else if (input.type === 'tel' && value && !validatePhone(value)) {
            showFieldError(input, 'Please enter a valid phone number');
            isValid = false;
        } else {
            input.classList.add('form-success');
        }
    });

    return isValid;
}

function showFieldError(input, message) {
    input.classList.add('form-error');
    
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    
    input.parentNode.appendChild(errorDiv);
}

// Real-time validation
function initRealTimeValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                validateSingleField(input);
            });
            
            input.addEventListener('input', () => {
                // Clear error state on input
                input.classList.remove('form-error');
                const existingError = input.parentNode.querySelector('.error-message');
                if (existingError) {
                    existingError.remove();
                }
            });
        });
    });
}

function validateSingleField(input) {
    const value = input.value.trim();
    
    // Remove previous states
    input.classList.remove('form-error', 'form-success');
    const existingError = input.parentNode.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }

    if (input.hasAttribute('required') && !value) {
        showFieldError(input, 'This field is required');
        return false;
    }

    if (input.type === 'email' && value && !validateEmail(value)) {
        showFieldError(input, 'Please enter a valid email address');
        return false;
    }

    if (input.type === 'tel' && value && !validatePhone(value)) {
        showFieldError(input, 'Please enter a valid phone number');
        return false;
    }

    if (value) {
        input.classList.add('form-success');
    }

    return true;
}

// Initialize real-time validation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initRealTimeValidation();
});

// Character counter for textareas
function initCharacterCounters() {
    const textareas = document.querySelectorAll('textarea');
    
    textareas.forEach(textarea => {
        const maxLength = textarea.getAttribute('maxlength');
        if (maxLength) {
            const counter = document.createElement('div');
            counter.className = 'character-counter text-sm text-white/60 mt-1';
            counter.textContent = `0 / ${maxLength}`;
            
            textarea.parentNode.appendChild(counter);
            
            textarea.addEventListener('input', () => {
                const currentLength = textarea.value.length;
                counter.textContent = `${currentLength} / ${maxLength}`;
                
                if (currentLength > maxLength * 0.9) {
                    counter.classList.add('text-yellow-400');
                } else {
                    counter.classList.remove('text-yellow-400');
                }
            });
        }
    });
}

// Auto-resize textareas
function initAutoResizeTextareas() {
    const textareas = document.querySelectorAll('textarea');
    
    textareas.forEach(textarea => {
        textarea.addEventListener('input', () => {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        });
    });
}

// Initialize additional features
document.addEventListener('DOMContentLoaded', () => {
    initCharacterCounters();
    initAutoResizeTextareas();
});