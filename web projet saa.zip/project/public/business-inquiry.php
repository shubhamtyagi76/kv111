<?php
// Business Inquiry Handler for InfinityFree
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get POST data
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required_fields = ['businessName', 'businessIdea', 'industry', 'budget', 'email'];
foreach ($required_fields as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Field '$field' is required"]);
        exit;
    }
}

// Sanitize input
$businessName = filter_var($input['businessName'], FILTER_SANITIZE_STRING);
$businessIdea = filter_var($input['businessIdea'], FILTER_SANITIZE_STRING);
$industry = filter_var($input['industry'], FILTER_SANITIZE_STRING);
$budget = filter_var($input['budget'], FILTER_SANITIZE_STRING);
$email = filter_var($input['email'], FILTER_SANITIZE_EMAIL);
$phone = isset($input['phone']) ? filter_var($input['phone'], FILTER_SANITIZE_STRING) : '';

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

// Email configuration
$to = 'cosmotech09solutions@gmail.com'; // Replace with your email
$subject = '🚀 New Business Inquiry: ' . $businessName . ' - ' . $industry;
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: noreply@" . $_SERVER['HTTP_HOST'] . "\r\n";
$headers .= "Reply-To: " . $email . "\r\n";

// Email body
$email_body = "
<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>New Business Inquiry - Vyomexa.ai</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #0db2e9, #b2fefa); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }
        .section { margin-bottom: 25px; padding: 20px; background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .section h3 { color: #0db2e9; margin-top: 0; border-bottom: 2px solid #0db2e9; padding-bottom: 10px; }
        .highlight { background: #e3f2fd; padding: 15px; border-left: 4px solid #0db2e9; margin: 15px 0; }
        .contact-info { background: #f1f8e9; padding: 15px; border-radius: 5px; }
        .footer { text-align: center; margin-top: 30px; padding: 20px; color: #666; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h1>🚀 New Business Inquiry</h1>
            <p>A new client has submitted their business details through Vyomexa.ai</p>
        </div>
        
        <div class='content'>
            <div class='section'>
                <h3>📋 Business Overview</h3>
                <p><strong>Business Name:</strong> " . htmlspecialchars($businessName) . "</p>
                <p><strong>Industry:</strong> " . htmlspecialchars($industry) . "</p>
                <p><strong>Budget Range:</strong> " . htmlspecialchars($budget) . "</p>
            </div>

            <div class='section'>
                <h3>💡 Business Idea</h3>
                <div class='highlight'>
                    " . nl2br(htmlspecialchars($businessIdea)) . "
                </div>
            </div>

            <div class='section'>
                <h3>📞 Contact Information</h3>
                <div class='contact-info'>
                    <p><strong>Email:</strong> <a href='mailto:" . htmlspecialchars($email) . "'>" . htmlspecialchars($email) . "</a></p>";
                    
if (!empty($phone)) {
    $email_body .= "<p><strong>Phone:</strong> <a href='tel:" . htmlspecialchars($phone) . "'>" . htmlspecialchars($phone) . "</a></p>";
}

$email_body .= "
                </div>
            </div>

            <div class='section'>
                <h3>⚡ Next Steps</h3>
                <ul>
                    <li>Contact the client within 24 hours</li>
                    <li>Schedule a discovery call to discuss requirements</li>
                    <li>Prepare a customized proposal</li>
                    <li>Begin AI website generation process</li>
                </ul>
            </div>
        </div>

        <div class='footer'>
            <p>This inquiry was generated automatically by <strong>Vyomexa.ai™</strong></p>
            <p>Timestamp: " . date('Y-m-d H:i:s') . "</p>
        </div>
    </div>
</body>
</html>
";

// Send email
if (mail($to, $subject, $email_body, $headers)) {
    // Save to database/file (optional)
    $inquiry_data = [
        'timestamp' => date('Y-m-d H:i:s'),
        'businessName' => $businessName,
        'businessIdea' => $businessIdea,
        'industry' => $industry,
        'budget' => $budget,
        'email' => $email,
        'phone' => $phone,
        'ip' => $_SERVER['REMOTE_ADDR']
    ];
    
    // Save to JSON file
    $inquiries_file = 'business_inquiries.json';
    $inquiries = [];
    
    if (file_exists($inquiries_file)) {
        $inquiries = json_decode(file_get_contents($inquiries_file), true) ?: [];
    }
    
    $inquiries[] = $inquiry_data;
    file_put_contents($inquiries_file, json_encode($inquiries, JSON_PRETTY_PRINT));
    
    echo json_encode([
        'success' => true, 
        'message' => 'Business inquiry submitted successfully',
        'businessName' => $businessName
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to submit inquiry']);
}
?>