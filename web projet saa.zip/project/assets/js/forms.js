// Enhanced Form Handling for Vyomexa.ai

// Form validation utilities
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\+]?[1-9][\d]{0,15}$/;
    return re.test(phone.replace(/\s/g, ''));
}

function validateRequired(value) {
    return value && value.trim().length > 0;
}

// Real-time form validation
function initRealTimeValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                validateField(input);
            });
            
            input.addEventListener('input', () => {
                clearFieldError(input);
            });
        });
    });
}

function validateField(input) {
    const value = input.value.trim();
    const isRequired = input.hasAttribute('required');
    
    clearFieldError(input);
    
    // Required field validation
    if (isRequired && !validateRequired(value)) {
        showFieldError(input, 'This field is required');
        return false;
    }
    
    // Email validation
    if (input.type === 'email' && value && !validateEmail(value)) {
        showFieldError(input, 'Please enter a valid email address');
        return false;
    }
    
    // Phone validation
    if (input.type === 'tel' && value && !validatePhone(value)) {
        showFieldError(input, 'Please enter a valid phone number');
        return false;
    }
    
    // Minimum length validation
    if (input.hasAttribute('minlength')) {
        const minLength = parseInt(input.getAttribute('minlength'));
        if (value.length < minLength) {
            showFieldError(input, `Minimum ${minLength} characters required`);
            return false;
        }
    }
    
    // Success state
    if (value) {
        input.classList.add('form-success');
        input.classList.remove('form-error');
    }
    
    return true;
}

function showFieldError(input, message) {
    input.classList.add('form-error');
    input.classList.remove('form-success');
    
    // Remove existing error message
    const existingError = input.parentNode.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
    
    // Add new error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    
    input.parentNode.appendChild(errorDiv);
}

function clearFieldError(input) {
    input.classList.remove('form-error', 'form-success');
    
    const existingError = input.parentNode.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }
}

// Form submission with validation
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!validateField(input)) {
            isValid = false;
        }
    });
    
    return isValid;
}

// Enhanced contact form handler
function handleContactFormSubmission(formData) {
    return new Promise((resolve, reject) => {
        // Simulate API call
        setTimeout(() => {
            // Mock success/failure
            if (Math.random() > 0.1) { // 90% success rate
                resolve({
                    success: true,
                    message: 'Thank you for your message! We\'ll get back to you within 24 hours.'
                });
            } else {
                reject({
                    success: false,
                    message: 'Sorry, there was an error sending your message. Please try again.'
                });
            }
        }, 2000);
    });
}

// Enhanced business inquiry handler
function handleBusinessInquirySubmission(formData) {
    return new Promise((resolve, reject) => {
        // Validate business-specific fields
        if (!formData.businessName || formData.businessName.length < 2) {
            reject({
                success: false,
                message: 'Please enter a valid business name'
            });
            return;
        }
        
        if (!formData.businessIdea || formData.businessIdea.length < 20) {
            reject({
                success: false,
                message: 'Please provide more details about your business idea'
            });
            return;
        }
        
        // Simulate API call
        setTimeout(() => {
            resolve({
                success: true,
                message: 'Your business inquiry has been submitted successfully! Our AI team will analyze your requirements and contact you within 24 hours.',
                data: {
                    inquiryId: 'INQ-' + Date.now(),
                    estimatedResponse: '24 hours',
                    nextSteps: [
                        'AI analysis of your business requirements',
                        'Custom strategy development',
                        'Initial consultation call',
                        'Project proposal and timeline'
                    ]
                }
            });
        }, 3000);
    });
}

// Auto-save form data to localStorage
function initAutoSave() {
    const forms = document.querySelectorAll('form[data-autosave]');
    
    forms.forEach(form => {
        const formId = form.id || 'form-' + Date.now();
        const storageKey = 'vyomexa-form-' + formId;
        
        // Load saved data
        const savedData = localStorage.getItem(storageKey);
        if (savedData) {
            try {
                const data = JSON.parse(savedData);
                Object.keys(data).forEach(key => {
                    const input = form.querySelector(`[name="${key}"]`);
                    if (input && input.type !== 'password') {
                        input.value = data[key];
                    }
                });
            } catch (e) {
                console.warn('Failed to load saved form data:', e);
            }
        }
        
        // Save data on input
        form.addEventListener('input', debounce(() => {
            const formData = new FormData(form);
            const data = {};
            
            for (let [key, value] of formData.entries()) {
                if (key !== 'password') { // Don't save passwords
                    data[key] = value;
                }
            }
            
            localStorage.setItem(storageKey, JSON.stringify(data));
        }, 1000));
        
        // Clear saved data on successful submission
        form.addEventListener('submit', () => {
            setTimeout(() => {
                localStorage.removeItem(storageKey);
            }, 5000); // Clear after 5 seconds to allow for error handling
        });
    });
}

// Character counter for textareas
function initCharacterCounters() {
    const textareas = document.querySelectorAll('textarea[maxlength]');
    
    textareas.forEach(textarea => {
        const maxLength = parseInt(textarea.getAttribute('maxlength'));
        
        // Create counter element
        const counter = document.createElement('div');
        counter.className = 'character-counter text-sm text-white/60 mt-1 text-right';
        counter.textContent = `0 / ${maxLength}`;
        
        textarea.parentNode.appendChild(counter);
        
        // Update counter on input
        textarea.addEventListener('input', () => {
            const currentLength = textarea.value.length;
            counter.textContent = `${currentLength} / ${maxLength}`;
            
            // Change color based on usage
            if (currentLength > maxLength * 0.9) {
                counter.classList.add('text-yellow-400');
                counter.classList.remove('text-white/60', 'text-red-400');
            } else if (currentLength === maxLength) {
                counter.classList.add('text-red-400');
                counter.classList.remove('text-white/60', 'text-yellow-400');
            } else {
                counter.classList.add('text-white/60');
                counter.classList.remove('text-yellow-400', 'text-red-400');
            }
        });
    });
}

// Auto-resize textareas
function initAutoResizeTextareas() {
    const textareas = document.querySelectorAll('textarea[data-autoresize]');
    
    textareas.forEach(textarea => {
        // Set initial height
        textarea.style.height = 'auto';
        textarea.style.height = textarea.scrollHeight + 'px';
        
        textarea.addEventListener('input', () => {
            textarea.style.height = 'auto';
            textarea.style.height = textarea.scrollHeight + 'px';
        });
    });
}

// Form progress indicator
function initFormProgress() {
    const forms = document.querySelectorAll('form[data-progress]');
    
    forms.forEach(form => {
        const requiredFields = form.querySelectorAll('input[required], textarea[required], select[required]');
        const totalFields = requiredFields.length;
        
        if (totalFields === 0) return;
        
        // Create progress bar
        const progressContainer = document.createElement('div');
        progressContainer.className = 'form-progress mb-4';
        progressContainer.innerHTML = `
            <div class="flex justify-between items-center mb-2">
                <span class="text-sm text-white/70">Form Progress</span>
                <span class="text-sm text-white/70"><span class="progress-count">0</span>/${totalFields}</span>
            </div>
            <div class="w-full bg-white/10 rounded-full h-2">
                <div class="progress-bar bg-gradient-to-r from-primary to-secondary h-2 rounded-full transition-all duration-300" style="width: 0%"></div>
            </div>
        `;
        
        form.insertBefore(progressContainer, form.firstChild);
        
        const progressBar = progressContainer.querySelector('.progress-bar');
        const progressCount = progressContainer.querySelector('.progress-count');
        
        // Update progress on input
        function updateProgress() {
            let completedFields = 0;
            
            requiredFields.forEach(field => {
                if (field.value.trim()) {
                    completedFields++;
                }
            });
            
            const percentage = (completedFields / totalFields) * 100;
            progressBar.style.width = percentage + '%';
            progressCount.textContent = completedFields;
        }
        
        requiredFields.forEach(field => {
            field.addEventListener('input', updateProgress);
            field.addEventListener('change', updateProgress);
        });
        
        // Initial update
        updateProgress();
    });
}

// Multi-step form handler
function initMultiStepForms() {
    const multiStepForms = document.querySelectorAll('form[data-multistep]');
    
    multiStepForms.forEach(form => {
        const steps = form.querySelectorAll('[data-step]');
        let currentStep = 0;
        
        // Hide all steps except first
        steps.forEach((step, index) => {
            if (index !== 0) {
                step.style.display = 'none';
            }
        });
        
        // Add navigation buttons
        const navigation = document.createElement('div');
        navigation.className = 'form-navigation flex justify-between mt-6';
        navigation.innerHTML = `
            <button type="button" class="prev-btn bg-white/10 hover:bg-white/20 text-white px-6 py-2 rounded-lg transition-all" style="display: none;">
                <i class="fas fa-arrow-left mr-2"></i>Previous
            </button>
            <button type="button" class="next-btn bg-gradient-to-r from-primary to-secondary text-black px-6 py-2 rounded-lg font-medium">
                Next<i class="fas fa-arrow-right ml-2"></i>
            </button>
        `;
        
        form.appendChild(navigation);
        
        const prevBtn = navigation.querySelector('.prev-btn');
        const nextBtn = navigation.querySelector('.next-btn');
        
        // Navigation handlers
        nextBtn.addEventListener('click', () => {
            if (currentStep < steps.length - 1) {
                // Validate current step
                const currentStepElement = steps[currentStep];
                const stepInputs = currentStepElement.querySelectorAll('input[required], textarea[required], select[required]');
                let stepValid = true;
                
                stepInputs.forEach(input => {
                    if (!validateField(input)) {
                        stepValid = false;
                    }
                });
                
                if (stepValid) {
                    steps[currentStep].style.display = 'none';
                    currentStep++;
                    steps[currentStep].style.display = 'block';
                    
                    // Update navigation
                    prevBtn.style.display = currentStep > 0 ? 'block' : 'none';
                    nextBtn.textContent = currentStep === steps.length - 1 ? 'Submit' : 'Next';
                    nextBtn.type = currentStep === steps.length - 1 ? 'submit' : 'button';
                }
            }
        });
        
        prevBtn.addEventListener('click', () => {
            if (currentStep > 0) {
                steps[currentStep].style.display = 'none';
                currentStep--;
                steps[currentStep].style.display = 'block';
                
                // Update navigation
                prevBtn.style.display = currentStep > 0 ? 'block' : 'none';
                nextBtn.textContent = 'Next';
                nextBtn.type = 'button';
            }
        });
    });
}

// Initialize all form enhancements
document.addEventListener('DOMContentLoaded', () => {
    initRealTimeValidation();
    initAutoSave();
    initCharacterCounters();
    initAutoResizeTextareas();
    initFormProgress();
    initMultiStepForms();
});

// Utility function for debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}