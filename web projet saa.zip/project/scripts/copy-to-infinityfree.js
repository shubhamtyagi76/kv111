const fs = require('fs');
const path = require('path');

// Create infinityfree-ready folder
const infinityFreeDir = path.join(__dirname, '..', 'infinityfree-ready');

// Ensure directory exists
if (!fs.existsSync(infinityFreeDir)) {
    fs.mkdirSync(infinityFreeDir, { recursive: true });
}

// Copy files from public folder
const publicDir = path.join(__dirname, '..', 'public');
const filesToCopy = [
    'index.html',
    'contact.php',
    'business-inquiry.php',
    '.htaccess',
    '404.html',
    '500.html',
    'robots.txt',
    'sitemap.xml'
];

// Copy individual files
filesToCopy.forEach(file => {
    const srcPath = path.join(publicDir, file);
    const destPath = path.join(infinityFreeDir, file);
    
    if (fs.existsSync(srcPath)) {
        fs.copyFileSync(srcPath, destPath);
        console.log(`Copied: ${file}`);
    }
});

// Copy assets folder
const assetsDir = path.join(publicDir, 'assets');
const destAssetsDir = path.join(infinityFreeDir, 'assets');

if (fs.existsSync(assetsDir)) {
    fs.cpSync(assetsDir, destAssetsDir, { recursive: true });
    console.log('Copied: assets folder');
}

console.log('\n✅ InfinityFree-ready files copied to: infinityfree-ready/');
console.log('\n📁 Upload these files to your InfinityFree htdocs folder:');
console.log('   - All files in infinityfree-ready/ folder');
console.log('\n🔧 Remember to:');
console.log('   1. Update email addresses in PHP files');
console.log('   2. Replace "yourdomain.com" with your actual domain');
console.log('   3. Test contact forms after upload');