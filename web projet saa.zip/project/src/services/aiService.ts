import { MarketingStrategyInput, MarketingStrategy, MediaCreationInput, GeneratedContent, VoiceoverOptions } from '../types/marketing';

class AIService {
  private apiKey: string;
  private baseUrl: string;
  private mockMode: boolean;

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY || '';
    this.baseUrl = 'https://api.openai.com/v1';
    this.mockMode = !this.apiKey; // Use mock mode if no API key
  }

  // Phase 2 - Marketing Strategy Generation
  async generateMarketingStrategy(input: MarketingStrategyInput): Promise<MarketingStrategy> {
    if (this.mockMode) {
      return this.generateMockStrategy(input);
    }
    
    try {
      const prompt = this.buildStrategyPrompt(input);
      
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: 'You are an expert digital marketing strategist. Generate comprehensive, actionable marketing strategies in JSON format.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.7,
          max_tokens: 4000
        })
      });

      const data = await response.json();
      const strategyData = JSON.parse(data.choices[0].message.content);
      
      return {
        id: this.generateId(),
        businessId: input.industry,
        ...strategyData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error generating marketing strategy:', error);
      return this.generateMockStrategy(input);
    }
  }

  private generateMockStrategy(input: MarketingStrategyInput): MarketingStrategy {
    return {
      id: this.generateId(),
      businessId: input.industry,
      seo: {
        keywords: [
          `${input.industry.toLowerCase()} solutions`,
          `best ${input.industry.toLowerCase()} services`,
          `${input.industry.toLowerCase()} automation`,
          `AI ${input.industry.toLowerCase()}`,
          `${input.industry.toLowerCase()} consulting`
        ],
        blogs: [
          `Top 10 ${input.industry} Trends in 2025`,
          `How AI is Transforming ${input.industry}`,
          `Complete Guide to ${input.industry} Automation`,
          `${input.industry} Best Practices for Beginners`,
          `Future of ${input.industry}: What to Expect`
        ],
        backlinks: [
          'Guest posting on industry blogs',
          'Partner with complementary businesses',
          'Create shareable infographics',
          'Participate in industry forums'
        ],
        contentPillars: [
          'Educational Content',
          'Industry News & Trends',
          'Case Studies & Success Stories',
          'Behind-the-Scenes Content'
        ],
        monthlyTargets: {
          organicTraffic: Math.floor(input.monthlyBudget * 2),
          keywordRankings: Math.min(50, Math.floor(input.monthlyBudget / 100)),
          backlinksToAcquire: Math.min(20, Math.floor(input.monthlyBudget / 200))
        }
      },
      smm: {
        platforms: input.platforms,
        hooks: [
          "Before you scroll, here's something that will change your perspective...",
          "Most people don't know this secret about...",
          "Stop doing this if you want to succeed in...",
          "Here's what nobody tells you about...",
          "The biggest mistake I see people make is..."
        ],
        contentThemes: [
          'Educational Tips',
          'Behind the Scenes',
          'Customer Success Stories',
          'Industry Insights',
          'Quick Tutorials'
        ],
        postingFrequency: input.platforms.reduce((acc, platform) => {
          acc[platform] = platform === 'Instagram' ? 7 : platform === 'LinkedIn' ? 5 : 3;
          return acc;
        }, {} as Record<string, number>),
        calendar: {
          week1: ['Educational reel', 'Carousel post', 'Story series'],
          week2: ['Testimonial video', 'Poll', 'Behind-the-scenes'],
          week3: ['Tutorial content', 'User-generated content', 'Live session'],
          week4: ['Case study', 'Q&A session', 'Monthly recap']
        },
        hashtagStrategy: input.platforms.reduce((acc, platform) => {
          acc[platform] = [
            `#${input.industry.toLowerCase()}`,
            '#AI',
            '#automation',
            '#business',
            '#growth'
          ];
          return acc;
        }, {} as Record<string, string[]>)
      },
      ads: {
        budget: input.monthlyBudget,
        platforms: input.platforms.filter(p => ['Instagram', 'Facebook', 'Google', 'LinkedIn'].includes(p)),
        budgetSplit: {
          'Meta': 60,
          'Google': 30,
          'LinkedIn': 10
        },
        formats: ['Lead Generation', 'Video Ads', 'Carousel Ads', 'Story Ads'],
        targetingCriteria: {
          demographics: ['25-45 years', 'College educated', 'Urban areas'],
          interests: [`${input.industry} tools`, 'Business automation', 'AI technology'],
          behaviors: ['Tech early adopters', 'Business decision makers', 'Online shoppers']
        },
        campaignObjectives: input.businessGoals.slice(0, 3)
      },
      email: {
        leadMagnet: `Free ${input.industry} Automation Guide`,
        funnelStages: ['Awareness', 'Consideration', 'Decision', 'Retention'],
        emailSequence: [
          {
            subject: 'Welcome! Your free guide is here',
            content: 'Thank you for joining our community...',
            sendDay: 0
          },
          {
            subject: `The #1 mistake in ${input.industry}`,
            content: 'Most businesses make this critical error...',
            sendDay: 3
          },
          {
            subject: 'Case study: How we helped [Company] grow 300%',
            content: 'Here\'s exactly what we did...',
            sendDay: 7
          }
        ],
        segmentation: ['New subscribers', 'Engaged users', 'Trial users', 'Customers']
      },
      personas: [
        {
          id: 'persona1',
          name: 'Tech-Savvy Entrepreneur',
          age: '28-40',
          occupation: 'Business Owner',
          income: '$75k-$150k',
          painPoints: ['Time management', 'Scaling operations', 'Technology adoption'],
          goals: ['Automate processes', 'Increase efficiency', 'Grow revenue'],
          preferredChannels: ['LinkedIn', 'Email', 'YouTube'],
          buyingBehavior: 'Research-driven, values ROI',
          demographics: {
            location: 'Urban/Suburban',
            education: 'College+',
            familyStatus: 'Married with kids'
          }
        }
      ],
      calendar: {
        week1: {
          monday: [{ id: '1', type: 'post', platform: 'Instagram', title: 'Educational Reel', description: 'Quick tip about industry trends', status: 'planned' }],
          wednesday: [{ id: '2', type: 'blog', platform: 'Website', title: 'Weekly Blog Post', description: 'In-depth industry analysis', status: 'planned' }],
          friday: [{ id: '3', type: 'story', platform: 'Instagram', title: 'Behind the Scenes', description: 'Show company culture', status: 'planned' }]
        }
      },
      kpis: {
        reach: Math.floor(input.monthlyBudget * 5),
        engagement: Math.floor(input.monthlyBudget * 0.5),
        leads: Math.floor(input.monthlyBudget * 0.1),
        conversions: Math.floor(input.monthlyBudget * 0.02),
        roi: Math.min(500, Math.floor(input.monthlyBudget * 0.3))
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }
  private buildStrategyPrompt(input: MarketingStrategyInput): string {
    return `
    Generate a comprehensive digital marketing strategy for:
    
    Product/Service: ${input.productService}
    Target Audience: ${input.targetAudience}
    Platforms: ${input.platforms.join(', ')}
    Monthly Budget: $${input.monthlyBudget}
    Strategy Type: ${input.strategyType}
    Industry: ${input.industry}
    Business Goals: ${input.businessGoals.join(', ')}
    
    Return a JSON object with the following structure:
    {
      "seo": {
        "keywords": ["keyword1", "keyword2"],
        "blogs": ["blog title 1", "blog title 2"],
        "backlinks": ["strategy1", "strategy2"],
        "contentPillars": ["pillar1", "pillar2"],
        "monthlyTargets": {
          "organicTraffic": 5000,
          "keywordRankings": 20,
          "backlinksToAcquire": 10
        }
      },
      "smm": {
        "platforms": ["Instagram", "LinkedIn"],
        "hooks": ["hook1", "hook2"],
        "contentThemes": ["theme1", "theme2"],
        "postingFrequency": {"Instagram": 7, "LinkedIn": 3},
        "calendar": {
          "week1": ["educational reel", "carousel post"],
          "week2": ["testimonial video", "poll"]
        },
        "hashtagStrategy": {
          "Instagram": ["#tag1", "#tag2"],
          "LinkedIn": ["#tag3", "#tag4"]
        }
      },
      "ads": {
        "budget": ${input.monthlyBudget},
        "platforms": ["Meta", "Google"],
        "budgetSplit": {"Meta": 60, "Google": 40},
        "formats": ["Lead Generation", "Video Ads"],
        "targetingCriteria": {
          "demographics": ["25-45", "College Educated"],
          "interests": ["interest1", "interest2"],
          "behaviors": ["behavior1", "behavior2"]
        },
        "campaignObjectives": ["Lead Generation", "Brand Awareness"]
      },
      "email": {
        "leadMagnet": "Free Guide: ...",
        "funnelStages": ["Awareness", "Consideration", "Decision"],
        "emailSequence": [
          {"subject": "Welcome!", "content": "...", "sendDay": 0},
          {"subject": "Your Free Guide", "content": "...", "sendDay": 1}
        ],
        "segmentation": ["New Subscribers", "Engaged Users"]
      },
      "personas": [
        {
          "id": "persona1",
          "name": "Primary Customer",
          "age": "25-35",
          "occupation": "Professional",
          "income": "$50k-$75k",
          "painPoints": ["pain1", "pain2"],
          "goals": ["goal1", "goal2"],
          "preferredChannels": ["Instagram", "Email"],
          "buyingBehavior": "Research-driven",
          "demographics": {
            "location": "Urban",
            "education": "College",
            "familyStatus": "Single/Married"
          }
        }
      ],
      "kpis": {
        "reach": 10000,
        "engagement": 500,
        "leads": 100,
        "conversions": 20,
        "roi": 300
      }
    }
    
    Make it specific to the industry and target audience provided.
    `;
  }

  // Phase 3 - Content Generation
  async generateTextContent(input: MediaCreationInput): Promise<string> {
    if (this.mockMode) {
      return this.generateMockContent(input);
    }
    
    try {
      const prompt = this.buildContentPrompt(input);
      
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: `You are an expert content creator specializing in ${input.platform} content. Create engaging, platform-optimized content.`
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.8,
          max_tokens: 2000
        })
      });

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('Error generating text content:', error);
      return this.generateMockContent(input);
    }
  }

  private generateMockContent(input: MediaCreationInput): string {
    const contentTemplates = {
      post: `🚀 ${input.topic}

Here's what you need to know:

✅ Key insight #1 about ${input.topic}
✅ Key insight #2 that most people miss
✅ Key insight #3 for immediate results

💡 Pro tip: The secret to success in ${input.topic} is consistency and the right strategy.

${input.cta}

#AI #automation #business #growth #${input.platform.toLowerCase()}`,

      blog: `# The Complete Guide to ${input.topic}

## Introduction

In today's fast-paced digital world, understanding ${input.topic} is crucial for business success. This comprehensive guide will walk you through everything you need to know.

## Why ${input.topic} Matters

${input.topic} has become increasingly important because:
- It drives business growth
- It improves efficiency
- It provides competitive advantage

## Key Strategies

### 1. Foundation Building
Start with a solid foundation by understanding your goals and requirements.

### 2. Implementation
Follow best practices for implementation to ensure success.

### 3. Optimization
Continuously optimize your approach based on data and feedback.

## Conclusion

${input.topic} is not just a trend—it's the future. By implementing these strategies, you'll be well-positioned for success.

${input.cta}`,

      reel: `🎬 REEL SCRIPT: ${input.topic}

HOOK (0-3s):
"Stop scrolling! Here's something that will change how you think about ${input.topic}..."

CONTENT (3-20s):
- Quick tip #1
- Quick tip #2  
- Quick tip #3

CTA (20-30s):
"${input.cta}"

VISUAL NOTES:
- Use dynamic transitions
- Include text overlays for key points
- End with strong call-to-action screen`,

      ad: `🎯 AD COPY: ${input.topic}

HEADLINE: Transform Your Business with ${input.topic}

DESCRIPTION:
Discover how leading companies are using ${input.topic} to:
✅ Increase efficiency by 300%
✅ Reduce costs by 50%
✅ Scale operations effortlessly

Don't get left behind. Join thousands of successful businesses already using our solution.

${input.cta}

Limited time offer - Act now!`,

      story: `📱 STORY CONTENT: ${input.topic}

Slide 1: Eye-catching visual with "${input.topic}" text overlay
Slide 2: "Did you know?" fact about the topic
Slide 3: Quick tip or insight
Slide 4: Behind-the-scenes content
Slide 5: Call-to-action with swipe-up link

Interactive elements:
- Poll: "Have you tried this?"
- Question sticker: "What's your biggest challenge?"
- Quiz: Test knowledge about the topic`,

      video: `🎥 VIDEO SCRIPT: ${input.topic}

INTRO (0-10s):
"Welcome back! Today we're diving deep into ${input.topic}..."

MAIN CONTENT (10s-80% of video):
1. Problem identification
2. Solution explanation
3. Step-by-step walkthrough
4. Real-world examples

CONCLUSION (Last 20%):
- Recap key points
- ${input.cta}
- Subscribe/follow reminder

PRODUCTION NOTES:
- Use engaging visuals
- Include screen recordings if applicable
- Add background music
- Include captions for accessibility`
    };

    return contentTemplates[input.type] || contentTemplates.post;
  }
  private buildContentPrompt(input: MediaCreationInput): string {
    return `
    Create ${input.type} content for ${input.platform} about: ${input.topic}
    
    Requirements:
    - Tone: ${input.tone}
    - Call to Action: ${input.cta}
    - Platform: ${input.platform}
    - Type: ${input.type}
    
    Brand Guidelines:
    - Style: ${input.branding.style}
    - Voice: ${input.branding.voiceGuidelines}
    
    ${input.type === 'blog' ? 'Create a full blog post with headings, subheadings, and SEO optimization.' : ''}
    ${input.type === 'post' ? 'Create an engaging social media post with relevant hashtags.' : ''}
    ${input.type === 'reel' ? 'Create a script for a short-form video with hook, content, and CTA.' : ''}
    ${input.type === 'ad' ? 'Create compelling ad copy with headline, description, and CTA.' : ''}
    
    Make it engaging, platform-appropriate, and aligned with the brand voice.
    `;
  }

  async generateImage(prompt: string, dimensions: string = '1024x1024'): Promise<string> {
    if (this.mockMode) {
      // Return a placeholder image URL
      return `https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=${dimensions.split('x')[0]}&h=${dimensions.split('x')[1]}&fit=crop`;
    }
    
    try {
      const response = await fetch(`${this.baseUrl}/images/generations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'dall-e-3',
          prompt: prompt,
          size: dimensions,
          quality: 'hd',
          n: 1
        })
      });

      const data = await response.json();
      return data.data[0].url;
    } catch (error) {
      console.error('Error generating image:', error);
      return `https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=${dimensions.split('x')[0]}&h=${dimensions.split('x')[1]}&fit=crop`;
    }
  }

  // Simulate video generation (would integrate with RunwayML/Lumen5)
  async generateVideo(script: string, duration: number, style: string): Promise<string> {
    // This would integrate with actual video generation APIs
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(`https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4`);
      }, 5000);
    });
  }

  // Simulate voiceover generation (would integrate with ElevenLabs)
  async generateVoiceover(text: string, options: VoiceoverOptions): Promise<string> {
    // This would integrate with actual TTS APIs
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(`https://www.soundjay.com/misc/sounds/bell-ringing-05.wav`);
      }, 3000);
    });
  }

  // AI Recommendations
  async generateRecommendations(campaignData: any): Promise<any[]> {
    if (this.mockMode) {
      return this.generateMockRecommendations(campaignData);
    }
    
    try {
      const prompt = `
      Analyze this campaign performance data and provide actionable recommendations:
      ${JSON.stringify(campaignData)}
      
      Provide recommendations in the following categories:
      1. Content optimization
      2. Timing optimization
      3. Budget allocation
      4. Audience targeting
      5. Platform strategy
      
      Return as JSON array with structure:
      [
        {
          "type": "optimization",
          "title": "Recommendation Title",
          "description": "Detailed description",
          "impact": "high|medium|low",
          "effort": "easy|moderate|complex",
          "expectedImprovement": "Expected improvement description",
          "actionItems": ["action1", "action2"]
        }
      ]
      `;

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: 'You are an expert marketing analyst. Provide data-driven recommendations.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 2000
        })
      });

      const data = await response.json();
      return JSON.parse(data.choices[0].message.content);
    } catch (error) {
      console.error('Error generating recommendations:', error);
      return this.generateMockRecommendations(campaignData);
    }
  }

  private generateMockRecommendations(campaignData: any): any[] {
    return [
      {
        type: 'content',
        title: 'Optimize Video Content Performance',
        description: 'Your video content is performing 40% better than static posts. Consider increasing video content ratio.',
        impact: 'high',
        effort: 'moderate',
        expectedImprovement: 'Increase engagement by 25-35%',
        actionItems: [
          'Create 2-3 more video posts per week',
          'Focus on educational and behind-the-scenes content',
          'Use trending audio and hashtags',
          'Optimize video length for each platform'
        ]
      },
      {
        type: 'timing',
        title: 'Adjust Posting Schedule',
        description: 'Your audience is most active between 6-8 PM on weekdays. Current posting times miss peak engagement.',
        impact: 'medium',
        effort: 'easy',
        expectedImprovement: 'Increase reach by 15-20%',
        actionItems: [
          'Schedule posts for 6-8 PM weekdays',
          'Test weekend morning slots (9-11 AM)',
          'Use scheduling tools for consistency',
          'Monitor engagement patterns monthly'
        ]
      },
      {
        type: 'budget',
        title: 'Reallocate Ad Spend',
        description: 'Instagram ads are generating 3x better ROI than Facebook. Consider budget reallocation.',
        impact: 'high',
        effort: 'easy',
        expectedImprovement: 'Improve ROI by 40-50%',
        actionItems: [
          'Shift 30% of Facebook budget to Instagram',
          'Test Instagram Reels ads',
          'Pause underperforming Facebook campaigns',
          'Monitor performance for 2 weeks before full shift'
        ]
      }
    ];
  }
  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }
}

export const aiService = new AIService();