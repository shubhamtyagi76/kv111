import { Campaign, CampaignSchedule, CampaignPerformance, AnalyticsData } from '../types/marketing';

class CampaignService {
  private campaigns: Campaign[] = [];
  private mockData: boolean = true; // Enable mock data for demo

  // Campaign Management
  async createCampaign(campaignData: Partial<Campaign>): Promise<Campaign> {
    const campaign: Campaign = {
      id: this.generateId(),
      name: campaignData.name || 'Untitled Campaign',
      type: campaignData.type || 'post',
      platforms: campaignData.platforms || [],
      content: campaignData.content || [],
      schedule: campaignData.schedule || {
        type: 'immediate',
        startDate: new Date().toISOString(),
        times: ['09:00'],
        timezone: 'UTC'
      },
      targeting: campaignData.targeting || {
        demographics: {
          age: '18-65',
          gender: 'all',
          location: [],
          interests: []
        },
        behaviors: [],
        customAudiences: []
      },
      budget: campaignData.budget,
      status: 'draft',
      performance: {
        reach: 0,
        impressions: 0,
        clicks: 0,
        ctr: 0,
        cpc: 0,
        cpl: 0,
        conversions: 0,
        roi: 0,
        engagement: {
          likes: 0,
          comments: 0,
          shares: 0,
          saves: 0
        }
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    this.campaigns.push(campaign);
    
    // Add some mock campaigns for demo
    if (this.campaigns.length === 1 && this.mockData) {
      this.addMockCampaigns();
    }
    
    return campaign;
  }

  private addMockCampaigns(): void {
    const mockCampaigns: Campaign[] = [
      {
        id: 'mock-1',
        name: 'AI Business Solutions - Lead Gen',
        type: 'ad',
        platforms: ['Instagram', 'Facebook'],
        content: [],
        schedule: {
          type: 'scheduled',
          startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          times: ['09:00', '15:00', '19:00'],
          timezone: 'UTC'
        },
        targeting: {
          demographics: {
            age: '25-45',
            gender: 'all',
            location: ['United States', 'Canada'],
            interests: ['Business', 'Technology', 'AI']
          },
          behaviors: ['Tech early adopters'],
          customAudiences: ['Website visitors']
        },
        budget: 5000,
        status: 'active',
        performance: {
          reach: 12500,
          impressions: 45000,
          clicks: 1350,
          ctr: 3.0,
          cpc: 3.70,
          cpl: 25.00,
          conversions: 54,
          roi: 280,
          engagement: {
            likes: 890,
            comments: 156,
            shares: 78,
            saves: 234
          }
        },
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'mock-2',
        name: 'Content Marketing - Educational Series',
        type: 'post',
        platforms: ['LinkedIn', 'Instagram'],
        content: [],
        schedule: {
          type: 'recurring',
          startDate: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
          times: ['10:00'],
          timezone: 'UTC'
        },
        targeting: {
          demographics: {
            age: '28-50',
            gender: 'all',
            location: ['Global'],
            interests: ['Marketing', 'Business Growth']
          },
          behaviors: ['Business decision makers'],
          customAudiences: ['Email subscribers']
        },
        budget: 2000,
        status: 'active',
        performance: {
          reach: 8900,
          impressions: 23400,
          clicks: 567,
          ctr: 2.4,
          cpc: 0,
          cpl: 0,
          conversions: 23,
          roi: 150,
          engagement: {
            likes: 1245,
            comments: 89,
            shares: 156,
            saves: 78
          }
        },
        createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: 'mock-3',
        name: 'Product Launch - Video Campaign',
        type: 'story',
        platforms: ['Instagram', 'YouTube'],
        content: [],
        schedule: {
          type: 'scheduled',
          startDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
          times: ['12:00', '18:00'],
          timezone: 'UTC'
        },
        targeting: {
          demographics: {
            age: '22-40',
            gender: 'all',
            location: ['United States'],
            interests: ['Technology', 'Innovation']
          },
          behaviors: ['Early adopters'],
          customAudiences: ['Lookalike audience']
        },
        budget: 8000,
        status: 'scheduled',
        performance: {
          reach: 0,
          impressions: 0,
          clicks: 0,
          ctr: 0,
          cpc: 0,
          cpl: 0,
          conversions: 0,
          roi: 0,
          engagement: {
            likes: 0,
            comments: 0,
            shares: 0,
            saves: 0
          }
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    this.campaigns.push(...mockCampaigns);
  }
  async updateCampaign(id: string, updates: Partial<Campaign>): Promise<Campaign> {
    const index = this.campaigns.findIndex(c => c.id === id);
    if (index === -1) throw new Error('Campaign not found');

    this.campaigns[index] = {
      ...this.campaigns[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    return this.campaigns[index];
  }

  async deleteCampaign(id: string): Promise<void> {
    const index = this.campaigns.findIndex(c => c.id === id);
    if (index === -1) throw new Error('Campaign not found');
    
    this.campaigns.splice(index, 1);
  }

  async getCampaigns(): Promise<Campaign[]> {
    // Initialize with mock data if empty
    if (this.campaigns.length === 0 && this.mockData) {
      this.addMockCampaigns();
    }
    return this.campaigns;
  }

  async getCampaign(id: string): Promise<Campaign> {
    const campaign = this.campaigns.find(c => c.id === id);
    if (!campaign) throw new Error('Campaign not found');
    return campaign;
  }

  // Campaign Scheduling
  async scheduleCampaign(id: string, schedule: CampaignSchedule): Promise<void> {
    const campaign = await this.getCampaign(id);
    campaign.schedule = schedule;
    campaign.status = 'scheduled';
    campaign.updatedAt = new Date().toISOString();

    // In a real implementation, this would integrate with a job scheduler
    this.simulateScheduling(campaign);
  }

  private simulateScheduling(campaign: Campaign): void {
    console.log(`Campaign ${campaign.name} scheduled for ${campaign.schedule.startDate}`);
    
    // Simulate campaign execution
    if (campaign.schedule.type === 'immediate') {
      setTimeout(() => {
        this.executeCampaign(campaign.id);
      }, 1000);
    } else {
      const startTime = new Date(campaign.schedule.startDate).getTime();
      const now = Date.now();
      const delay = Math.max(0, startTime - now);
      
      setTimeout(() => {
        this.executeCampaign(campaign.id);
      }, delay);
    }
  }

  private async executeCampaign(id: string): Promise<void> {
    const campaign = await this.getCampaign(id);
    campaign.status = 'active';
    
    // Simulate publishing to platforms
    for (const platform of campaign.platforms) {
      await this.publishToPlatform(campaign, platform);
    }

    // Start performance tracking
    this.startPerformanceTracking(id);
  }

  private async publishToPlatform(campaign: Campaign, platform: string): Promise<void> {
    console.log(`Publishing campaign ${campaign.name} to ${platform}`);
    
    // This would integrate with actual platform APIs
    switch (platform.toLowerCase()) {
      case 'instagram':
        await this.publishToInstagram(campaign);
        break;
      case 'facebook':
        await this.publishToFacebook(campaign);
        break;
      case 'linkedin':
        await this.publishToLinkedIn(campaign);
        break;
      case 'youtube':
        await this.publishToYouTube(campaign);
        break;
      case 'google':
        await this.publishToGoogleAds(campaign);
        break;
      default:
        console.log(`Platform ${platform} not yet supported`);
    }
  }

  // Platform-specific publishing methods (would integrate with actual APIs)
  private async publishToInstagram(campaign: Campaign): Promise<void> {
    // Instagram Graph API integration
    console.log('Publishing to Instagram...');
  }

  private async publishToFacebook(campaign: Campaign): Promise<void> {
    // Facebook Graph API integration
    console.log('Publishing to Facebook...');
  }

  private async publishToLinkedIn(campaign: Campaign): Promise<void> {
    // LinkedIn API integration
    console.log('Publishing to LinkedIn...');
  }

  private async publishToYouTube(campaign: Campaign): Promise<void> {
    // YouTube Data API integration
    console.log('Publishing to YouTube...');
  }

  private async publishToGoogleAds(campaign: Campaign): Promise<void> {
    // Google Ads API integration
    console.log('Publishing to Google Ads...');
  }

  // Performance Tracking
  private startPerformanceTracking(campaignId: string): void {
    // Simulate real-time performance updates
    const interval = setInterval(async () => {
      try {
        const campaign = await this.getCampaign(campaignId);
        if (campaign.status !== 'active') {
          clearInterval(interval);
          return;
        }

        // Simulate performance data updates
        const performance = this.generateMockPerformanceData(campaign.performance);
        await this.updateCampaignPerformance(campaignId, performance);
      } catch (error) {
        console.error('Error updating campaign performance:', error);
        clearInterval(interval);
      }
    }, 30000); // Update every 30 seconds
  }

  private generateMockPerformanceData(current: CampaignPerformance): CampaignPerformance {
    return {
      reach: current.reach + Math.floor(Math.random() * 100),
      impressions: current.impressions + Math.floor(Math.random() * 200),
      clicks: current.clicks + Math.floor(Math.random() * 10),
      ctr: 0, // Will be calculated
      cpc: Math.random() * 2 + 0.5,
      cpl: Math.random() * 10 + 5,
      conversions: current.conversions + Math.floor(Math.random() * 3),
      roi: 0, // Will be calculated
      engagement: {
        likes: current.engagement.likes + Math.floor(Math.random() * 20),
        comments: current.engagement.comments + Math.floor(Math.random() * 5),
        shares: current.engagement.shares + Math.floor(Math.random() * 3),
        saves: current.engagement.saves + Math.floor(Math.random() * 8)
      }
    };
  }

  private async updateCampaignPerformance(id: string, performance: CampaignPerformance): Promise<void> {
    const campaign = await this.getCampaign(id);
    
    // Calculate derived metrics
    performance.ctr = performance.impressions > 0 ? (performance.clicks / performance.impressions) * 100 : 0;
    performance.roi = performance.conversions > 0 ? ((performance.conversions * 100) / (campaign.budget || 1)) * 100 : 0;
    
    campaign.performance = performance;
    campaign.updatedAt = new Date().toISOString();
  }

  // Analytics
  async getAnalytics(campaignId: string, timeframe: string = '7d'): Promise<AnalyticsData> {
    const campaign = await this.getCampaign(campaignId);
    
    return {
      campaignId,
      platform: campaign.platforms.join(', '),
      metrics: {
        reach: campaign.performance.reach,
        impressions: campaign.performance.impressions,
        clicks: campaign.performance.clicks,
        ctr: campaign.performance.ctr,
        cpc: campaign.performance.cpc,
        conversions: campaign.performance.conversions,
        roi: campaign.performance.roi,
        engagement_rate: this.calculateEngagementRate(campaign.performance)
      },
      timeframe,
      lastUpdated: campaign.updatedAt
    };
  }

  private calculateEngagementRate(performance: CampaignPerformance): number {
    const totalEngagements = performance.engagement.likes + 
                           performance.engagement.comments + 
                           performance.engagement.shares + 
                           performance.engagement.saves;
    
    return performance.reach > 0 ? (totalEngagements / performance.reach) * 100 : 0;
  }

  async pauseCampaign(id: string): Promise<void> {
    const campaign = await this.getCampaign(id);
    campaign.status = 'paused';
    campaign.updatedAt = new Date().toISOString();
  }

  async resumeCampaign(id: string): Promise<void> {
    const campaign = await this.getCampaign(id);
    campaign.status = 'active';
    campaign.updatedAt = new Date().toISOString();
    this.startPerformanceTracking(id);
  }

  async completeCampaign(id: string): Promise<void> {
    const campaign = await this.getCampaign(id);
    campaign.status = 'completed';
    campaign.updatedAt = new Date().toISOString();
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }
}

export const campaignService = new CampaignService();