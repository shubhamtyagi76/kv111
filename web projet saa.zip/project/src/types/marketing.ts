export interface MarketingStrategyInput {
  productService: string;
  targetAudience: string;
  platforms: string[];
  monthlyBudget: number;
  strategyType: 'organic' | 'paid' | 'hybrid';
  businessGoals: string[];
  industry: string;
  competitorAnalysis?: string;
}

export interface SEOStrategy {
  keywords: string[];
  blogs: string[];
  backlinks: string[];
  contentPillars: string[];
  monthlyTargets: {
    organicTraffic: number;
    keywordRankings: number;
    backlinksToAcquire: number;
  };
}

export interface SMMStrategy {
  platforms: string[];
  hooks: string[];
  contentThemes: string[];
  postingFrequency: Record<string, number>;
  calendar: Record<string, string[]>;
  hashtagStrategy: Record<string, string[]>;
}

export interface AdStrategy {
  budget: number;
  platforms: string[];
  budgetSplit: Record<string, number>;
  formats: string[];
  targetingCriteria: {
    demographics: string[];
    interests: string[];
    behaviors: string[];
  };
  campaignObjectives: string[];
}

export interface EmailStrategy {
  leadMagnet: string;
  funnelStages: string[];
  emailSequence: {
    subject: string;
    content: string;
    sendDay: number;
  }[];
  segmentation: string[];
}

export interface MarketingStrategy {
  id: string;
  businessId: string;
  seo: SEOStrategy;
  smm: SMMStrategy;
  ads: AdStrategy;
  email: EmailStrategy;
  personas: CustomerPersona[];
  calendar: WeeklyCalendar;
  kpis: KPITargets;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerPersona {
  id: string;
  name: string;
  age: string;
  occupation: string;
  income: string;
  painPoints: string[];
  goals: string[];
  preferredChannels: string[];
  buyingBehavior: string;
  demographics: {
    location: string;
    education: string;
    familyStatus: string;
  };
}

export interface WeeklyCalendar {
  [week: string]: {
    [day: string]: CalendarItem[];
  };
}

export interface CalendarItem {
  id: string;
  type: 'post' | 'story' | 'reel' | 'blog' | 'email' | 'ad';
  platform: string;
  title: string;
  description: string;
  status: 'planned' | 'created' | 'scheduled' | 'published';
  contentId?: string;
}

export interface KPITargets {
  reach: number;
  engagement: number;
  leads: number;
  conversions: number;
  roi: number;
}

// Phase 3 - Media Creation Types
export interface MediaCreationInput {
  type: 'post' | 'reel' | 'blog' | 'ad' | 'story' | 'video';
  topic: string;
  platform: string;
  tone: 'professional' | 'casual' | 'humorous' | 'inspirational' | 'educational';
  cta: string;
  branding: BrandKit;
  duration?: number; // for videos
  dimensions?: string; // for images
}

export interface BrandKit {
  logo?: string;
  primaryColor: string;
  secondaryColor: string;
  fonts: string[];
  style: 'modern' | 'classic' | 'minimalist' | 'bold' | 'playful';
  voiceGuidelines: string;
}

export interface GeneratedContent {
  id: string;
  type: string;
  title: string;
  content: string;
  mediaUrl?: string;
  thumbnailUrl?: string;
  duration?: number;
  fileSize?: number;
  format: string;
  platform: string;
  status: 'generating' | 'ready' | 'failed';
  createdAt: string;
  metadata: {
    prompt: string;
    aiModel: string;
    processingTime: number;
  };
}

export interface VoiceoverOptions {
  gender: 'male' | 'female';
  language: string;
  emotion: 'energetic' | 'emotional' | 'neutral' | 'calm' | 'excited';
  speed: number;
  pitch: number;
  effects: string[];
}

// Phase 4 - Campaign Management Types
export interface Campaign {
  id: string;
  name: string;
  type: 'post' | 'ad' | 'email' | 'story' | 'sequence';
  platforms: string[];
  content: GeneratedContent[];
  schedule: CampaignSchedule;
  targeting: CampaignTargeting;
  budget?: number;
  status: 'draft' | 'scheduled' | 'active' | 'paused' | 'completed';
  performance: CampaignPerformance;
  createdAt: string;
  updatedAt: string;
}

export interface CampaignSchedule {
  type: 'immediate' | 'scheduled' | 'recurring';
  startDate: string;
  endDate?: string;
  frequency?: 'daily' | 'weekly' | 'monthly';
  times: string[];
  timezone: string;
}

export interface CampaignTargeting {
  demographics: {
    age: string;
    gender: string;
    location: string[];
    interests: string[];
  };
  behaviors: string[];
  customAudiences: string[];
}

export interface CampaignPerformance {
  reach: number;
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  cpl: number;
  conversions: number;
  roi: number;
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    saves: number;
  };
}

export interface AnalyticsData {
  campaignId: string;
  platform: string;
  metrics: {
    [key: string]: number;
  };
  timeframe: string;
  lastUpdated: string;
}

export interface AIRecommendation {
  id: string;
  type: 'optimization' | 'content' | 'timing' | 'budget' | 'targeting';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  effort: 'easy' | 'moderate' | 'complex';
  expectedImprovement: string;
  actionItems: string[];
}