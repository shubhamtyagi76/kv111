export interface BusinessData {
  businessIdea: string;
  niche: string;
  targetAudience: string;
  serviceType: 'product' | 'service' | 'both';
  businessName: string;
  brandTone: 'professional' | 'friendly' | 'bold' | 'minimalist';
  primaryColor: string;
  secondaryColor: string;
  industry: string;
  goals: string[];
  uniqueValue: string;
  contactEmail: string;
  contactPhone?: string;
  budget: string;
  timeline: string;
}

export interface WebsiteTemplate {
  id: string;
  name: string;
  category: string;
  preview: string;
  sections: string[];
  suitableFor: string[];
}

export interface MarketingStrategy {
  id: string;
  businessId: string;
  seoKeywords: string[];
  contentCalendar: ContentCalendarItem[];
  adPlatforms: string[];
  audienceTargeting: AudienceTarget;
  marketingObjectives: string[];
}

export interface ContentCalendarItem {
  id: string;
  type: 'blog' | 'social' | 'ad' | 'email';
  title: string;
  platform: string;
  scheduledDate: Date;
  content: string;
  status: 'draft' | 'scheduled' | 'published';
}

export interface AudienceTarget {
  demographics: {
    ageRange: string;
    gender: string;
    location: string;
    income: string;
  };
  interests: string[];
  behaviors: string[];
  painPoints: string[];
}

export interface EmailNotification {
  to: string;
  subject: string;
  html: string;
  businessData?: BusinessData;
}

export interface DatabaseRecord {
  id: string;
  created_at: string;
  business_name: string;
  business_idea: string;
  niche: string;
  industry: string;
  contact_email: string;
  contact_phone?: string;
  budget: string;
  timeline: string;
  status: 'inquiry' | 'in_progress' | 'completed';
  website_generated: boolean;
}