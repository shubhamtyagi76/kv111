import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database functions
export const saveBusinessInquiry = async (businessData: any) => {
  try {
    const { data, error } = await supabase
      .from('business_inquiries')
      .insert([
        {
          business_name: businessData.businessName,
          business_idea: businessData.businessIdea,
          niche: businessData.niche,
          industry: businessData.industry,
          service_type: businessData.serviceType,
          brand_tone: businessData.brandTone,
          primary_color: businessData.primaryColor,
          secondary_color: businessData.secondaryColor,
          target_audience: businessData.targetAudience,
          unique_value: businessData.uniqueValue,
          goals: businessData.goals,
          contact_email: businessData.contactEmail,
          contact_phone: businessData.contactPhone,
          budget: businessData.budget,
          timeline: businessData.timeline,
          status: 'inquiry'
        }
      ])
      .select()

    if (error) throw error
    return { success: true, data }
  } catch (error) {
    console.error('Error saving business inquiry:', error)
    return { success: false, error }
  }
}

export const updateWebsiteGenerated = async (inquiryId: string) => {
  try {
    const { data, error } = await supabase
      .from('business_inquiries')
      .update({ 
        website_generated: true, 
        status: 'in_progress',
        updated_at: new Date().toISOString()
      })
      .eq('id', inquiryId)
      .select()

    if (error) throw error
    return { success: true, data }
  } catch (error) {
    console.error('Error updating website status:', error)
    return { success: false, error }
  }
}

export const getBusinessInquiries = async () => {
  try {
    const { data, error } = await supabase
      .from('business_inquiries')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) throw error
    return { success: true, data }
  } catch (error) {
    console.error('Error fetching business inquiries:', error)
    return { success: false, error }
  }
}