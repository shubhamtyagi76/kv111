import React, { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import LandingPage from './components/LandingPage';
import BusinessIdeaFlow from './components/BusinessIdeaFlow';
import WebsiteBuilder from './components/WebsiteBuilder';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import AdminDashboard from './components/AdminDashboard';
import { BusinessData } from './types/business';

// Phase 2 - Strategy
import StrategyForm from './features/strategy/StrategyForm';
import StrategyResult from './features/strategy/StrategyResult';
import { strategyEngine } from './features/strategy/StrategyEngine';
import { Strategy, StrategyInput } from './features/strategy/types';

// Phase 3 - Media
import MediaForm from './features/media/MediaForm';
import MediaPreview from './features/media/MediaPreview';
import { blogGenerator } from './features/media/BlogGenerator';
import { imageGenerator } from './features/media/ImageGenerator';
import { videoGenerator } from './features/media/VideoGenerator';
import { voiceoverGenerator } from './features/media/VoiceoverGenerator';
import { MediaCreationInput, GeneratedContent, VoiceoverOptions } from './features/media/types';

// Phase 4 - Automation
import CampaignBuilder from './features/automation/CampaignBuilder';
import { Campaign } from './features/automation/types';

import toast from 'react-hot-toast';

function App() {
  const [currentStep, setCurrentStep] = useState<'landing' | 'idea-flow' | 'website-builder' | 'strategy-form' | 'strategy-result' | 'media-form' | 'media-preview' | 'campaign-builder' | 'analytics' | 'admin'>('landing');
  const [businessData, setBusinessData] = useState<BusinessData | null>(null);
  const [generatedStrategy, setGeneratedStrategy] = useState<Strategy | null>(null);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleStartJourney = () => {
    setCurrentStep('idea-flow');
  };

  const handleBusinessDataComplete = (data: BusinessData) => {
    setBusinessData(data);
    setCurrentStep('website-builder');
  };

  const handleBackToLanding = () => {
    setCurrentStep('landing');
    setBusinessData(null);
  };

  const handleNavigateToMarketing = () => {
    setCurrentStep('strategy-form');
  };

  const handleNavigateToMediaStudio = () => {
    setCurrentStep('media-form');
  };

  const handleNavigateTocampaigns = () => {
    setCurrentStep('campaign-builder');
  };

  const handleNavigateToAnalytics = () => {
    setCurrentStep('analytics');
  };

  const handleNavigateToAdmin = () => {
    setCurrentStep('admin');
  };

  // Strategy handlers
  const handleStrategyComplete = async (input: StrategyInput) => {
    setIsGenerating(true);
    try {
      const strategy = await strategyEngine.generateStrategy(input);
      setGeneratedStrategy(strategy);
      setCurrentStep('strategy-result');
      toast.success('Marketing strategy generated successfully!');
    } catch (error) {
      toast.error('Failed to generate strategy. Please try again.');
      console.error('Strategy generation error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleStrategyExport = () => {
    if (!generatedStrategy) return;
    
    const dataStr = JSON.stringify(generatedStrategy, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `marketing-strategy-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Strategy exported successfully!');
  };

  // Media handlers
  const handleMediaComplete = async (input: MediaCreationInput, voiceOptions?: VoiceoverOptions) => {
    setIsGenerating(true);
    
    try {
      const content: GeneratedContent = {
        id: Date.now().toString(),
        type: input.type,
        title: `${input.type} - ${input.topic}`,
        content: '',
        status: 'generating',
        platform: input.platform,
        format: getFormatForType(input.type),
        createdAt: new Date().toISOString(),
        metadata: {
          prompt: input.topic,
          aiModel: 'gpt-4',
          processingTime: 0
        }
      };

      setGeneratedContent(prev => [content, ...prev]);
      setCurrentStep('media-preview');

      const startTime = Date.now();

      // Generate text content
      let textContent = '';
      if (input.type === 'blog') {
        textContent = await blogGenerator.generateBlog(input);
      } else if (['reel', 'video'].includes(input.type)) {
        textContent = await videoGenerator.generateVideoScript(input);
      } else {
        // Generate other content types using a general text generator
        textContent = await generateTextContent(input);
      }
      
      content.content = textContent;

      // Generate visual content if needed
      if (['post', 'story', 'ad'].includes(input.type)) {
        content.mediaUrl = await imageGenerator.generateImage(input);
        content.thumbnailUrl = content.mediaUrl;
      }

      // Generate video if needed
      if (['reel', 'video'].includes(input.type)) {
        content.mediaUrl = await videoGenerator.generateVideo(textContent, input);
        content.duration = input.duration || 30;
      }

      // Generate voiceover if needed
      if (['reel', 'video'].includes(input.type) && voiceOptions) {
        const script = extractScriptFromContent(textContent);
        if (script) {
          const audioUrl = await voiceoverGenerator.generateVoiceover(script, voiceOptions);
          content.metadata.audioUrl = audioUrl;
        }
      }

      content.status = 'ready';
      content.metadata.processingTime = Date.now() - startTime;

      setGeneratedContent(prev => 
        prev.map(c => c.id === content.id ? content : c)
      );

      toast.success('Content generated successfully!');
    } catch (error) {
      console.error('Content generation error:', error);
      toast.error('Failed to generate content. Please try again.');
      
      setGeneratedContent(prev => 
        prev.map(c => c.id === Date.now().toString() ? { ...c, status: 'failed' } : c)
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const getFormatForType = (type: string): string => {
    switch (type) {
      case 'post':
      case 'story':
      case 'ad':
        return 'image/jpeg';
      case 'reel':
      case 'video':
        return 'video/mp4';
      case 'blog':
        return 'text/html';
      default:
        return 'text/plain';
    }
  };

  const generateTextContent = async (input: MediaCreationInput): Promise<string> => {
    // Mock text generation for non-blog content
    const contentTemplates = {
      post: `🚀 ${input.topic}\n\nHere's what you need to know:\n\n✅ Key insight #1\n✅ Key insight #2\n✅ Key insight #3\n\n💡 Pro tip: ${input.topic} is the future!\n\n${input.cta}\n\n#AI #automation #business #${input.platform.toLowerCase()}`,
      ad: `🎯 ${input.topic}\n\nTransform your business today!\n\n✅ Increase efficiency by 300%\n✅ Reduce costs by 50%\n✅ Scale operations effortlessly\n\n${input.cta}\n\nLimited time offer - Act now!`,
      story: `📱 ${input.topic}\n\nSwipe up to learn more!\n\n${input.cta}`
    };

    return contentTemplates[input.type as keyof typeof contentTemplates] || contentTemplates.post;
  };

  const extractScriptFromContent = (content: string): string => {
    const lines = content.split('\n');
    return lines
      .filter(line => !line.startsWith('#') && !line.startsWith('**') && line.trim())
      .join(' ')
      .substring(0, 500);
  };

  const handleMediaDownload = (content: GeneratedContent) => {
    if (content.type === 'blog') {
      const blob = new Blob([content.content], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${content.title}.html`;
      a.click();
      URL.revokeObjectURL(url);
    } else if (content.mediaUrl) {
      const a = document.createElement('a');
      a.href = content.mediaUrl;
      a.download = `${content.title}.${content.format.split('/')[1]}`;
      a.click();
    }
    toast.success('Content downloaded!');
  };

  const handleMediaShare = (content: GeneratedContent) => {
    if (navigator.share) {
      navigator.share({
        title: content.title,
        text: content.content.substring(0, 100) + '...',
        url: content.mediaUrl || window.location.href
      });
    } else {
      navigator.clipboard.writeText(content.content);
      toast.success('Content copied to clipboard!');
    }
  };

  // Campaign handlers
  const handleCampaignComplete = (campaign: Partial<Campaign>) => {
    console.log('Campaign created:', campaign);
    toast.success('Campaign created successfully!');
    setCurrentStep('landing');
  };

  return (
    <>
      <div className="min-h-screen bg-black">
        {currentStep === 'landing' && (
          <LandingPage 
            onStartJourney={handleStartJourney}
            onNavigateToStrategy={handleNavigateToMarketing}
            onNavigateToMedia={handleNavigateToMediaStudio}
            onNavigateToCampaigns={handleNavigateTocampaigns}
            onNavigateToAnalytics={handleNavigateToAnalytics}
            onNavigateToAdmin={handleNavigateToAdmin}
          />
        )}
        {currentStep === 'idea-flow' && (
          <BusinessIdeaFlow 
            onComplete={handleBusinessDataComplete}
            onBack={handleBackToLanding}
          />
        )}
        {currentStep === 'website-builder' && businessData && (
          <WebsiteBuilder 
            businessData={businessData}
            onBack={() => setCurrentStep('idea-flow')}
            onNavigateToStrategy={handleNavigateToMarketing}
          />
        )}
        {currentStep === 'strategy-form' && (
          <StrategyForm 
            onComplete={handleStrategyComplete}
            onBack={handleBackToLanding}
          />
        )}
        {currentStep === 'strategy-result' && generatedStrategy && (
          <StrategyResult 
            strategy={generatedStrategy}
            onBack={() => setCurrentStep('strategy-form')}
            onNavigateToMedia={handleNavigateToMediaStudio}
            onExport={handleStrategyExport}
          />
        )}
        {currentStep === 'media-form' && (
          <MediaForm 
            onComplete={handleMediaComplete}
            onBack={handleBackToLanding}
          />
        )}
        {currentStep === 'media-preview' && (
          <MediaPreview 
            content={generatedContent}
            onBack={() => setCurrentStep('media-form')}
            onDownload={handleMediaDownload}
            onShare={handleMediaShare}
          />
        )}
        {currentStep === 'campaign-builder' && (
          <CampaignBuilder 
            onComplete={handleCampaignComplete}
            onBack={handleBackToLanding}
          />
        )}
        {currentStep === 'analytics' && (
          <AnalyticsDashboard 
            onBack={handleBackToLanding}
          />
        )}
        {currentStep === 'admin' && (
          <AdminDashboard />
        )}
      </div>
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#1f2937',
            color: '#fff',
            border: '1px solid #374151'
          },
          success: {
            iconTheme: {
              primary: '#0db2e9',
              secondary: '#fff',
            },
          },
        }}
      />
    </>
  );
}

export default App;