import { MediaCreationInput } from './types';

class ImageGenerator {
  private apiKey: string;
  private baseUrl: string;
  private mockMode: boolean;

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY || '';
    this.baseUrl = 'https://api.openai.com/v1';
    this.mockMode = !this.apiKey;
  }

  async generateImage(input: MediaCreationInput): Promise<string> {
    if (this.mockMode) {
      return this.getMockImage(input);
    }

    try {
      const prompt = this.buildImagePrompt(input);
      
      const response = await fetch(`${this.baseUrl}/images/generations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'dall-e-3',
          prompt: prompt,
          size: this.getDimensions(input.dimensions || '1024x1024'),
          quality: 'hd',
          n: 1
        })
      });

      const data = await response.json();
      return data.data[0].url;
    } catch (error) {
      console.error('Error generating image:', error);
      return this.getMockImage(input);
    }
  }

  private buildImagePrompt(input: MediaCreationInput): string {
    return `Create a ${input.branding.style} style ${input.type} image for ${input.platform} about ${input.topic}. 
    
    Style: ${input.branding.style}
    Brand colors: ${input.branding.primaryColor} and ${input.branding.secondaryColor}
    Tone: ${input.tone}
    Platform: ${input.platform}
    
    The image should be professional, engaging, and optimized for ${input.platform}. 
    Include relevant visual elements that represent ${input.topic} while maintaining brand consistency.
    Make it visually appealing and suitable for social media engagement.`;
  }

  private getDimensions(dimensions: string): '1024x1024' | '1792x1024' | '1024x1792' {
    switch (dimensions) {
      case '1080x1080':
      case '1024x1024':
        return '1024x1024';
      case '1920x1080':
      case '1792x1024':
        return '1792x1024';
      case '1080x1920':
      case '1024x1792':
        return '1024x1792';
      default:
        return '1024x1024';
    }
  }

  private getMockImage(input: MediaCreationInput): string {
    // Return appropriate stock images based on content type and topic
    const imageCategories = {
      business: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg',
      technology: 'https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg',
      marketing: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg',
      social: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg',
      creative: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg',
      default: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg'
    };

    const topic = input.topic.toLowerCase();
    let category = 'default';

    if (topic.includes('business') || topic.includes('entrepreneur')) category = 'business';
    else if (topic.includes('tech') || topic.includes('ai') || topic.includes('digital')) category = 'technology';
    else if (topic.includes('marketing') || topic.includes('advertising')) category = 'marketing';
    else if (topic.includes('social') || topic.includes('media')) category = 'social';
    else if (topic.includes('creative') || topic.includes('design')) category = 'creative';

    const baseUrl = imageCategories[category as keyof typeof imageCategories];
    const dimensions = input.dimensions || '1080x1080';
    const [width, height] = dimensions.split('x');
    
    return `${baseUrl}?auto=compress&cs=tinysrgb&w=${width}&h=${height}&fit=crop`;
  }
}

export const imageGenerator = new ImageGenerator();