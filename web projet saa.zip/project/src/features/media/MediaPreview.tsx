import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Download, Share2, Eye, Edit, Play, Pause, Volume2, 
  VolumeX, FileText, Image, Video, Mic, ArrowLeft 
} from 'lucide-react';
import { GeneratedContent } from './types';

interface MediaPreviewProps {
  content: GeneratedContent[];
  onBack: () => void;
  onEdit?: (content: GeneratedContent) => void;
  onDownload: (content: GeneratedContent) => void;
  onShare: (content: GeneratedContent) => void;
}

const MediaPreview: React.FC<MediaPreviewProps> = ({ 
  content, 
  onBack, 
  onEdit, 
  onDownload, 
  onShare 
}) => {
  const [selectedContent, setSelectedContent] = useState<GeneratedContent | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const getContentIcon = (type: string) => {
    switch (type) {
      case 'blog':
        return <FileText className="w-6 h-6" />;
      case 'post':
      case 'story':
      case 'ad':
        return <Image className="w-6 h-6" />;
      case 'reel':
      case 'video':
        return <Video className="w-6 h-6" />;
      default:
        return <FileText className="w-6 h-6" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ready':
        return 'bg-green-500/20 text-green-400';
      case 'generating':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'failed':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <div className="flex items-center mb-4">
              <button
                onClick={onBack}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center mr-4"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Studio
              </button>
            </div>
            <h1 className="text-4xl font-bold text-[#0db2e9] mb-2">Content Library</h1>
            <p className="text-white/80">Manage and preview your AI-generated content</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-white">{content.length}</div>
            <div className="text-white/60">Total Items</div>
          </div>
        </div>

        {content.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <FileText className="w-10 h-10 text-white/40" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">No content yet</h3>
            <p className="text-white/70 mb-8">Create your first piece of content to get started</p>
            <button
              onClick={onBack}
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-6 py-3 rounded-lg transition-all duration-200 font-medium"
            >
              Create Content
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {content.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden hover:border-[#0db2e9]/50 transition-all duration-300"
              >
                {/* Content Preview */}
                <div className="aspect-video bg-white/10 relative group cursor-pointer" onClick={() => setSelectedContent(item)}>
                  {item.mediaUrl ? (
                    item.format.startsWith('video/') ? (
                      <video
                        src={item.mediaUrl}
                        className="w-full h-full object-cover"
                        muted
                        loop
                        onMouseEnter={(e) => e.currentTarget.play()}
                        onMouseLeave={(e) => e.currentTarget.pause()}
                      />
                    ) : (
                      <img
                        src={item.mediaUrl}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    )
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      {getContentIcon(item.type)}
                    </div>
                  )}
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Eye className="w-8 h-8 text-white" />
                  </div>
                  
                  {/* Status Badge */}
                  <div className="absolute top-2 right-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(item.status)}`}>
                      {item.status}
                    </span>
                  </div>

                  {/* Duration Badge for Videos */}
                  {item.duration && (
                    <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-xs text-white">
                      {formatDuration(item.duration)}
                    </div>
                  )}
                </div>

                {/* Content Info */}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-white font-semibold truncate flex-1 mr-2">{item.title}</h3>
                    <div className="text-[#0db2e9]">
                      {getContentIcon(item.type)}
                    </div>
                  </div>
                  
                  <p className="text-white/70 text-sm mb-3 line-clamp-2">
                    {item.content.substring(0, 100)}...
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-white/60 mb-4">
                    <span>{item.platform}</span>
                    <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                  </div>

                  {/* File Info */}
                  {item.fileSize && (
                    <div className="text-xs text-white/60 mb-4">
                      Size: {formatFileSize(item.fileSize)}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedContent(item)}
                      className="flex-1 bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </button>
                    <button
                      onClick={() => onDownload(item)}
                      className="bg-[#0db2e9]/20 hover:bg-[#0db2e9]/30 text-[#0db2e9] px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onShare(item)}
                      className="bg-green-500/20 hover:bg-green-500/30 text-green-400 px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                    {onEdit && (
                      <button
                        onClick={() => onEdit(item)}
                        className="bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Content Detail Modal */}
        {selectedContent && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-white/10">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold text-white">{selectedContent.title}</h3>
                  <button
                    onClick={() => setSelectedContent(null)}
                    className="text-white/60 hover:text-white text-2xl p-2"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                {/* Media Preview */}
                {selectedContent.mediaUrl && (
                  <div className="mb-6">
                    {selectedContent.format.startsWith('video/') ? (
                      <div className="relative">
                        <video
                          src={selectedContent.mediaUrl}
                          className="w-full max-h-96 object-contain rounded-lg"
                          controls
                          muted={isMuted}
                        />
                        <div className="absolute bottom-4 right-4 flex gap-2">
                          <button
                            onClick={() => setIsMuted(!isMuted)}
                            className="bg-black/50 text-white p-2 rounded-full hover:bg-black/70 transition-colors"
                          >
                            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>
                    ) : (
                      <img
                        src={selectedContent.mediaUrl}
                        alt={selectedContent.title}
                        className="w-full max-h-96 object-contain rounded-lg"
                      />
                    )}
                  </div>
                )}

                {/* Audio Preview */}
                {selectedContent.metadata.audioUrl && (
                  <div className="mb-6">
                    <h4 className="text-lg font-semibold text-white mb-3 flex items-center">
                      <Mic className="w-5 h-5 mr-2" />
                      Voiceover
                    </h4>
                    <audio
                      src={selectedContent.metadata.audioUrl}
                      controls
                      className="w-full"
                    />
                  </div>
                )}
                
                {/* Content Text */}
                <div className="bg-white/5 p-4 rounded-lg mb-6">
                  <h4 className="text-lg font-semibold text-white mb-3">Content</h4>
                  <div className="text-white/80 whitespace-pre-wrap max-h-60 overflow-y-auto">
                    {selectedContent.content}
                  </div>
                </div>

                {/* Metadata */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h5 className="text-white font-medium mb-2">Details</h5>
                    <div className="space-y-1 text-sm text-white/70">
                      <div>Type: {selectedContent.type}</div>
                      <div>Platform: {selectedContent.platform}</div>
                      <div>Format: {selectedContent.format}</div>
                      <div>Created: {new Date(selectedContent.createdAt).toLocaleString()}</div>
                      {selectedContent.duration && <div>Duration: {formatDuration(selectedContent.duration)}</div>}
                      {selectedContent.fileSize && <div>Size: {formatFileSize(selectedContent.fileSize)}</div>}
                    </div>
                  </div>
                  
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h5 className="text-white font-medium mb-2">Generation Info</h5>
                    <div className="space-y-1 text-sm text-white/70">
                      <div>AI Model: {selectedContent.metadata.aiModel}</div>
                      <div>Processing Time: {selectedContent.metadata.processingTime}ms</div>
                      <div>Prompt: {selectedContent.metadata.prompt.substring(0, 50)}...</div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-4">
                  <button
                    onClick={() => onDownload(selectedContent)}
                    className="bg-[#0db2e9] hover:bg-[#0aa3d1] text-white px-6 py-3 rounded-lg transition-all flex items-center"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download
                  </button>
                  <button
                    onClick={() => onShare(selectedContent)}
                    className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg transition-all flex items-center"
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    Share
                  </button>
                  {onEdit && (
                    <button
                      onClick={() => onEdit(selectedContent)}
                      className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-lg transition-all flex items-center"
                    >
                      <Edit className="w-5 h-5 mr-2" />
                      Edit
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaPreview;