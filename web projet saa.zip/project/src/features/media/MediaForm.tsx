import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Image, Video, FileText, Mic, Palette, Wand2, 
  ArrowLeft, ArrowRight, Settings 
} from 'lucide-react';
import { MediaCreationInput, BrandKit, VoiceoverOptions } from './types';

interface MediaFormProps {
  onComplete: (input: MediaCreationInput, voiceOptions?: VoiceoverOptions) => void;
  onBack: () => void;
}

const MediaForm: React.FC<MediaFormProps> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<MediaCreationInput>({
    type: 'post',
    topic: '',
    platform: 'Instagram',
    tone: 'professional',
    cta: '',
    branding: {
      primaryColor: '#0db2e9',
      secondaryColor: '#b2fefa',
      fonts: ['Poppins'],
      style: 'modern',
      voiceGuidelines: 'Professional, friendly, and informative'
    },
    dimensions: '1080x1080'
  });

  const [voiceoverOptions, setVoiceoverOptions] = useState<VoiceoverOptions>({
    gender: 'female',
    language: 'en-US',
    emotion: 'neutral',
    speed: 1.0,
    pitch: 1.0,
    effects: []
  });

  const steps = [
    {
      title: 'Content Type',
      description: 'What do you want to create?',
      icon: <Wand2 className="w-8 h-8" />
    },
    {
      title: 'Content Details',
      description: 'Tell us about your content',
      icon: <FileText className="w-8 h-8" />
    },
    {
      title: 'Brand Settings',
      description: 'Customize your brand elements',
      icon: <Palette className="w-8 h-8" />
    },
    {
      title: 'Advanced Options',
      description: 'Fine-tune your content',
      icon: <Settings className="w-8 h-8" />
    }
  ];

  const contentTypes = [
    { value: 'post', label: 'Social Post', icon: <Image className="w-5 h-5" />, desc: 'Instagram/Facebook posts' },
    { value: 'story', label: 'Story', icon: <Image className="w-5 h-5" />, desc: 'Instagram/Facebook stories' },
    { value: 'reel', label: 'Reel/Video', icon: <Video className="w-5 h-5" />, desc: 'Short-form videos' },
    { value: 'blog', label: 'Blog Post', icon: <FileText className="w-5 h-5" />, desc: 'Long-form content' },
    { value: 'ad', label: 'Advertisement', icon: <Wand2 className="w-5 h-5" />, desc: 'Paid ad content' },
    { value: 'video', label: 'Video', icon: <Video className="w-5 h-5" />, desc: 'Long-form videos' }
  ];

  const platforms = ['Instagram', 'Facebook', 'LinkedIn', 'YouTube', 'TikTok', 'Twitter', 'Pinterest'];
  const tones = ['professional', 'casual', 'humorous', 'inspirational', 'educational'];
  const styles = ['modern', 'classic', 'minimalist', 'bold', 'playful'];

  const handleInputChange = (field: keyof MediaCreationInput, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleBrandingChange = (field: keyof BrandKit, value: any) => {
    setFormData(prev => ({
      ...prev,
      branding: { ...prev.branding, [field]: value }
    }));
  };

  const handleVoiceoverChange = (field: keyof VoiceoverOptions, value: any) => {
    setVoiceoverOptions(prev => ({ ...prev, [field]: value }));
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return formData.type !== '';
      case 1:
        return formData.topic.trim().length > 5 && formData.platform && formData.tone;
      case 2:
        return formData.branding.style && formData.branding.primaryColor;
      case 3:
        return true; // Advanced options are optional
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      const needsVoiceover = ['reel', 'video'].includes(formData.type);
      onComplete(formData, needsVoiceover ? voiceoverOptions : undefined);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      onBack();
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {contentTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => handleInputChange('type', type.value)}
                  className={`p-6 rounded-xl border-2 transition-all text-left ${
                    formData.type === type.value
                      ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                      : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                  }`}
                >
                  <div className="flex items-center mb-3">
                    {type.icon}
                    <span className="ml-3 font-semibold text-lg">{type.label}</span>
                  </div>
                  <p className="text-sm opacity-70">{type.desc}</p>
                </button>
              ))}
            </div>
          </motion.div>
        );

      case 1:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                What's your content topic?
              </label>
              <textarea
                value={formData.topic}
                onChange={(e) => handleInputChange('topic', e.target.value)}
                placeholder="e.g., 5 AI tools that will revolutionize your business workflow and save you 10 hours per week"
                className="w-full h-32 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white text-lg font-semibold mb-4">Platform</label>
                <select
                  value={formData.platform}
                  onChange={(e) => handleInputChange('platform', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                >
                  {platforms.map(platform => (
                    <option key={platform} value={platform} className="bg-gray-800">
                      {platform}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-white text-lg font-semibold mb-4">Tone</label>
                <select
                  value={formData.tone}
                  onChange={(e) => handleInputChange('tone', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                >
                  {tones.map(tone => (
                    <option key={tone} value={tone} className="bg-gray-800">
                      {tone.charAt(0).toUpperCase() + tone.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Call to Action
              </label>
              <input
                type="text"
                value={formData.cta}
                onChange={(e) => handleInputChange('cta', e.target.value)}
                placeholder="e.g., Visit our website, Sign up now, Learn more..."
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
              />
            </div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">Brand Style</label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {styles.map((style) => (
                  <button
                    key={style}
                    onClick={() => handleBrandingChange('style', style)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      formData.branding.style === style
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold capitalize">{style}</div>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white text-lg font-semibold mb-4">Primary Color</label>
                <input
                  type="color"
                  value={formData.branding.primaryColor}
                  onChange={(e) => handleBrandingChange('primaryColor', e.target.value)}
                  className="w-full h-12 bg-white/10 border border-white/20 rounded-xl cursor-pointer"
                />
              </div>
              <div>
                <label className="block text-white text-lg font-semibold mb-4">Secondary Color</label>
                <input
                  type="color"
                  value={formData.branding.secondaryColor}
                  onChange={(e) => handleBrandingChange('secondaryColor', e.target.value)}
                  className="w-full h-12 bg-white/10 border border-white/20 rounded-xl cursor-pointer"
                />
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Voice Guidelines
              </label>
              <textarea
                value={formData.branding.voiceGuidelines}
                onChange={(e) => handleBrandingChange('voiceGuidelines', e.target.value)}
                placeholder="Describe your brand voice and personality..."
                className="w-full h-24 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] resize-none"
              />
            </div>
          </motion.div>
        );

      case 3:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Image-specific options */}
            {['post', 'story', 'ad'].includes(formData.type) && (
              <div>
                <label className="block text-white text-lg font-semibold mb-4">Image Dimensions</label>
                <select
                  value={formData.dimensions}
                  onChange={(e) => handleInputChange('dimensions', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                >
                  <option value="1080x1080" className="bg-gray-800">Square (1080x1080)</option>
                  <option value="1080x1350" className="bg-gray-800">Portrait (1080x1350)</option>
                  <option value="1920x1080" className="bg-gray-800">Landscape (1920x1080)</option>
                  <option value="1080x1920" className="bg-gray-800">Story (1080x1920)</option>
                </select>
              </div>
            )}

            {/* Video-specific options */}
            {['reel', 'video'].includes(formData.type) && (
              <>
                <div>
                  <label className="block text-white text-lg font-semibold mb-4">
                    Duration: {formData.duration || 30} seconds
                  </label>
                  <input
                    type="range"
                    min="15"
                    max="300"
                    step="5"
                    value={formData.duration || 30}
                    onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
                    className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-white/60 text-sm mt-2">
                    <span>15s</span>
                    <span>5min</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">Voice Gender</label>
                    <select
                      value={voiceoverOptions.gender}
                      onChange={(e) => handleVoiceoverChange('gender', e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    >
                      <option value="female" className="bg-gray-800">Female</option>
                      <option value="male" className="bg-gray-800">Male</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">Voice Emotion</label>
                    <select
                      value={voiceoverOptions.emotion}
                      onChange={(e) => handleVoiceoverChange('emotion', e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    >
                      <option value="neutral" className="bg-gray-800">Neutral</option>
                      <option value="energetic" className="bg-gray-800">Energetic</option>
                      <option value="calm" className="bg-gray-800">Calm</option>
                      <option value="excited" className="bg-gray-800">Excited</option>
                      <option value="emotional" className="bg-gray-800">Emotional</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">
                      Speed: {voiceoverOptions.speed}x
                    </label>
                    <input
                      type="range"
                      min="0.5"
                      max="2.0"
                      step="0.1"
                      value={voiceoverOptions.speed}
                      onChange={(e) => handleVoiceoverChange('speed', parseFloat(e.target.value))}
                      className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">
                      Pitch: {voiceoverOptions.pitch}x
                    </label>
                    <input
                      type="range"
                      min="0.5"
                      max="2.0"
                      step="0.1"
                      value={voiceoverOptions.pitch}
                      onChange={(e) => handleVoiceoverChange('pitch', parseFloat(e.target.value))}
                      className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
              </>
            )}
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#0db2e9] mb-4">AI Media Creation Studio</h1>
          <p className="text-white/80 text-lg">
            Create professional content with AI - posts, videos, blogs, and more
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <span className="text-white/80">Step {currentStep + 1} of {steps.length}</span>
            <span className="text-white/80">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-3 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-8 mb-8">
          <div className="flex items-center mb-6">
            <div className="text-[#0db2e9] mr-4">
              {steps[currentStep].icon}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {steps[currentStep].title}
              </h2>
              <p className="text-white/70">
                {steps[currentStep].description}
              </p>
            </div>
          </div>

          {renderStep()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            className="flex items-center px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all duration-200"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            {currentStep === 0 ? 'Back to Home' : 'Previous'}
          </button>

          {currentStep === steps.length - 1 ? (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center px-8 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              <Wand2 className="w-5 h-5 mr-2" />
              Generate Content
            </button>
          ) : (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center px-6 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              Next
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MediaForm;