export interface MediaCreationInput {
  type: 'post' | 'reel' | 'blog' | 'ad' | 'story' | 'video';
  topic: string;
  platform: string;
  tone: 'professional' | 'casual' | 'humorous' | 'inspirational' | 'educational';
  cta: string;
  branding: BrandKit;
  duration?: number; // for videos
  dimensions?: string; // for images
}

export interface BrandKit {
  logo?: string;
  primaryColor: string;
  secondaryColor: string;
  fonts: string[];
  style: 'modern' | 'classic' | 'minimalist' | 'bold' | 'playful';
  voiceGuidelines: string;
}

export interface GeneratedContent {
  id: string;
  type: string;
  title: string;
  content: string;
  mediaUrl?: string;
  thumbnailUrl?: string;
  duration?: number;
  fileSize?: number;
  format: string;
  platform: string;
  status: 'generating' | 'ready' | 'failed';
  createdAt: string;
  metadata: {
    prompt: string;
    aiModel: string;
    processingTime: number;
    audioUrl?: string;
  };
}

export interface VoiceoverOptions {
  gender: 'male' | 'female';
  language: string;
  emotion: 'energetic' | 'emotional' | 'neutral' | 'calm' | 'excited';
  speed: number;
  pitch: number;
  effects: string[];
}

export interface MediaLibraryItem {
  id: string;
  name: string;
  type: 'image' | 'video' | 'audio' | 'text';
  url: string;
  thumbnailUrl?: string;
  size: number;
  format: string;
  createdAt: string;
  tags: string[];
}