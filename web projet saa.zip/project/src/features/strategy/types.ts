export interface StrategyInput {
  businessType: string;
  productService: string;
  targetAudience: string;
  monthlyBudget: number;
  platforms: string[];
  strategyType: 'organic' | 'paid' | 'hybrid';
  industry: string;
  businessGoals: string[];
  competitorAnalysis?: string;
}

export interface SEOPlan {
  keywords: string[];
  blogIdeas: string[];
  backlinks: string[];
  contentPillars: string[];
  monthlyTargets: {
    organicTraffic: number;
    keywordRankings: number;
    backlinksToAcquire: number;
  };
}

export interface SMMPlan {
  platforms: string[];
  contentTypes: string[];
  frequency: string;
  hooks: string[];
  contentThemes: string[];
  postingSchedule: Record<string, number>;
  hashtagStrategy: Record<string, string[]>;
}

export interface AdsPlan {
  platforms: string[];
  format: string;
  budgetSplit: Record<string, number>;
  targetingCriteria: {
    demographics: string[];
    interests: string[];
    behaviors: string[];
  };
  campaignObjectives: string[];
}

export interface EmailPlan {
  leadMagnet: string;
  subjectLines: string[];
  cadence: string;
  funnelStages: string[];
  emailSequence: {
    subject: string;
    content: string;
    sendDay: number;
  }[];
}

export interface Strategy {
  id: string;
  businessId: string;
  seo: SEOPlan;
  smm: SMMPlan;
  ads: AdsPlan;
  email: EmailPlan;
  personas: CustomerPersona[];
  kpis: KPITargets;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerPersona {
  id: string;
  name: string;
  age: string;
  occupation: string;
  income: string;
  painPoints: string[];
  goals: string[];
  preferredChannels: string[];
  buyingBehavior: string;
  demographics: {
    location: string;
    education: string;
    familyStatus: string;
  };
}

export interface KPITargets {
  reach: number;
  engagement: number;
  leads: number;
  conversions: number;
  roi: number;
}