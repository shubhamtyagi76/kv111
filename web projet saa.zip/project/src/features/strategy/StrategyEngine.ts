import { StrategyInput, Strategy } from './types';

class StrategyEngine {
  private apiKey: string;
  private baseUrl: string;
  private mockMode: boolean;

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY || '';
    this.baseUrl = 'https://api.openai.com/v1';
    this.mockMode = !this.apiKey; // Use mock mode if no API key
  }

  async generateStrategy(input: StrategyInput): Promise<Strategy> {
    if (this.mockMode) {
      return this.generateMockStrategy(input);
    }
    
    try {
      const prompt = this.buildStrategyPrompt(input);
      
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4',
          messages: [
            {
              role: 'system',
              content: 'You are an expert digital marketing strategist. Generate comprehensive, actionable marketing strategies in JSON format.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.7,
          max_tokens: 4000
        })
      });

      const data = await response.json();
      const strategyData = JSON.parse(data.choices[0].message.content);
      
      return {
        id: this.generateId(),
        businessId: input.industry,
        ...strategyData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error generating marketing strategy:', error);
      return this.generateMockStrategy(input);
    }
  }

  private buildStrategyPrompt(input: StrategyInput): string {
    return `
    Generate a comprehensive digital marketing strategy for a ${input.businessType} business:
    
    Business Details:
    - Product/Service: ${input.productService}
    - Target Audience: ${input.targetAudience}
    - Industry: ${input.industry}
    - Monthly Budget: $${input.monthlyBudget}
    - Strategy Type: ${input.strategyType}
    - Preferred Platforms: ${input.platforms.join(', ')}
    - Business Goals: ${input.businessGoals.join(', ')}
    
    Return a JSON object with this exact structure:
    {
      "seo": {
        "keywords": ["keyword1", "keyword2"],
        "blogIdeas": ["blog title 1", "blog title 2"],
        "backlinks": ["strategy1", "strategy2"],
        "contentPillars": ["pillar1", "pillar2"],
        "monthlyTargets": {
          "organicTraffic": 5000,
          "keywordRankings": 20,
          "backlinksToAcquire": 10
        }
      },
      "smm": {
        "platforms": ["Instagram", "LinkedIn"],
        "contentTypes": ["reels", "carousels", "stories"],
        "frequency": "5 posts per week",
        "hooks": ["hook1", "hook2"],
        "contentThemes": ["theme1", "theme2"],
        "postingSchedule": {"Instagram": 7, "LinkedIn": 3},
        "hashtagStrategy": {
          "Instagram": ["#tag1", "#tag2"],
          "LinkedIn": ["#tag3", "#tag4"]
        }
      },
      "ads": {
        "platforms": ["Meta", "Google"],
        "format": "Lead Generation",
        "budgetSplit": {"Meta": 60, "Google": 40},
        "targetingCriteria": {
          "demographics": ["25-45", "College Educated"],
          "interests": ["interest1", "interest2"],
          "behaviors": ["behavior1", "behavior2"]
        },
        "campaignObjectives": ["Lead Generation", "Brand Awareness"]
      },
      "email": {
        "leadMagnet": "Free Guide: ...",
        "subjectLines": ["subject1", "subject2"],
        "cadence": "Weekly",
        "funnelStages": ["Awareness", "Consideration", "Decision"],
        "emailSequence": [
          {"subject": "Welcome!", "content": "...", "sendDay": 0},
          {"subject": "Your Free Guide", "content": "...", "sendDay": 1}
        ]
      },
      "personas": [
        {
          "id": "persona1",
          "name": "Primary Customer",
          "age": "25-35",
          "occupation": "Professional",
          "income": "$50k-$75k",
          "painPoints": ["pain1", "pain2"],
          "goals": ["goal1", "goal2"],
          "preferredChannels": ["Instagram", "Email"],
          "buyingBehavior": "Research-driven",
          "demographics": {
            "location": "Urban",
            "education": "College",
            "familyStatus": "Single/Married"
          }
        }
      ],
      "kpis": {
        "reach": 10000,
        "engagement": 500,
        "leads": 100,
        "conversions": 20,
        "roi": 300
      }
    }
    
    Make it specific to the industry and target audience provided.
    `;
  }

  private generateMockStrategy(input: StrategyInput): Strategy {
    return {
      id: this.generateId(),
      businessId: input.industry,
      seo: {
        keywords: [
          `${input.industry.toLowerCase()} solutions`,
          `best ${input.industry.toLowerCase()} services`,
          `${input.industry.toLowerCase()} automation`,
          `AI ${input.industry.toLowerCase()}`,
          `${input.industry.toLowerCase()} consulting`
        ],
        blogIdeas: [
          `Top 10 ${input.industry} Trends in 2025`,
          `How AI is Transforming ${input.industry}`,
          `Complete Guide to ${input.industry} Automation`,
          `${input.industry} Best Practices for Beginners`,
          `Future of ${input.industry}: What to Expect`
        ],
        backlinks: [
          'Guest posting on industry blogs',
          'Partner with complementary businesses',
          'Create shareable infographics',
          'Participate in industry forums'
        ],
        contentPillars: [
          'Educational Content',
          'Industry News & Trends',
          'Case Studies & Success Stories',
          'Behind-the-Scenes Content'
        ],
        monthlyTargets: {
          organicTraffic: Math.floor(input.monthlyBudget * 2),
          keywordRankings: Math.min(50, Math.floor(input.monthlyBudget / 100)),
          backlinksToAcquire: Math.min(20, Math.floor(input.monthlyBudget / 200))
        }
      },
      smm: {
        platforms: input.platforms,
        contentTypes: ['reels', 'carousels', 'stories', 'posts'],
        frequency: '5-7 posts per week',
        hooks: [
          "Before you scroll, here's something that will change your perspective...",
          "Most people don't know this secret about...",
          "Stop doing this if you want to succeed in...",
          "Here's what nobody tells you about...",
          "The biggest mistake I see people make is..."
        ],
        contentThemes: [
          'Educational Tips',
          'Behind the Scenes',
          'Customer Success Stories',
          'Industry Insights',
          'Quick Tutorials'
        ],
        postingSchedule: input.platforms.reduce((acc, platform) => {
          acc[platform] = platform === 'Instagram' ? 7 : platform === 'LinkedIn' ? 5 : 3;
          return acc;
        }, {} as Record<string, number>),
        hashtagStrategy: input.platforms.reduce((acc, platform) => {
          acc[platform] = [
            `#${input.industry.toLowerCase()}`,
            '#AI',
            '#automation',
            '#business',
            '#growth'
          ];
          return acc;
        }, {} as Record<string, string[]>)
      },
      ads: {
        platforms: input.platforms.filter(p => ['Instagram', 'Facebook', 'Google', 'LinkedIn'].includes(p)),
        format: 'Lead Generation',
        budgetSplit: {
          'Meta': 60,
          'Google': 30,
          'LinkedIn': 10
        },
        targetingCriteria: {
          demographics: ['25-45 years', 'College educated', 'Urban areas'],
          interests: [`${input.industry} tools`, 'Business automation', 'AI technology'],
          behaviors: ['Tech early adopters', 'Business decision makers', 'Online shoppers']
        },
        campaignObjectives: input.businessGoals.slice(0, 3)
      },
      email: {
        leadMagnet: `Free ${input.industry} Automation Guide`,
        subjectLines: [
          `Transform your ${input.industry} business in 30 days`,
          `The secret to ${input.industry} success`,
          `Why most ${input.industry} businesses fail`
        ],
        cadence: 'Weekly',
        funnelStages: ['Awareness', 'Consideration', 'Decision', 'Retention'],
        emailSequence: [
          {
            subject: 'Welcome! Your free guide is here',
            content: 'Thank you for joining our community...',
            sendDay: 0
          },
          {
            subject: `The #1 mistake in ${input.industry}`,
            content: 'Most businesses make this critical error...',
            sendDay: 3
          },
          {
            subject: 'Case study: How we helped [Company] grow 300%',
            content: 'Here\'s exactly what we did...',
            sendDay: 7
          }
        ]
      },
      personas: [
        {
          id: 'persona1',
          name: 'Tech-Savvy Entrepreneur',
          age: '28-40',
          occupation: 'Business Owner',
          income: '$75k-$150k',
          painPoints: ['Time management', 'Scaling operations', 'Technology adoption'],
          goals: ['Automate processes', 'Increase efficiency', 'Grow revenue'],
          preferredChannels: ['LinkedIn', 'Email', 'YouTube'],
          buyingBehavior: 'Research-driven, values ROI',
          demographics: {
            location: 'Urban/Suburban',
            education: 'College+',
            familyStatus: 'Married with kids'
          }
        }
      ],
      kpis: {
        reach: Math.floor(input.monthlyBudget * 5),
        engagement: Math.floor(input.monthlyBudget * 0.5),
        leads: Math.floor(input.monthlyBudget * 0.1),
        conversions: Math.floor(input.monthlyBudget * 0.02),
        roi: Math.min(500, Math.floor(input.monthlyBudget * 0.3))
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }
}

export const strategyEngine = new StrategyEngine();