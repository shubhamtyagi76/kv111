import React from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, Users, DollarSign, Target, Share2, Download, 
  ArrowRight, Sparkles, Eye, Mail 
} from 'lucide-react';
import { Strategy } from './types';

interface StrategyResultProps {
  strategy: Strategy;
  onBack: () => void;
  onNavigateToMedia?: () => void;
  onExport: () => void;
}

const StrategyResult: React.FC<StrategyResultProps> = ({ 
  strategy, 
  onBack, 
  onNavigateToMedia, 
  onExport 
}) => {
  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-[#0db2e9] mb-2">Your Marketing Strategy</h1>
            <p className="text-white/80">AI-generated comprehensive marketing plan</p>
          </div>
          <div className="flex gap-4">
            <button
              onClick={onExport}
              className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg transition-all duration-200 flex items-center"
            >
              <Download className="w-5 h-5 mr-2" />
              Export PDF
            </button>
            <button
              onClick={onBack}
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-6 py-3 rounded-lg transition-all duration-200 flex items-center font-medium"
            >
              Generate New
            </button>
            {onNavigateToMedia && (
              <button
                onClick={onNavigateToMedia}
                className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 px-6 py-3 rounded-lg transition-all duration-200 flex items-center font-medium"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Create Content
                <ArrowRight className="w-4 h-4 ml-2" />
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* SEO Strategy */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
              <TrendingUp className="w-6 h-6 mr-3" />
              SEO Strategy
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Target Keywords</h4>
                <div className="flex flex-wrap gap-2">
                  {strategy.seo.keywords.map((keyword, index) => (
                    <span key={index} className="bg-[#0db2e9]/20 text-[#0db2e9] px-3 py-1 rounded-full text-sm">
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Blog Content Ideas</h4>
                <ul className="space-y-2">
                  {strategy.seo.blogIdeas.map((blog, index) => (
                    <li key={index} className="text-white/80 flex items-start">
                      <span className="text-[#0db2e9] mr-2">•</span>
                      {blog}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Monthly Targets</h4>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-white/10 p-3 rounded-lg text-center">
                    <div className="text-[#0db2e9] font-bold text-lg">{strategy.seo.monthlyTargets.organicTraffic.toLocaleString()}</div>
                    <div className="text-white/70 text-xs">Traffic</div>
                  </div>
                  <div className="bg-white/10 p-3 rounded-lg text-center">
                    <div className="text-[#0db2e9] font-bold text-lg">{strategy.seo.monthlyTargets.keywordRankings}</div>
                    <div className="text-white/70 text-xs">Keywords</div>
                  </div>
                  <div className="bg-white/10 p-3 rounded-lg text-center">
                    <div className="text-[#0db2e9] font-bold text-lg">{strategy.seo.monthlyTargets.backlinksToAcquire}</div>
                    <div className="text-white/70 text-xs">Backlinks</div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Social Media Strategy */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
              <Share2 className="w-6 h-6 mr-3" />
              Social Media Strategy
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Content Hooks</h4>
                <ul className="space-y-2">
                  {strategy.smm.hooks.map((hook, index) => (
                    <li key={index} className="text-white/80 flex items-start">
                      <span className="text-[#0db2e9] mr-2">•</span>
                      "{hook}"
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Posting Frequency</h4>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(strategy.smm.postingSchedule).map(([platform, frequency]) => (
                    <div key={platform} className="bg-white/10 p-3 rounded-lg">
                      <div className="text-white font-medium">{platform}</div>
                      <div className="text-[#0db2e9]">{frequency} posts/week</div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Content Types</h4>
                <div className="flex flex-wrap gap-2">
                  {strategy.smm.contentTypes.map((type, index) => (
                    <span key={index} className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm">
                      {type}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Ad Strategy */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
              <DollarSign className="w-6 h-6 mr-3" />
              Advertising Strategy
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Budget Allocation</h4>
                <div className="space-y-2">
                  {Object.entries(strategy.ads.budgetSplit).map(([platform, percentage]) => (
                    <div key={platform} className="flex justify-between items-center">
                      <span className="text-white/80">{platform}</span>
                      <span className="text-[#0db2e9] font-semibold">{percentage}%</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Campaign Objectives</h4>
                <div className="flex flex-wrap gap-2">
                  {strategy.ads.campaignObjectives.map((objective, index) => (
                    <span key={index} className="bg-yellow-500/20 text-yellow-400 px-3 py-1 rounded-full text-sm">
                      {objective}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Targeting Criteria</h4>
                <div className="space-y-2">
                  <div>
                    <span className="text-white/70 text-sm">Demographics:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {strategy.ads.targetingCriteria.demographics.map((demo, index) => (
                        <span key={index} className="bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs">
                          {demo}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <span className="text-white/70 text-sm">Interests:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {strategy.ads.targetingCriteria.interests.map((interest, index) => (
                        <span key={index} className="bg-purple-500/20 text-purple-400 px-2 py-1 rounded text-xs">
                          {interest}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Email Strategy */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
              <Mail className="w-6 h-6 mr-3" />
              Email Marketing
            </h3>
            <div className="space-y-4">
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Lead Magnet</h4>
                <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
                  <p className="text-green-400 font-medium">{strategy.email.leadMagnet}</p>
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Subject Lines</h4>
                <ul className="space-y-1">
                  {strategy.email.subjectLines.map((subject, index) => (
                    <li key={index} className="text-white/80 text-sm">
                      <span className="text-[#0db2e9] mr-2">•</span>
                      {subject}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-white mb-2">Email Sequence</h4>
                <div className="space-y-2">
                  {strategy.email.emailSequence.map((email, index) => (
                    <div key={index} className="bg-white/10 p-3 rounded-lg">
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-white font-medium text-sm">{email.subject}</span>
                        <span className="text-[#0db2e9] text-xs">Day {email.sendDay}</span>
                      </div>
                      <p className="text-white/70 text-xs">{email.content.substring(0, 60)}...</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Customer Personas */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
        >
          <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
            <Users className="w-6 h-6 mr-3" />
            Customer Personas
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {strategy.personas.map((persona, index) => (
              <div key={index} className="bg-white/10 p-4 rounded-lg">
                <h4 className="text-lg font-semibold text-white mb-2">{persona.name}</h4>
                <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                  <div>
                    <span className="text-white/60">Age:</span>
                    <span className="text-white ml-2">{persona.age}</span>
                  </div>
                  <div>
                    <span className="text-white/60">Occupation:</span>
                    <span className="text-white ml-2">{persona.occupation}</span>
                  </div>
                  <div>
                    <span className="text-white/60">Income:</span>
                    <span className="text-white ml-2">{persona.income}</span>
                  </div>
                  <div>
                    <span className="text-white/60">Location:</span>
                    <span className="text-white ml-2">{persona.demographics.location}</span>
                  </div>
                </div>
                <div className="mb-3">
                  <h5 className="text-white font-medium mb-1 text-sm">Pain Points:</h5>
                  <div className="flex flex-wrap gap-1">
                    {persona.painPoints.map((pain, i) => (
                      <span key={i} className="bg-red-500/20 text-red-400 px-2 py-1 rounded text-xs">
                        {pain}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h5 className="text-white font-medium mb-1 text-sm">Goals:</h5>
                  <div className="flex flex-wrap gap-1">
                    {persona.goals.map((goal, i) => (
                      <span key={i} className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs">
                        {goal}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* KPI Targets */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
        >
          <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
            <Target className="w-6 h-6 mr-3" />
            KPI Targets
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {Object.entries(strategy.kpis).map(([kpi, target]) => (
              <div key={kpi} className="text-center">
                <div className="text-3xl font-bold text-[#0db2e9] mb-2">
                  {typeof target === 'number' ? target.toLocaleString() : target}
                  {kpi === 'roi' && '%'}
                </div>
                <div className="text-white/80 capitalize">{kpi.replace(/([A-Z])/g, ' $1')}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default StrategyResult;