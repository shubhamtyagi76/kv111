import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Target, TrendingUp, Users, DollarSign, Brain, ArrowRight, ArrowLeft } from 'lucide-react';
import { StrategyInput } from './types';

interface StrategyFormProps {
  onComplete: (input: StrategyInput) => void;
  onBack: () => void;
}

const StrategyForm: React.FC<StrategyFormProps> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<StrategyInput>({
    businessType: '',
    productService: '',
    targetAudience: '',
    monthlyBudget: 1000,
    platforms: [],
    strategyType: 'hybrid',
    industry: '',
    businessGoals: [],
    competitorAnalysis: ''
  });

  const steps = [
    {
      title: 'Business Overview',
      description: 'Tell us about your business',
      icon: <Target className="w-8 h-8" />
    },
    {
      title: 'Target Audience',
      description: 'Define your ideal customers',
      icon: <Users className="w-8 h-8" />
    },
    {
      title: 'Budget & Platforms',
      description: 'Set your budget and choose platforms',
      icon: <DollarSign className="w-8 h-8" />
    },
    {
      title: 'Strategy Type',
      description: 'Choose your marketing approach',
      icon: <TrendingUp className="w-8 h-8" />
    }
  ];

  const businessTypes = [
    'E-commerce', 'SaaS', 'Consulting', 'Agency', 'Local Business',
    'B2B Services', 'Education', 'Healthcare', 'Real Estate', 'Other'
  ];

  const industries = [
    'Technology', 'Healthcare', 'Finance', 'E-commerce', 'Education', 'Real Estate',
    'Food & Beverage', 'Fashion', 'Fitness', 'Consulting', 'Manufacturing', 'Other'
  ];

  const platforms = [
    'Instagram', 'Facebook', 'LinkedIn', 'YouTube', 'TikTok', 'Twitter',
    'Google Ads', 'Pinterest', 'Snapchat', 'Website/Blog'
  ];

  const businessGoals = [
    'Increase brand awareness', 'Generate leads', 'Drive sales', 'Build community',
    'Educate customers', 'Launch new product', 'Expand market reach', 'Improve customer retention'
  ];

  const handleInputChange = (field: keyof StrategyInput, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field: 'platforms' | 'businessGoals', value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return formData.businessType && formData.productService.length > 10 && formData.industry;
      case 1:
        return formData.targetAudience.length > 10;
      case 2:
        return formData.platforms.length > 0 && formData.monthlyBudget > 0;
      case 3:
        return formData.businessGoals.length > 0;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(formData);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      onBack();
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                What type of business do you have?
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {businessTypes.map((type) => (
                  <button
                    key={type}
                    onClick={() => handleInputChange('businessType', type)}
                    className={`p-3 rounded-lg border transition-all ${
                      formData.businessType === type
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Which industry best describes your business?
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {industries.map((industry) => (
                  <button
                    key={industry}
                    onClick={() => handleInputChange('industry', industry)}
                    className={`p-3 rounded-lg border transition-all ${
                      formData.industry === industry
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {industry}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Describe your product or service in detail
              </label>
              <textarea
                value={formData.productService}
                onChange={(e) => handleInputChange('productService', e.target.value)}
                placeholder="e.g., We offer AI-powered digital marketing automation tools that help small businesses create, schedule, and optimize their social media campaigns..."
                className="w-full h-40 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>
          </motion.div>
        );

      case 1:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Define your target audience in detail
              </label>
              <textarea
                value={formData.targetAudience}
                onChange={(e) => handleInputChange('targetAudience', e.target.value)}
                placeholder="e.g., Small business owners aged 25-45, primarily in service industries, who are tech-savvy but time-constrained. They have annual revenues of $100k-$1M and are looking to scale their marketing efforts without hiring a full team..."
                className="w-full h-40 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Competitor Analysis (Optional)
              </label>
              <textarea
                value={formData.competitorAnalysis || ''}
                onChange={(e) => handleInputChange('competitorAnalysis', e.target.value)}
                placeholder="Describe your main competitors and what makes you different..."
                className="w-full h-32 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your preferred marketing platforms
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {platforms.map((platform) => (
                  <button
                    key={platform}
                    onClick={() => handleArrayToggle('platforms', platform)}
                    className={`p-3 rounded-lg border transition-all ${
                      formData.platforms.includes(platform)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {platform}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Monthly Marketing Budget: ${formData.monthlyBudget.toLocaleString()}
              </label>
              <input
                type="range"
                min="100"
                max="50000"
                step="100"
                value={formData.monthlyBudget}
                onChange={(e) => handleInputChange('monthlyBudget', parseInt(e.target.value))}
                className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-white/60 text-sm mt-2">
                <span>$100</span>
                <span>$50,000+</span>
              </div>
            </div>
          </motion.div>
        );

      case 3:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your marketing strategy type
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { value: 'organic', label: 'Organic', desc: 'Focus on content marketing, SEO, and organic social media growth' },
                  { value: 'paid', label: 'Paid', desc: 'Emphasis on paid advertising across platforms for quick results' },
                  { value: 'hybrid', label: 'Hybrid', desc: 'Balanced approach combining organic and paid strategies' }
                ].map((strategy) => (
                  <button
                    key={strategy.value}
                    onClick={() => handleInputChange('strategyType', strategy.value)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      formData.strategyType === strategy.value
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold text-lg">{strategy.label}</div>
                    <div className="text-sm opacity-70 mt-2">{strategy.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your business goals (choose all that apply)
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {businessGoals.map((goal) => (
                  <button
                    key={goal}
                    onClick={() => handleArrayToggle('businessGoals', goal)}
                    className={`p-3 rounded-lg border transition-all text-left ${
                      formData.businessGoals.includes(goal)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#0db2e9] mb-4">AI Marketing Strategy Generator</h1>
          <p className="text-white/80 text-lg">
            Get a comprehensive, AI-powered marketing strategy tailored to your business
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <span className="text-white/80">Step {currentStep + 1} of {steps.length}</span>
            <span className="text-white/80">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-3 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-8 mb-8">
          <div className="flex items-center mb-6">
            <div className="text-[#0db2e9] mr-4">
              {steps[currentStep].icon}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {steps[currentStep].title}
              </h2>
              <p className="text-white/70">
                {steps[currentStep].description}
              </p>
            </div>
          </div>

          {renderStep()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            className="flex items-center px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all duration-200"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            {currentStep === 0 ? 'Back to Home' : 'Previous'}
          </button>

          {currentStep === steps.length - 1 ? (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center px-8 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              <Brain className="w-5 h-5 mr-2" />
              Generate Strategy
            </button>
          ) : (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center px-6 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              Next
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default StrategyForm;