export interface Campaign {
  id: string;
  name: string;
  type: 'post' | 'ad' | 'email' | 'story' | 'sequence';
  platforms: string[];
  content: CampaignContent[];
  schedule: CampaignSchedule;
  targeting: CampaignTargeting;
  budget?: number;
  status: 'draft' | 'scheduled' | 'active' | 'paused' | 'completed';
  performance: CampaignPerformance;
  createdAt: string;
  updatedAt: string;
}

export interface CampaignContent {
  id: string;
  type: 'text' | 'image' | 'video' | 'carousel';
  title: string;
  content: string;
  mediaUrl?: string;
  thumbnailUrl?: string;
  duration?: number;
  order: number;
}

export interface CampaignSchedule {
  type: 'immediate' | 'scheduled' | 'recurring';
  startDate: string;
  endDate?: string;
  frequency?: 'daily' | 'weekly' | 'monthly';
  times: string[];
  timezone: string;
  daysOfWeek?: number[]; // 0-6, Sunday = 0
  daysOfMonth?: number[]; // 1-31
}

export interface CampaignTargeting {
  demographics: {
    age: string;
    gender: string;
    location: string[];
    interests: string[];
  };
  behaviors: string[];
  customAudiences: string[];
  lookalikeSources?: string[];
}

export interface CampaignPerformance {
  reach: number;
  impressions: number;
  clicks: number;
  ctr: number;
  cpc: number;
  cpl: number;
  conversions: number;
  roi: number;
  engagement: {
    likes: number;
    comments: number;
    shares: number;
    saves: number;
  };
  platformBreakdown?: Record<string, Partial<CampaignPerformance>>;
}

export interface AnalyticsData {
  campaignId: string;
  platform: string;
  metrics: {
    [key: string]: number;
  };
  timeframe: string;
  lastUpdated: string;
}

export interface AIRecommendation {
  id: string;
  type: 'optimization' | 'content' | 'timing' | 'budget' | 'targeting';
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  effort: 'easy' | 'moderate' | 'complex';
  expectedImprovement: string;
  actionItems: string[];
  campaignId?: string;
}

export interface CalendarEvent {
  id: string;
  campaignId: string;
  title: string;
  description: string;
  start: Date;
  end: Date;
  type: 'post' | 'ad' | 'email' | 'story';
  platform: string;
  status: 'scheduled' | 'published' | 'failed';
  color?: string;
}

export interface PlatformConfig {
  id: string;
  name: string;
  connected: boolean;
  apiKey?: string;
  accessToken?: string;
  refreshToken?: string;
  expiresAt?: string;
  permissions: string[];
  rateLimits: {
    postsPerDay: number;
    postsPerHour: number;
  };
}