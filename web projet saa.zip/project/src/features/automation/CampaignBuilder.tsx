import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, Clock, Target, Users, DollarSign, 
  ArrowLeft, ArrowRight, Plus, Trash2, Settings 
} from 'lucide-react';
import { Campaign, CampaignSchedule, CampaignTargeting } from './types';

interface CampaignBuilderProps {
  onComplete: (campaign: Partial<Campaign>) => void;
  onBack: () => void;
}

const CampaignBuilder: React.FC<CampaignBuilderProps> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [campaignData, setCampaignData] = useState<Partial<Campaign>>({
    name: '',
    type: 'post',
    platforms: [],
    content: [],
    schedule: {
      type: 'scheduled',
      startDate: new Date().toISOString().split('T')[0],
      times: ['09:00'],
      timezone: 'UTC'
    },
    targeting: {
      demographics: {
        age: '18-65',
        gender: 'all',
        location: [],
        interests: []
      },
      behaviors: [],
      customAudiences: []
    },
    budget: 1000
  });

  const steps = [
    {
      title: 'Campaign Basics',
      description: 'Set up your campaign details',
      icon: <Target className="w-8 h-8" />
    },
    {
      title: 'Platform Selection',
      description: 'Choose where to publish',
      icon: <Settings className="w-8 h-8" />
    },
    {
      title: 'Schedule & Timing',
      description: 'When to publish your content',
      icon: <Calendar className="w-8 h-8" />
    },
    {
      title: 'Audience Targeting',
      description: 'Define your target audience',
      icon: <Users className="w-8 h-8" />
    },
    {
      title: 'Budget & Goals',
      description: 'Set budget and objectives',
      icon: <DollarSign className="w-8 h-8" />
    }
  ];

  const campaignTypes = [
    { value: 'post', label: 'Social Post', desc: 'Regular social media posts' },
    { value: 'ad', label: 'Advertisement', desc: 'Paid advertising campaigns' },
    { value: 'email', label: 'Email Campaign', desc: 'Email marketing sequences' },
    { value: 'story', label: 'Story Campaign', desc: 'Instagram/Facebook stories' },
    { value: 'sequence', label: 'Content Sequence', desc: 'Multi-part content series' }
  ];

  const platforms = [
    { id: 'instagram', name: 'Instagram', icon: '📷', connected: true },
    { id: 'facebook', name: 'Facebook', icon: '📘', connected: true },
    { id: 'linkedin', name: 'LinkedIn', icon: '💼', connected: false },
    { id: 'youtube', name: 'YouTube', icon: '📺', connected: false },
    { id: 'tiktok', name: 'TikTok', icon: '🎵', connected: false },
    { id: 'twitter', name: 'Twitter', icon: '🐦', connected: false }
  ];

  const timezones = [
    'UTC', 'America/New_York', 'America/Los_Angeles', 'Europe/London', 
    'Europe/Paris', 'Asia/Tokyo', 'Asia/Shanghai', 'Australia/Sydney'
  ];

  const interests = [
    'Technology', 'Business', 'Marketing', 'Fitness', 'Travel', 'Food',
    'Fashion', 'Sports', 'Music', 'Art', 'Education', 'Health'
  ];

  const behaviors = [
    'Frequent online shoppers', 'Tech early adopters', 'Business decision makers',
    'Social media power users', 'Mobile-first users', 'Video content consumers'
  ];

  const handleInputChange = (field: string, value: any) => {
    setCampaignData(prev => ({ ...prev, [field]: value }));
  };

  const handleScheduleChange = (field: keyof CampaignSchedule, value: any) => {
    setCampaignData(prev => ({
      ...prev,
      schedule: { ...prev.schedule!, [field]: value }
    }));
  };

  const handleTargetingChange = (field: string, value: any) => {
    setCampaignData(prev => ({
      ...prev,
      targeting: { ...prev.targeting!, [field]: value }
    }));
  };

  const handleDemographicsChange = (field: string, value: any) => {
    setCampaignData(prev => ({
      ...prev,
      targeting: {
        ...prev.targeting!,
        demographics: { ...prev.targeting!.demographics, [field]: value }
      }
    }));
  };

  const handleArrayToggle = (field: string, value: string, isNested = false, parentField?: string) => {
    if (isNested && parentField) {
      setCampaignData(prev => {
        const currentArray = (prev.targeting as any)[parentField][field] || [];
        return {
          ...prev,
          targeting: {
            ...prev.targeting!,
            [parentField]: {
              ...(prev.targeting as any)[parentField],
              [field]: currentArray.includes(value)
                ? currentArray.filter((item: string) => item !== value)
                : [...currentArray, value]
            }
          }
        };
      });
    } else {
      setCampaignData(prev => {
        const currentArray = (prev as any)[field] || [];
        return {
          ...prev,
          [field]: currentArray.includes(value)
            ? currentArray.filter((item: string) => item !== value)
            : [...currentArray, value]
        };
      });
    }
  };

  const addTime = () => {
    const newTime = '12:00';
    handleScheduleChange('times', [...(campaignData.schedule?.times || []), newTime]);
  };

  const removeTime = (index: number) => {
    const times = campaignData.schedule?.times || [];
    handleScheduleChange('times', times.filter((_, i) => i !== index));
  };

  const updateTime = (index: number, time: string) => {
    const times = [...(campaignData.schedule?.times || [])];
    times[index] = time;
    handleScheduleChange('times', times);
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return campaignData.name && campaignData.type;
      case 1:
        return campaignData.platforms && campaignData.platforms.length > 0;
      case 2:
        return campaignData.schedule?.startDate && campaignData.schedule?.times?.length > 0;
      case 3:
        return true; // Targeting is optional
      case 4:
        return campaignData.budget && campaignData.budget > 0;
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete(campaignData);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      onBack();
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Campaign Name
              </label>
              <input
                type="text"
                value={campaignData.name || ''}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter campaign name..."
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
              />
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Campaign Type
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {campaignTypes.map((type) => (
                  <button
                    key={type.value}
                    onClick={() => handleInputChange('type', type.value)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      campaignData.type === type.value
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold text-lg">{type.label}</div>
                    <div className="text-sm opacity-70 mt-1">{type.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        );

      case 1:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select Platforms
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {platforms.map((platform) => (
                  <button
                    key={platform.id}
                    onClick={() => handleArrayToggle('platforms', platform.id)}
                    disabled={!platform.connected}
                    className={`p-4 rounded-xl border-2 transition-all text-left relative ${
                      campaignData.platforms?.includes(platform.id)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : platform.connected
                        ? 'bg-white/5 border-white/20 text-white hover:border-white/40'
                        : 'bg-white/5 border-white/10 text-white/40 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{platform.icon}</span>
                      <div>
                        <div className="font-semibold">{platform.name}</div>
                        <div className="text-xs">
                          {platform.connected ? 'Connected' : 'Not Connected'}
                        </div>
                      </div>
                    </div>
                    {!platform.connected && (
                      <div className="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full"></div>
                    )}
                  </button>
                ))}
              </div>
              <p className="text-white/60 text-sm mt-4">
                Connect platforms in Settings to enable publishing
              </p>
            </div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Schedule Type
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { value: 'immediate', label: 'Immediate', desc: 'Publish right away' },
                  { value: 'scheduled', label: 'Scheduled', desc: 'Publish at specific time' },
                  { value: 'recurring', label: 'Recurring', desc: 'Repeat on schedule' }
                ].map((type) => (
                  <button
                    key={type.value}
                    onClick={() => handleScheduleChange('type', type.value)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      campaignData.schedule?.type === type.value
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold">{type.label}</div>
                    <div className="text-sm opacity-70 mt-1">{type.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {campaignData.schedule?.type !== 'immediate' && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={campaignData.schedule?.startDate || ''}
                      onChange={(e) => handleScheduleChange('startDate', e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">
                      Timezone
                    </label>
                    <select
                      value={campaignData.schedule?.timezone || 'UTC'}
                      onChange={(e) => handleScheduleChange('timezone', e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    >
                      {timezones.map(tz => (
                        <option key={tz} value={tz} className="bg-gray-800">{tz}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-4">
                    <label className="text-white text-lg font-semibold">
                      Publishing Times
                    </label>
                    <button
                      onClick={addTime}
                      className="bg-[#0db2e9] hover:bg-[#0aa3d1] text-white px-3 py-1 rounded-lg text-sm flex items-center"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add Time
                    </button>
                  </div>
                  <div className="space-y-3">
                    {campaignData.schedule?.times?.map((time, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <input
                          type="time"
                          value={time}
                          onChange={(e) => updateTime(index, e.target.value)}
                          className="px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                        />
                        {campaignData.schedule!.times!.length > 1 && (
                          <button
                            onClick={() => removeTime(index)}
                            className="text-red-400 hover:text-red-300 p-2"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {campaignData.schedule?.type === 'recurring' && (
                  <div>
                    <label className="block text-white text-lg font-semibold mb-4">
                      Frequency
                    </label>
                    <select
                      value={campaignData.schedule?.frequency || 'weekly'}
                      onChange={(e) => handleScheduleChange('frequency', e.target.value)}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    >
                      <option value="daily" className="bg-gray-800">Daily</option>
                      <option value="weekly" className="bg-gray-800">Weekly</option>
                      <option value="monthly" className="bg-gray-800">Monthly</option>
                    </select>
                  </div>
                )}
              </>
            )}
          </motion.div>
        );

      case 3:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-white text-lg font-semibold mb-4">
                  Age Range
                </label>
                <select
                  value={campaignData.targeting?.demographics.age || '18-65'}
                  onChange={(e) => handleDemographicsChange('age', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                >
                  <option value="18-24" className="bg-gray-800">18-24</option>
                  <option value="25-34" className="bg-gray-800">25-34</option>
                  <option value="35-44" className="bg-gray-800">35-44</option>
                  <option value="45-54" className="bg-gray-800">45-54</option>
                  <option value="55-64" className="bg-gray-800">55-64</option>
                  <option value="18-65" className="bg-gray-800">All Adults</option>
                </select>
              </div>
              
              <div>
                <label className="block text-white text-lg font-semibold mb-4">
                  Gender
                </label>
                <select
                  value={campaignData.targeting?.demographics.gender || 'all'}
                  onChange={(e) => handleDemographicsChange('gender', e.target.value)}
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                >
                  <option value="all" className="bg-gray-800">All</option>
                  <option value="male" className="bg-gray-800">Male</option>
                  <option value="female" className="bg-gray-800">Female</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Interests
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {interests.map((interest) => (
                  <button
                    key={interest}
                    onClick={() => handleArrayToggle('interests', interest, true, 'demographics')}
                    className={`p-3 rounded-lg border transition-all text-sm ${
                      campaignData.targeting?.demographics.interests?.includes(interest)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {interest}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Behaviors
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {behaviors.map((behavior) => (
                  <button
                    key={behavior}
                    onClick={() => handleArrayToggle('behaviors', behavior, false)}
                    className={`p-3 rounded-lg border transition-all text-sm text-left ${
                      campaignData.targeting?.behaviors?.includes(behavior)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {behavior}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        );

      case 4:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Campaign Budget: ${campaignData.budget?.toLocaleString() || '0'}
              </label>
              <input
                type="range"
                min="100"
                max="50000"
                step="100"
                value={campaignData.budget || 1000}
                onChange={(e) => handleInputChange('budget', parseInt(e.target.value))}
                className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-white/60 text-sm mt-2">
                <span>$100</span>
                <span>$50,000+</span>
              </div>
            </div>

            <div className="bg-white/5 p-6 rounded-xl">
              <h4 className="text-lg font-semibold text-white mb-4">Campaign Summary</h4>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-white/70">Name:</span>
                  <span className="text-white">{campaignData.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/70">Type:</span>
                  <span className="text-white capitalize">{campaignData.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/70">Platforms:</span>
                  <span className="text-white">{campaignData.platforms?.length || 0} selected</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/70">Schedule:</span>
                  <span className="text-white capitalize">{campaignData.schedule?.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/70">Budget:</span>
                  <span className="text-white">${campaignData.budget?.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#0db2e9] mb-4">Campaign Builder</h1>
          <p className="text-white/80 text-lg">
            Create and schedule your marketing campaigns
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <span className="text-white/80">Step {currentStep + 1} of {steps.length}</span>
            <span className="text-white/80">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-3 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-8 mb-8">
          <div className="flex items-center mb-6">
            <div className="text-[#0db2e9] mr-4">
              {steps[currentStep].icon}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {steps[currentStep].title}
              </h2>
              <p className="text-white/70">
                {steps[currentStep].description}
              </p>
            </div>
          </div>

          {renderStep()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={handleBack}
            className="flex items-center px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all duration-200"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            {currentStep === 0 ? 'Back to Home' : 'Previous'}
          </button>

          {currentStep === steps.length - 1 ? (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center px-8 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              Create Campaign
            </button>
          ) : (
            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center px-6 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              Next
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CampaignBuilder;