import React, { useState, useEffect } from 'react';
import { Users, Globe, TrendingUp, Mail, Phone, Calendar, DollarSign, Eye } from 'lucide-react';
import { getBusinessInquiries } from '../lib/supabase';
import { motion } from 'framer-motion';

interface BusinessInquiry {
  id: string;
  business_name: string;
  business_idea: string;
  niche: string;
  industry: string;
  contact_email: string;
  contact_phone?: string;
  budget: string;
  timeline: string;
  status: string;
  website_generated: boolean;
  created_at: string;
}

const AdminDashboard: React.FC = () => {
  const [inquiries, setInquiries] = useState<BusinessInquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInquiry, setSelectedInquiry] = useState<BusinessInquiry | null>(null);

  useEffect(() => {
    loadInquiries();
  }, []);

  const loadInquiries = async () => {
    setLoading(true);
    const result = await getBusinessInquiries();
    if (result.success) {
      setInquiries(result.data || []);
    }
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'inquiry': return 'bg-yellow-500';
      case 'in_progress': return 'bg-blue-500';
      case 'completed': return 'bg-green-500';
      case 'cancelled': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const stats = {
    total: inquiries.length,
    websitesGenerated: inquiries.filter(i => i.website_generated).length,
    inProgress: inquiries.filter(i => i.status === 'in_progress').length,
    completed: inquiries.filter(i => i.status === 'completed').length
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] rounded-full flex items-center justify-center mx-auto mb-4 animate-spin">
            <Globe className="w-8 h-8 text-black" />
          </div>
          <p className="text-white/80">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#0db2e9] mb-2">Vyomexa.ai™ Admin Dashboard</h1>
          <p className="text-white/80 text-sm sm:text-base">Manage business inquiries and website generations</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/10 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-white/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-xs sm:text-sm">Total Inquiries</p>
                <p className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{stats.total}</p>
              </div>
              <Users className="w-6 sm:w-8 h-6 sm:h-8 text-[#0db2e9]" />
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/10 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-white/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-xs sm:text-sm">Websites Generated</p>
                <p className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{stats.websitesGenerated}</p>
              </div>
              <Globe className="w-6 sm:w-8 h-6 sm:h-8 text-green-500" />
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/10 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-white/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-xs sm:text-sm">In Progress</p>
                <p className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{stats.inProgress}</p>
              </div>
              <TrendingUp className="w-6 sm:w-8 h-6 sm:h-8 text-blue-500" />
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/10 backdrop-blur-sm p-4 sm:p-6 rounded-xl border border-white/20"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-xs sm:text-sm">Completed</p>
                <p className="text-xl sm:text-2xl md:text-3xl font-bold text-white">{stats.completed}</p>
              </div>
              <TrendingUp className="w-6 sm:w-8 h-6 sm:h-8 text-green-500" />
            </div>
          </motion.div>
        </div>

        {/* Inquiries Table */}
        <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden">
          <div className="p-4 sm:p-6 border-b border-white/10">
            <h2 className="text-xl sm:text-2xl font-bold text-white">Recent Business Inquiries</h2>
          </div>
          
          <div className="overflow-x-auto min-w-full">
            <table className="w-full min-w-[800px]">
              <thead className="bg-white/5">
                <tr>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Business</th>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Industry</th>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Contact</th>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Budget</th>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Status</th>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Date</th>
                  <th className="text-left p-3 sm:p-4 text-white/80 font-semibold text-xs sm:text-sm">Actions</th>
                </tr>
              </thead>
              <tbody>
                {inquiries.map((inquiry, index) => (
                  <motion.tr 
                    key={inquiry.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-b border-white/10 hover:bg-white/5"
                  >
                    <td className="p-3 sm:p-4">
                      <div>
                        <p className="text-white font-semibold text-xs sm:text-sm">{inquiry.business_name}</p>
                        <p className="text-white/60 text-xs">{inquiry.niche}</p>
                      </div>
                    </td>
                    <td className="p-3 sm:p-4 text-white/80 text-xs sm:text-sm">{inquiry.industry}</td>
                    <td className="p-3 sm:p-4">
                      <div className="space-y-1 text-xs sm:text-sm">
                        <div className="flex items-center text-white/80">
                          <Mail className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                          {inquiry.contact_email}
                        </div>
                        {inquiry.contact_phone && (
                          <div className="flex items-center text-white/80">
                            <Phone className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2 flex-shrink-0" />
                            {inquiry.contact_phone}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="p-3 sm:p-4 text-white/80 text-xs sm:text-sm">{inquiry.budget}</td>
                    <td className="p-3 sm:p-4">
                      <div className="flex items-center">
                        <div className={`w-2 sm:w-3 h-2 sm:h-3 rounded-full ${getStatusColor(inquiry.status)} mr-1 sm:mr-2`}></div>
                        <span className="text-white/80 capitalize text-xs sm:text-sm">{inquiry.status.replace('_', ' ')}</span>
                        {inquiry.website_generated && (
                          <Globe className="w-3 sm:w-4 h-3 sm:h-4 ml-1 sm:ml-2 text-green-500" />
                        )}
                      </div>
                    </td>
                    <td className="p-3 sm:p-4 text-white/80 text-xs sm:text-sm">
                      {new Date(inquiry.created_at).toLocaleDateString()}
                    </td>
                    <td className="p-3 sm:p-4">
                      <button
                        onClick={() => setSelectedInquiry(inquiry)}
                        className="bg-[#0db2e9] hover:bg-[#0aa3d1] text-white px-2 sm:px-3 py-1 rounded-lg text-xs sm:text-sm flex items-center"
                      >
                        <Eye className="w-3 sm:w-4 h-3 sm:h-4 mr-1" />
                        View
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Inquiry Detail Modal */}
        {selectedInquiry && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-4 sm:p-6 border-b border-white/10">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-white pr-4">{selectedInquiry.business_name}</h3>
                  <button
                    onClick={() => setSelectedInquiry(null)}
                    className="text-white/60 hover:text-white text-xl sm:text-2xl p-2"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                  <div>
                    <h4 className="text-base sm:text-lg font-semibold text-[#0db2e9] mb-2 sm:mb-3">Business Details</h4>
                    <div className="space-y-1 sm:space-y-2 text-white/80 text-sm sm:text-base">
                      <p><strong>Industry:</strong> {selectedInquiry.industry}</p>
                      <p><strong>Niche:</strong> {selectedInquiry.niche}</p>
                      <p><strong>Budget:</strong> {selectedInquiry.budget}</p>
                      <p><strong>Timeline:</strong> {selectedInquiry.timeline}</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-base sm:text-lg font-semibold text-[#0db2e9] mb-2 sm:mb-3">Contact Information</h4>
                    <div className="space-y-1 sm:space-y-2 text-white/80 text-sm sm:text-base">
                      <p><strong>Email:</strong> {selectedInquiry.contact_email}</p>
                      {selectedInquiry.contact_phone && (
                        <p><strong>Phone:</strong> {selectedInquiry.contact_phone}</p>
                      )}
                      <p><strong>Status:</strong> {selectedInquiry.status}</p>
                      <p><strong>Website Generated:</strong> {selectedInquiry.website_generated ? 'Yes' : 'No'}</p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h4 className="text-base sm:text-lg font-semibold text-[#0db2e9] mb-2 sm:mb-3">Business Idea</h4>
                  <p className="text-white/80 leading-relaxed text-sm sm:text-base">{selectedInquiry.business_idea}</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;