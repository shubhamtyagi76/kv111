import React, { useState, useEffect } from 'react';
import { Sparkles, Zap, Globe, TrendingUp, ArrowRight, Play, CheckCircle, Phone, MessageCircle } from 'lucide-react';

interface LandingPageProps {
  onStartJourney: () => void;
  onNavigateToStrategy: () => void;
  onNavigateToMedia: () => void;
  onNavigateToCampaigns: () => void;
  onNavigateToAnalytics: () => void;
  onNavigateToAdmin: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ 
  onStartJourney, 
  onNavigateToStrategy, 
  onNavigateToMedia, 
  onNavigateToCampaigns, 
  onNavigateToAnalytics,
  onNavigateToAdmin 
}) => {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const searchSuggestions = [
    'Web Development Services',
    'SEO & Content Marketing',
    'AI-Powered Business Solutions',
    'Social Media Management',
    'E-commerce Development',
    'Brand Identity Design',
    'Marketing Strategy Generator',
    'AI Content Creation',
    'Campaign Management'
  ];

  const services = [
    {
      icon: <Globe className="w-8 h-8" />,
      title: 'AI Website Builder',
      description: 'Responsive, fast-loading websites designed to drive your brand online with AI automation.',
      action: onStartJourney
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Marketing Strategy Generator',
      description: 'AI-powered marketing strategies with SEO, SMM, and advertising plans tailored to your business.',
      action: onNavigateToStrategy
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: 'AI Media Creation Studio',
      description: 'Generate videos, graphics, blogs, and voiceovers with emotion-enabled AI technology.',
      action: onNavigateToMedia
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: 'Campaign Automation',
      description: 'Schedule, deploy, and monitor campaigns across platforms with real-time analytics.',
      action: onNavigateToCampaigns
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: 'E-Commerce Management',
      description: 'We handle your product listings, sales strategies, and automated online stores.',
      action: onStartJourney
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: 'Social Media Marketing',
      description: 'AI-powered campaigns and management to build engagement and grow followers.',
      action: onNavigateToMedia
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      role: 'Fitness Coach',
      image: 'https://images.pexels.com/photos/3768911/pexels-photo-3768911.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      content: 'Vyomexa.ai built my entire fitness coaching business in one afternoon. The AI understood exactly what I needed!'
    },
    {
      name: 'Michael Chen',
      role: 'Digital Marketer',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      content: 'This platform replaced my entire marketing team. The content quality is incredible and saves me 20+ hours per week.'
    },
    {
      name: 'Emily Rodriguez',
      role: 'E-commerce Owner',
      image: 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop',
      content: 'From business idea to profitable online store in 48 hours. The AI marketing campaigns are generating real sales!'
    }
  ];

  // Animated background effect
  useEffect(() => {
    const canvas = document.getElementById('bg-canvas') as HTMLCanvasElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      dx: number;
      dy: number;
      size: number;
      opacity: number;
    }> = [];

    // Create particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        dx: (Math.random() - 0.5) * 0.5,
        dy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.2
      });
    }

    function animate() {
      if (!ctx || !canvas) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        particle.x += particle.dx;
        particle.y += particle.dy;
        
        if (particle.x < 0 || particle.x > canvas.width) particle.dx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.dy *= -1;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(13, 178, 233, ${particle.opacity})`;
        ctx.fill();
      });
      
      requestAnimationFrame(animate);
    }
    
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    // Handle device orientation changes
    const handleOrientationChange = () => {
      setTimeout(() => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }, 100);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
    };
  }, []);

  const filteredSuggestions = searchSuggestions.filter(suggestion =>
    suggestion.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-black text-white relative overflow-x-hidden">
      {/* Animated Background Canvas */}
      <canvas 
        id="bg-canvas" 
        className="fixed top-0 left-0 w-full h-full z-0 pointer-events-none"
      />

      {/* Header Branding */}
      <header className="relative z-10 text-center py-4 sm:py-5 bg-black/60 backdrop-blur-sm">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-[#0db2e9] mb-2">Vyomexa.ai™</h1>
        <p className="text-[#b2fefa] text-sm sm:text-base md:text-lg px-4">Your One-Stop Digital Marketing Partner</p>
      </header>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-black/80 backdrop-blur-lg border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-14 sm:h-16">
            <div className="text-lg sm:text-xl md:text-2xl font-bold text-[#0db2e9]">Vyomexa.ai™</div>
            
            {/* Mobile menu button */}
            <button 
              className="md:hidden text-white text-xl p-2 rounded-lg hover:bg-white/10 transition-colors"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <i className={`fas ${mobileMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
            </button>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-4 lg:space-x-8">
              <a href="#home" className="text-white/80 hover:text-white transition-colors relative group">
                Home
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0db2e9] transition-all duration-300 group-hover:w-full"></span>
              </a>
              <a href="#services" className="text-white/80 hover:text-white transition-colors relative group">
                Our Services
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0db2e9] transition-all duration-300 group-hover:w-full"></span>
              </a>
              <a href="#about" className="text-white/80 hover:text-white transition-colors relative group">
                About Us
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0db2e9] transition-all duration-300 group-hover:w-full"></span>
              </a>
              <a href="#testimonials" className="text-white/80 hover:text-white transition-colors relative group">
                Our Clients
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0db2e9] transition-all duration-300 group-hover:w-full"></span>
              </a>
              <a href="#contact" className="text-white/80 hover:text-white transition-colors relative group">
                Contact Us
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#0db2e9] transition-all duration-300 group-hover:w-full"></span>
              </a>
            </nav>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <div className="md:hidden fixed inset-0 bg-black/95 backdrop-blur-lg z-50 flex flex-col items-center justify-center safe-area-inset">
              <button 
                className="absolute top-4 right-4 sm:top-5 sm:right-5 text-white text-2xl p-2 rounded-lg hover:bg-white/10 transition-colors"
                onClick={() => setMobileMenuOpen(false)}
              >
                <i className="fas fa-times"></i>
              </button>
              <nav className="flex flex-col space-y-6 sm:space-y-8 text-center px-4">
                <a href="#home" className="text-white text-lg sm:text-xl hover:text-[#0db2e9] transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>Home</a>
                <a href="#services" className="text-white text-lg sm:text-xl hover:text-[#0db2e9] transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>Our Services</a>
                <a href="#about" className="text-white text-lg sm:text-xl hover:text-[#0db2e9] transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>About Us</a>
                <a href="#testimonials" className="text-white text-lg sm:text-xl hover:text-[#0db2e9] transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>Our Clients</a>
                <a href="#contact" className="text-white text-lg sm:text-xl hover:text-[#0db2e9] transition-colors py-2" onClick={() => setMobileMenuOpen(false)}>Contact Us</a>
              </nav>
            </div>
          )}
        </div>
      </nav>

      {/* Search Box */}
      <div className="relative z-10 max-w-2xl mx-auto px-4 py-6 sm:py-8">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSuggestions(e.target.value.length > 0);
            }}
            onFocus={() => setShowSuggestions(searchQuery.length > 0)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
            placeholder="How may I help you?"
            className="w-full px-4 sm:px-6 py-3 sm:py-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent text-sm sm:text-base"
          />
          
          {showSuggestions && filteredSuggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-black/90 backdrop-blur-sm border border-white/20 rounded-xl overflow-hidden max-h-60 overflow-y-auto">
              {filteredSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  className="w-full px-4 sm:px-6 py-3 text-left text-white/80 hover:text-white hover:bg-white/10 transition-colors text-sm sm:text-base"
                  onClick={() => {
                    setSearchQuery(suggestion);
                    setShowSuggestions(false);
                  }}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}
          
          {/* Quick Access Navigation */}
          <div className="mt-12 sm:mt-16 text-center">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-6 sm:mb-8">Quick Access</h3>
            <div className="flex flex-wrap justify-center gap-3 sm:gap-4">
              <button
                onClick={onNavigateToStrategy}
                className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium transition-all duration-200 text-sm sm:text-base"
              >
                Strategy Generator
              </button>
              <button
                onClick={onNavigateToMedia}
                className="bg-white/10 hover:bg-white/20 text-white px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium transition-all duration-200 text-sm sm:text-base"
              >
                Media Studio
              </button>
              <button
                onClick={onNavigateToCampaigns}
                className="bg-white/10 hover:bg-white/20 text-white px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium transition-all duration-200 text-sm sm:text-base"
              >
                Campaign Manager
              </button>
              <button
                onClick={onNavigateToAdmin}
                className="bg-red-500/20 hover:bg-red-500/30 text-red-400 px-4 sm:px-6 py-2 sm:py-3 rounded-lg font-medium transition-all duration-200 text-sm sm:text-base"
              >
                Admin Dashboard
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section id="home" className="relative z-10 pt-8 sm:pt-12 pb-16 sm:pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center px-3 sm:px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6 sm:mb-8">
            <Sparkles className="w-3 sm:w-4 h-3 sm:h-4 text-[#0db2e9] mr-2" />
            <span className="text-white/90 text-xs sm:text-sm">AI-Powered Business Automation Platform</span>
          </div>
          
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-white mb-4 sm:mb-6 leading-tight px-2">
            Build Your Digital
            <br />
            <span className="bg-gradient-to-r from-[#0db2e9] via-[#b2fefa] to-[#0db2e9] bg-clip-text text-transparent">
              Business Empire
            </span>
          </h1>
          
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-white/80 mb-6 sm:mb-8 max-w-3xl mx-auto leading-relaxed px-4">
            Turn any business idea into a complete digital presence with AI. Website, marketing, content, and automation - all in one platform.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-center mb-12 sm:mb-16 px-4">
            <button 
              onClick={onStartJourney}
              className="group bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold transition-all duration-200 transform hover:scale-105 flex items-center text-sm sm:text-base w-full sm:w-auto justify-center"
            >
              Start My Business
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <button 
              onClick={() => setIsVideoPlaying(true)}
              className="group bg-white/10 hover:bg-white/20 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold transition-all duration-200 backdrop-blur-sm flex items-center text-sm sm:text-base w-full sm:w-auto justify-center"
            >
              <Play className="mr-2 w-5 h-5 group-hover:scale-110 transition-transform" />
              Watch Demo
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 md:gap-8 text-center px-4">
            <div>
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-1 sm:mb-2">10,000+</div>
              <div className="text-white/70 text-xs sm:text-sm md:text-base">Websites Built</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-1 sm:mb-2">$2M+</div>
              <div className="text-white/70 text-xs sm:text-sm md:text-base">Revenue Generated</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-1 sm:mb-2">50+</div>
              <div className="text-white/70 text-xs sm:text-sm md:text-base">Industries Served</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl md:text-3xl font-bold text-white mb-1 sm:mb-2">99%</div>
              <div className="text-white/70 text-xs sm:text-sm md:text-base">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="relative z-10 py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0db2e9] mb-4 sm:mb-6">
              Our Digital Solutions
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-white/80 max-w-2xl mx-auto px-4">
              From idea to profit in one platform. No coding, no marketing team, no hassle.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {services.map((service, index) => (
              <button
                key={index}
                onClick={service.action}
                className="group bg-white/10 hover:bg-white/20 backdrop-blur-sm p-6 sm:p-8 rounded-2xl border border-white/20 hover:border-[#0db2e9]/50 transition-all duration-300 transform hover:scale-105 hover:-translate-y-2 text-left cursor-pointer"
              >
                <div className="text-[#0db2e9] mb-4 sm:mb-6 group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                <h3 className="text-lg sm:text-xl font-semibold text-white mb-3 sm:mb-4">{service.title}</h3>
                <p className="text-white/70 leading-relaxed text-sm sm:text-base">{service.description}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="relative z-10 py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0db2e9] mb-6 sm:mb-8">About Us</h2>
          <div className="text-sm sm:text-base md:text-lg text-white/80 leading-relaxed space-y-4 sm:space-y-6">
            <p>
              At <strong className="text-[#0db2e9]">Vyomexa.ai™</strong>, we are a results-driven digital marketing agency specializing in AI-powered web development, SEO services, content creation, branding, and e-commerce management. Our mission is to empower businesses of all sizes to thrive in the digital landscape through innovative automation and intelligent solutions.
            </p>
            <p>
              Whether you need a new website, better search rankings, automated content creation, or full digital transformation—<strong className="text-[#0db2e9]">Vyomexa.ai™</strong> is your trusted AI-powered partner for sustainable growth and success.
            </p>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="relative z-10 py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0db2e9] mb-4 sm:mb-6">
              Our Clients Success Stories
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-white/80 max-w-2xl mx-auto px-4">
              Real results from entrepreneurs who trusted AI to build their business
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm p-6 sm:p-8 rounded-2xl border border-white/20 hover:border-[#0db2e9]/50 transition-all duration-300">
                <div className="flex items-center mb-4 sm:mb-6">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-10 sm:w-12 h-10 sm:h-12 rounded-full object-cover mr-3 sm:mr-4"
                  />
                  <div>
                    <h4 className="text-white font-semibold text-sm sm:text-base">{testimonial.name}</h4>
                    <p className="text-white/70 text-xs sm:text-sm">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-white/80 leading-relaxed mb-3 sm:mb-4 text-sm sm:text-base">"{testimonial.content}"</p>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className="text-yellow-400 text-sm sm:text-base">⭐</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-r from-[#0db2e9]/20 to-[#b2fefa]/20 p-8 sm:p-12 rounded-3xl border border-white/20 backdrop-blur-sm">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6">
              Ready to Build Your Empire?
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-white/80 mb-6 sm:mb-8 max-w-2xl mx-auto">
              Join thousands of entrepreneurs who've transformed their ideas into profitable businesses with AI.
            </p>
            <button 
              onClick={onStartJourney}
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-8 sm:px-12 py-3 sm:py-4 rounded-xl font-semibold transition-all duration-200 transform hover:scale-105 text-base sm:text-lg w-full sm:w-auto"
            >
              Start Building Now - Free
            </button>
            <p className="text-white/60 mt-3 sm:mt-4 text-xs sm:text-sm">No credit card required • 7-day free trial</p>
          </div>
        </div>
      </section>

      {/* Floating Contact Icons */}
      <div className="fixed right-3 sm:right-5 bottom-20 sm:bottom-24 flex flex-col gap-3 sm:gap-4 z-50">
        <a
          href="tel:7891159369"
          className="bg-red-500 hover:bg-red-600 text-white p-3 sm:p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce"
          style={{ animationDelay: '0.5s' }}
        >
          <Phone className="w-5 sm:w-6 h-5 sm:h-6" />
        </a>
        <a
          href="https://wa.me/917891159369"
          className="bg-green-500 hover:bg-green-600 text-white p-3 sm:p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce"
        >
          <MessageCircle className="w-5 sm:w-6 h-5 sm:h-6" />
        </a>
      </div>

      {/* Footer */}
      <footer id="contact" className="relative z-10 bg-[#0f103f] border-t border-white/10 py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-6 sm:mb-8">
            <h3 className="text-[#0db2e9] text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">Vyomexa.ai™</h3>
            <p className="text-white/80 max-w-2xl mx-auto mb-4 sm:mb-6 text-sm sm:text-base">
              Empowering your digital success – AI-powered web development, SEO, branding & e-commerce, all under one roof.
            </p>
            
            {/* Contact Links */}
            <div className="flex justify-center flex-wrap gap-4 sm:gap-8 mb-6 sm:mb-8">
              <a href="mailto:vyomexa.ai@gmail.com" className="text-[#0db2e9] hover:text-[#b2fefa] transition-colors text-sm sm:text-base">
                vyomexa.ai@gmail.com
              </a>
              <a href="tel:+917891159369" className="text-[#0db2e9] hover:text-[#b2fefa] transition-colors text-sm sm:text-base">
                +91 78911 59369
              </a>
            </div>

            {/* Social Icons */}
            <div className="flex justify-center space-x-4 sm:space-x-6 mb-6 sm:mb-8">
              <a href="#" className="text-white hover:text-[#0db2e9] transition-colors text-lg sm:text-xl p-2">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-white hover:text-[#0db2e9] transition-colors text-lg sm:text-xl p-2">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-white hover:text-[#0db2e9] transition-colors text-lg sm:text-xl p-2">
                <i className="fab fa-linkedin-in"></i>
              </a>
              <a href="#" className="text-white hover:text-[#0db2e9] transition-colors text-lg sm:text-xl p-2">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-6 sm:pt-8 text-center text-white/60">
            <p className="text-xs sm:text-sm">&copy; 2025 <strong className="text-[#0db2e9]">Vyomexa.ai™</strong>. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;