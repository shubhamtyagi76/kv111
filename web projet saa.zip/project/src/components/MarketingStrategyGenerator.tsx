import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Target, TrendingUp, Users, DollarSign, Calendar, Brain, Download, Share2 } from 'lucide-react';
import { MarketingStrategyInput, MarketingStrategy } from '../types/marketing';
import { aiService } from '../services/aiService';
import toast from 'react-hot-toast';

interface MarketingStrategyGeneratorProps {
  onBack: () => void;
  onNavigateToMedia?: () => void;
}

const MarketingStrategyGenerator: React.FC<MarketingStrategyGeneratorProps> = ({ onBack, onNavigateToMedia }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedStrategy, setGeneratedStrategy] = useState<MarketingStrategy | null>(null);
  const [formData, setFormData] = useState<MarketingStrategyInput>({
    productService: '',
    targetAudience: '',
    platforms: [],
    monthlyBudget: 1000,
    strategyType: 'hybrid',
    businessGoals: [],
    industry: '',
    competitorAnalysis: ''
  });

  const steps = [
    {
      title: 'Business Overview',
      description: 'Tell us about your product or service',
      icon: <Target className="w-8 h-8" />
    },
    {
      title: 'Target Audience',
      description: 'Define your ideal customers',
      icon: <Users className="w-8 h-8" />
    },
    {
      title: 'Platforms & Budget',
      description: 'Choose platforms and set your budget',
      icon: <DollarSign className="w-8 h-8" />
    },
    {
      title: 'Strategy Type',
      description: 'Select your marketing approach',
      icon: <TrendingUp className="w-8 h-8" />
    }
  ];

  const platforms = [
    'Instagram', 'Facebook', 'LinkedIn', 'YouTube', 'TikTok', 'Twitter',
    'Google Ads', 'Pinterest', 'Snapchat', 'Website/Blog'
  ];

  const businessGoals = [
    'Increase brand awareness', 'Generate leads', 'Drive sales', 'Build community',
    'Educate customers', 'Launch new product', 'Expand market reach', 'Improve customer retention'
  ];

  const industries = [
    'Technology', 'Healthcare', 'Finance', 'E-commerce', 'Education', 'Real Estate',
    'Food & Beverage', 'Fashion', 'Fitness', 'Consulting', 'Manufacturing', 'Other'
  ];

  const handleInputChange = (field: keyof MarketingStrategyInput, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleArrayToggle = (field: 'platforms' | 'businessGoals', value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].includes(value)
        ? prev[field].filter(item => item !== value)
        : [...prev[field], value]
    }));
  };

  const generateStrategy = async () => {
    setIsGenerating(true);
    try {
      const strategy = await aiService.generateMarketingStrategy(formData);
      setGeneratedStrategy(strategy);
      toast.success('Marketing strategy generated successfully!');
    } catch (error) {
      toast.error('Failed to generate strategy. Please try again.');
      console.error('Strategy generation error:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const exportStrategy = () => {
    if (!generatedStrategy) return;
    
    const dataStr = JSON.stringify(generatedStrategy, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `marketing-strategy-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success('Strategy exported successfully!');
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return formData.productService.length > 10 && formData.industry.length > 0;
      case 1:
        return formData.targetAudience.length > 10;
      case 2:
        return formData.platforms.length > 0 && formData.monthlyBudget > 0;
      case 3:
        return formData.businessGoals.length > 0;
      default:
        return false;
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Describe your product or service in detail
              </label>
              <textarea
                value={formData.productService}
                onChange={(e) => handleInputChange('productService', e.target.value)}
                placeholder="e.g., We offer AI-powered digital marketing automation tools that help small businesses create, schedule, and optimize their social media campaigns..."
                className="w-full h-40 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>
            
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your industry
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {industries.map((industry) => (
                  <button
                    key={industry}
                    onClick={() => handleInputChange('industry', industry)}
                    className={`p-3 rounded-lg border transition-all ${
                      formData.industry === industry
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {industry}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Competitor Analysis (Optional)
              </label>
              <textarea
                value={formData.competitorAnalysis || ''}
                onChange={(e) => handleInputChange('competitorAnalysis', e.target.value)}
                placeholder="Describe your main competitors and what makes you different..."
                className="w-full h-32 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Define your target audience in detail
              </label>
              <textarea
                value={formData.targetAudience}
                onChange={(e) => handleInputChange('targetAudience', e.target.value)}
                placeholder="e.g., Small business owners aged 25-45, primarily in service industries, who are tech-savvy but time-constrained. They have annual revenues of $100k-$1M and are looking to scale their marketing efforts without hiring a full team..."
                className="w-full h-40 px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your preferred marketing platforms
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {platforms.map((platform) => (
                  <button
                    key={platform}
                    onClick={() => handleArrayToggle('platforms', platform)}
                    className={`p-3 rounded-lg border transition-all ${
                      formData.platforms.includes(platform)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {platform}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Monthly Marketing Budget: ${formData.monthlyBudget.toLocaleString()}
              </label>
              <input
                type="range"
                min="100"
                max="50000"
                step="100"
                value={formData.monthlyBudget}
                onChange={(e) => handleInputChange('monthlyBudget', parseInt(e.target.value))}
                className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-white/60 text-sm mt-2">
                <span>$100</span>
                <span>$50,000+</span>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your marketing strategy type
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  { value: 'organic', label: 'Organic', desc: 'Focus on content marketing, SEO, and organic social media growth' },
                  { value: 'paid', label: 'Paid', desc: 'Emphasis on paid advertising across platforms for quick results' },
                  { value: 'hybrid', label: 'Hybrid', desc: 'Balanced approach combining organic and paid strategies' }
                ].map((strategy) => (
                  <button
                    key={strategy.value}
                    onClick={() => handleInputChange('strategyType', strategy.value)}
                    className={`p-4 rounded-xl border-2 transition-all text-left ${
                      formData.strategyType === strategy.value
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold text-lg">{strategy.label}</div>
                    <div className="text-sm opacity-70 mt-2">{strategy.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-lg font-semibold mb-4">
                Select your business goals (choose all that apply)
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {businessGoals.map((goal) => (
                  <button
                    key={goal}
                    onClick={() => handleArrayToggle('businessGoals', goal)}
                    className={`p-3 rounded-lg border transition-all text-left ${
                      formData.businessGoals.includes(goal)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <div className="w-20 h-20 bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] rounded-full flex items-center justify-center mx-auto mb-8">
            <Brain className="w-10 h-10 text-black animate-pulse" />
          </div>
          <h2 className="text-4xl font-bold text-white mb-4">AI is Crafting Your Strategy</h2>
          <p className="text-white/80 mb-8 max-w-md mx-auto">
            Analyzing your business data and generating a comprehensive marketing strategy...
          </p>
          <div className="flex justify-center">
            <div className="w-80 bg-white/10 rounded-full h-3">
              <motion.div 
                className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-3 rounded-full"
                initial={{ width: '0%' }}
                animate={{ width: '100%' }}
                transition={{ duration: 8, ease: "easeInOut" }}
              />
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  if (generatedStrategy) {
    return (
      <div className="min-h-screen bg-black text-white p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-4xl font-bold text-[#0db2e9] mb-2">Your Marketing Strategy</h1>
              <p className="text-white/80">AI-generated comprehensive marketing plan</p>
            </div>
            <div className="flex gap-4">
              <button
                onClick={exportStrategy}
                className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg transition-all duration-200 flex items-center"
              >
                <Download className="w-5 h-5 mr-2" />
                Export
              </button>
              <button
                onClick={() => setGeneratedStrategy(null)}
                className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-6 py-3 rounded-lg transition-all duration-200 flex items-center font-medium"
              >
                Generate New
              </button>
              {onNavigateToMedia && (
                <button
                  onClick={onNavigateToMedia}
                  className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 px-6 py-3 rounded-lg transition-all duration-200 flex items-center font-medium"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Create Content
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* SEO Strategy */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
            >
              <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
                <TrendingUp className="w-6 h-6 mr-3" />
                SEO Strategy
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Target Keywords</h4>
                  <div className="flex flex-wrap gap-2">
                    {generatedStrategy.seo.keywords.map((keyword, index) => (
                      <span key={index} className="bg-[#0db2e9]/20 text-[#0db2e9] px-3 py-1 rounded-full text-sm">
                        {keyword}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Blog Content Ideas</h4>
                  <ul className="space-y-2">
                    {generatedStrategy.seo.blogs.map((blog, index) => (
                      <li key={index} className="text-white/80 flex items-start">
                        <span className="text-[#0db2e9] mr-2">•</span>
                        {blog}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>

            {/* Social Media Strategy */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
            >
              <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
                <Share2 className="w-6 h-6 mr-3" />
                Social Media Strategy
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Content Hooks</h4>
                  <ul className="space-y-2">
                    {generatedStrategy.smm.hooks.map((hook, index) => (
                      <li key={index} className="text-white/80 flex items-start">
                        <span className="text-[#0db2e9] mr-2">•</span>
                        "{hook}"
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Posting Frequency</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {Object.entries(generatedStrategy.smm.postingFrequency).map(([platform, frequency]) => (
                      <div key={platform} className="bg-white/10 p-3 rounded-lg">
                        <div className="text-white font-medium">{platform}</div>
                        <div className="text-[#0db2e9]">{frequency} posts/week</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Ad Strategy */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
            >
              <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
                <DollarSign className="w-6 h-6 mr-3" />
                Advertising Strategy
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Budget Allocation</h4>
                  <div className="space-y-2">
                    {Object.entries(generatedStrategy.ads.budgetSplit).map(([platform, percentage]) => (
                      <div key={platform} className="flex justify-between items-center">
                        <span className="text-white/80">{platform}</span>
                        <span className="text-[#0db2e9] font-semibold">{percentage}%</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">Campaign Formats</h4>
                  <div className="flex flex-wrap gap-2">
                    {generatedStrategy.ads.formats.map((format, index) => (
                      <span key={index} className="bg-green-500/20 text-green-400 px-3 py-1 rounded-full text-sm">
                        {format}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Customer Personas */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
            >
              <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
                <Users className="w-6 h-6 mr-3" />
                Customer Personas
              </h3>
              <div className="space-y-4">
                {generatedStrategy.personas.map((persona, index) => (
                  <div key={index} className="bg-white/10 p-4 rounded-lg">
                    <h4 className="text-lg font-semibold text-white mb-2">{persona.name}</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-white/60">Age:</span>
                        <span className="text-white ml-2">{persona.age}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Occupation:</span>
                        <span className="text-white ml-2">{persona.occupation}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Income:</span>
                        <span className="text-white ml-2">{persona.income}</span>
                      </div>
                      <div>
                        <span className="text-white/60">Location:</span>
                        <span className="text-white ml-2">{persona.demographics.location}</span>
                      </div>
                    </div>
                    <div className="mt-3">
                      <h5 className="text-white font-medium mb-1">Pain Points:</h5>
                      <div className="flex flex-wrap gap-1">
                        {persona.painPoints.map((pain, i) => (
                          <span key={i} className="bg-red-500/20 text-red-400 px-2 py-1 rounded text-xs">
                            {pain}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* KPI Targets */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mt-8 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-2xl font-bold text-[#0db2e9] mb-4 flex items-center">
              <Target className="w-6 h-6 mr-3" />
              KPI Targets
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
              {Object.entries(generatedStrategy.kpis).map(([kpi, target]) => (
                <div key={kpi} className="text-center">
                  <div className="text-3xl font-bold text-[#0db2e9] mb-2">
                    {typeof target === 'number' ? target.toLocaleString() : target}
                    {kpi === 'roi' && '%'}
                  </div>
                  <div className="text-white/80 capitalize">{kpi.replace(/([A-Z])/g, ' $1')}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-[#0db2e9] mb-4">AI Marketing Strategy Generator</h1>
          <p className="text-white/80 text-lg">
            Get a comprehensive, AI-powered marketing strategy tailored to your business
          </p>
        </div>

        {/* Progress Bar */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-4">
            <span className="text-white/80">Step {currentStep + 1} of {steps.length}</span>
            <span className="text-white/80">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-3 rounded-full transition-all duration-500"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-8 mb-8">
          <div className="flex items-center mb-6">
            <div className="text-[#0db2e9] mr-4">
              {steps[currentStep].icon}
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">
                {steps[currentStep].title}
              </h2>
              <p className="text-white/70">
                {steps[currentStep].description}
              </p>
            </div>
          </div>

          {renderStep()}
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={() => currentStep === 0 ? onBack() : setCurrentStep(Math.max(0, currentStep - 1))}
            className={`px-6 py-3 rounded-xl transition-all duration-200 ${
              'bg-white/10 hover:bg-white/20 text-white'
            }`}
          >
            {currentStep === 0 ? 'Back to Home' : 'Previous'}
          </button>

          {currentStep === steps.length - 1 ? (
            <button
              onClick={generateStrategy}
              disabled={!isStepValid()}
              className={`px-8 py-3 rounded-xl transition-all duration-200 flex items-center ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              <Brain className="w-5 h-5 mr-2" />
              Generate Strategy
            </button>
          ) : (
            <button
              onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
              disabled={!isStepValid()}
              className={`px-6 py-3 rounded-xl transition-all duration-200 ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              Next
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketingStrategyGenerator;