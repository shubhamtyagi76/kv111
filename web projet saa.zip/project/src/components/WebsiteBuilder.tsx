import React, { useState, useEffect } from 'react';
import { ArrowLeft, Eye, Code, Palette, Globe, Download, Share2, Phone, MessageCircle } from 'lucide-react';
import { BusinessData } from '../types/business';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

interface WebsiteBuilderProps {
  businessData: BusinessData;
  onBack: () => void;
  onNavigateToStrategy?: () => void;
}

const WebsiteBuilder: React.FC<WebsiteBuilderProps> = ({ businessData, onBack, onNavigateToStrategy }) => {
  const [isGenerating, setIsGenerating] = useState(true);
  const [generatedWebsite, setGeneratedWebsite] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>('preview');

  // Animated background effect
  useEffect(() => {
    const canvas = document.getElementById('bg-canvas-builder') as HTMLCanvasElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      dx: number;
      dy: number;
      size: number;
      opacity: number;
    }> = [];

    for (let i = 0; i < 30; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        dx: (Math.random() - 0.5) * 0.3,
        dy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.3 + 0.1
      });
    }

    function animate() {
      if (!ctx || !canvas) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        particle.x += particle.dx;
        particle.y += particle.dy;
        
        if (particle.x < 0 || particle.x > canvas.width) particle.dx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.dy *= -1;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(13, 178, 233, ${particle.opacity})`;
        ctx.fill();
      });
      
      requestAnimationFrame(animate);
    }
    
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const handleOrientationChange = () => {
      setTimeout(() => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }, 100);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
    };
  }, []);

  useEffect(() => {
    const generateWebsite = async () => {
      setIsGenerating(true);
      
      // Simulate AI processing time with realistic progress
      const steps = [
        'Analyzing business requirements...',
        'Generating brand-aligned design...',
        'Creating responsive layouts...',
        'Optimizing for SEO...',
        'Finalizing website structure...'
      ];

      for (let i = 0; i < steps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 800));
        // You could show progress here if needed
      }
      
      const websiteHTML = generateWebsiteHTML(businessData);
      setGeneratedWebsite(websiteHTML);
      setIsGenerating(false);
      
      // Send website generation notification
      await sendWebsiteNotification(businessData);
    };

    generateWebsite();
  }, [businessData]);

  const sendWebsiteNotification = async (data: BusinessData) => {
    try {
      await fetch('/api/send-website-notification', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          websiteGenerated: true,
          generatedAt: new Date().toISOString()
        }),
      });
    } catch (error) {
      console.error('Error sending website notification:', error);
    }
  };

  const generateWebsiteHTML = (data: BusinessData) => {
    const { businessName, businessIdea, niche, targetAudience, primaryColor, secondaryColor, brandTone, uniqueValue, contactEmail, contactPhone } = data;
    
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${businessName} - ${niche}</title>
    <meta name="description" content="${businessIdea.substring(0, 160)}">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <style>
        * { font-family: 'Poppins', sans-serif; }
        :root {
            --primary-color: ${primaryColor};
            --secondary-color: ${secondaryColor};
        }
        .bg-primary { background-color: var(--primary-color); }
        .text-primary { color: var(--primary-color); }
        .border-primary { border-color: var(--primary-color); }
        .bg-secondary { background-color: var(--secondary-color); }
        .text-secondary { color: var(--secondary-color); }
        
        /* Animated background */
        .hero-bg {
            background: linear-gradient(135deg, var(--primary-color)20, var(--secondary-color)20);
            position: relative;
            overflow: hidden;
        }
        
        .hero-bg::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="%23ffffff" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="%23ffffff" opacity="0.1"/><circle cx="50" cy="10" r="1" fill="%23ffffff" opacity="0.1"/><circle cx="10" cy="60" r="1" fill="%23ffffff" opacity="0.1"/><circle cx="90" cy="40" r="1" fill="%23ffffff" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
            animation: float 20s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        .floating-contact {
            position: fixed;
            right: 20px;
            bottom: 20px;
            z-index: 1000;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .floating-contact a {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            transition: transform 0.3s ease;
            animation: bounce 2s infinite;
        }
        
        .floating-contact a:hover {
            transform: scale(1.1);
        }
        
        .floating-contact .whatsapp { background: #25D366; }
        .floating-contact .phone { background: #ff4444; animation-delay: 0.5s; }
        
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <h1 class="text-2xl font-bold text-primary">${businessName}</h1>
                </div>
                <nav class="hidden md:flex space-x-8">
                    <a href="#home" class="text-gray-700 hover:text-primary transition-colors font-medium">Home</a>
                    <a href="#about" class="text-gray-700 hover:text-primary transition-colors font-medium">About</a>
                    <a href="#services" class="text-gray-700 hover:text-primary transition-colors font-medium">Services</a>
                    <a href="#contact" class="text-gray-700 hover:text-primary transition-colors font-medium">Contact</a>
                </nav>
                <button class="bg-primary text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity font-medium">
                    Get Started
                </button>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section id="home" class="hero-bg py-20 text-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center">
                <h2 class="text-5xl md:text-6xl font-bold mb-6">
                    Transform Your ${niche}
                </h2>
                <p class="text-xl md:text-2xl mb-8 max-w-3xl mx-auto opacity-90">
                    ${businessIdea.substring(0, 200)}...
                </p>
                <div class="flex flex-col sm:flex-row justify-center gap-4">
                    <button class="bg-white text-primary px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg">
                        Start Today
                    </button>
                    <button class="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-primary transition-colors text-lg">
                        Learn More
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <h3 class="text-4xl font-bold text-gray-900 mb-6">About ${businessName}</h3>
                    <p class="text-lg text-gray-600 mb-6 leading-relaxed">
                        ${businessIdea}
                    </p>
                    <div class="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-xl border-l-4 border-primary">
                        <h4 class="text-xl font-semibold text-primary mb-3">What Makes Us Different</h4>
                        <p class="text-gray-700">${uniqueValue || 'We provide exceptional service tailored to your specific needs.'}</p>
                    </div>
                </div>
                <div class="bg-gradient-to-br from-gray-100 to-gray-200 h-96 rounded-xl flex items-center justify-center">
                    <div class="text-center">
                        <i class="fas fa-image text-6xl text-gray-400 mb-4"></i>
                        <p class="text-gray-500 font-medium">Professional Image Placeholder</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h3 class="text-4xl font-bold text-gray-900 mb-4">Our Services</h3>
                <p class="text-lg text-gray-600">Designed specifically for ${targetAudience}</p>
            </div>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="w-16 h-16 bg-primary rounded-xl mb-6 flex items-center justify-center">
                        <i class="fas fa-star text-white text-2xl"></i>
                    </div>
                    <h4 class="text-xl font-semibold text-gray-900 mb-4">Premium Service</h4>
                    <p class="text-gray-600">Our flagship service designed to deliver exceptional results for your business.</p>
                </div>
                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="w-16 h-16 bg-secondary rounded-xl mb-6 flex items-center justify-center">
                        <i class="fas fa-rocket text-white text-2xl"></i>
                    </div>
                    <h4 class="text-xl font-semibold text-gray-900 mb-4">Growth Solutions</h4>
                    <p class="text-gray-600">Accelerate your business growth with our proven strategies and expertise.</p>
                </div>
                <div class="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
                    <div class="w-16 h-16 bg-primary rounded-xl mb-6 flex items-center justify-center">
                        <i class="fas fa-shield-alt text-white text-2xl"></i>
                    </div>
                    <h4 class="text-xl font-semibold text-gray-900 mb-4">Support & Maintenance</h4>
                    <p class="text-gray-600">Ongoing support to ensure your continued success and peace of mind.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16">
                <h3 class="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h3>
                <p class="text-lg text-gray-600">Ready to start your journey? Let's talk!</p>
            </div>
            <div class="grid md:grid-cols-2 gap-12">
                <div>
                    <h4 class="text-2xl font-semibold text-gray-900 mb-6">Contact Information</h4>
                    <div class="space-y-6">
                        ${contactEmail ? `
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mr-4">
                                <i class="fas fa-envelope text-white"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">Email</p>
                                <p class="text-gray-600">${contactEmail}</p>
                            </div>
                        </div>
                        ` : ''}
                        ${contactPhone ? `
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mr-4">
                                <i class="fas fa-phone text-white"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">Phone</p>
                                <p class="text-gray-600">${contactPhone}</p>
                            </div>
                        </div>
                        ` : ''}
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mr-4">
                                <i class="fas fa-map-marker-alt text-white"></i>
                            </div>
                            <div>
                                <p class="font-medium text-gray-900">Location</p>
                                <p class="text-gray-600">Available Worldwide</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <form class="space-y-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Name</label>
                            <input type="text" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Message</label>
                            <textarea rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"></textarea>
                        </div>
                        <button type="submit" class="w-full bg-primary text-white py-3 px-6 rounded-lg hover:opacity-90 transition-opacity font-medium">
                            Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center">
                <h5 class="text-3xl font-bold mb-4 text-primary">${businessName}</h5>
                <p class="text-gray-400 mb-6 max-w-2xl mx-auto">${niche} - Powered by Vyomexa.ai™</p>
                <div class="flex justify-center space-x-6 mb-8">
                    <a href="#" class="text-gray-400 hover:text-white transition-colors text-xl">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors text-xl">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors text-xl">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors text-xl">
                        <i class="fab fa-twitter"></i>
                    </a>
                </div>
                <div class="border-t border-gray-800 pt-8">
                    <p class="text-gray-400">© 2025 ${businessName}. All rights reserved. | Built with ❤️ by Vyomexa.ai™</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Floating Contact Buttons -->
    <div class="floating-contact">
        ${contactPhone ? `<a href="tel:${contactPhone}" class="phone" title="Call Us"><i class="fas fa-phone"></i></a>` : ''}
        <a href="https://wa.me/917891159369" class="whatsapp" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
    </div>

    <!-- Smooth Scrolling Script -->
    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>`;
  };

  const handleExport = () => {
    const blob = new Blob([generatedWebsite], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${businessData.businessName.toLowerCase().replace(/\s+/g, '-')}-website.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Website exported successfully!');
  };

  const handlePublish = () => {
    toast.success('Publishing feature coming soon! Your website will be live shortly.');
  };

  if (isGenerating) {
    return (
      <div className="min-h-screen bg-black text-white relative overflow-x-hidden">
        <canvas 
          id="bg-canvas-builder" 
          className="fixed top-0 left-0 w-full h-full z-0 pointer-events-none"
        />
        
        <div className="relative z-10 min-h-screen flex items-center justify-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center px-4"
          >
            <div className="w-16 sm:w-20 h-16 sm:h-20 bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] rounded-full flex items-center justify-center mx-auto mb-6 sm:mb-8">
              <Globe className="w-8 sm:w-10 h-8 sm:h-10 text-black animate-spin" />
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-3 sm:mb-4">AI is Building Your Website</h2>
            <p className="text-white/80 mb-6 sm:mb-8 max-w-md mx-auto text-sm sm:text-base">
              Analyzing your business data and generating a custom website optimized for your industry...
            </p>
            <div className="flex justify-center">
              <div className="w-64 sm:w-80 bg-white/10 rounded-full h-2 sm:h-3">
                <motion.div 
                  className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-2 sm:h-3 rounded-full"
                  initial={{ width: '0%' }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 4, ease: "easeInOut" }}
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white relative overflow-x-hidden">
      <canvas 
        id="bg-canvas-builder" 
        className="fixed top-0 left-0 w-full h-full z-0 pointer-events-none"
      />

      {/* Header */}
      <header className="relative z-10 bg-white/5 backdrop-blur-sm border-b border-white/10 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center py-3 sm:py-0 sm:h-16 gap-3 sm:gap-0">
            <div className="flex items-center">
              <button
                onClick={onBack}
                className="flex items-center px-3 sm:px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-all duration-200 mr-4 sm:mr-6 text-sm sm:text-base"
              >
                <ArrowLeft className="w-4 sm:w-5 h-4 sm:h-5 mr-2" />
                Back
              </button>
              <h1 className="text-base sm:text-lg md:text-xl font-bold text-[#0db2e9] truncate">
                {businessData.businessName} - Website Builder
              </h1>
            </div>
            
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-4 w-full sm:w-auto">
              <div className="flex bg-white/10 rounded-lg p-1">
                <button
                  onClick={() => setActiveTab('preview')}
                  className={`flex items-center px-3 sm:px-4 py-2 rounded-md transition-all text-xs sm:text-sm ${
                    activeTab === 'preview'
                      ? 'bg-white/20 text-white'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  <Eye className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2" />
                  Preview
                </button>
                <button
                  onClick={() => setActiveTab('code')}
                  className={`flex items-center px-3 sm:px-4 py-2 rounded-md transition-all text-xs sm:text-sm ${
                    activeTab === 'code'
                      ? 'bg-white/20 text-white'
                      : 'text-white/70 hover:text-white'
                  }`}
                >
                  <Code className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2" />
                  Code
                </button>
              </div>
              
              <div className="flex gap-2">
                <button 
                  onClick={handleExport}
                  className="bg-white/10 hover:bg-white/20 text-white px-3 sm:px-4 py-2 rounded-lg transition-all duration-200 flex items-center text-xs sm:text-sm flex-1 sm:flex-none justify-center"
                >
                  <Download className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2" />
                  Export
                </button>
                <button 
                  onClick={handlePublish}
                  className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-3 sm:px-4 py-2 rounded-lg transition-all duration-200 flex items-center font-medium text-xs sm:text-sm flex-1 sm:flex-none justify-center"
                >
                  <Share2 className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2" />
                  Publish
                </button>
                {onNavigateToStrategy && (
                  <button 
                    onClick={onNavigateToStrategy}
                    className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 px-3 sm:px-4 py-2 rounded-lg transition-all duration-200 flex items-center font-medium text-xs sm:text-sm flex-1 sm:flex-none justify-center"
                  >
                    <TrendingUp className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2" />
                    Marketing
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="relative z-10 p-3 sm:p-6">
        {activeTab === 'preview' ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-full mx-auto bg-white rounded-lg shadow-2xl overflow-hidden"
          >
            <div className="bg-gray-100 p-2 sm:p-4 flex items-center justify-between border-b">
              <div className="flex items-center space-x-2">
                <div className="flex space-x-1">
                  <div className="w-2 sm:w-3 h-2 sm:h-3 bg-red-500 rounded-full"></div>
                  <div className="w-2 sm:w-3 h-2 sm:h-3 bg-yellow-500 rounded-full"></div>
                  <div className="w-2 sm:w-3 h-2 sm:h-3 bg-green-500 rounded-full"></div>
                </div>
                <span className="text-gray-600 text-xs sm:text-sm ml-2 sm:ml-4 truncate">
                  {businessData.businessName.toLowerCase().replace(/\s+/g, '')}.com
                </span>
              </div>
              <div className="hidden sm:flex items-center space-x-2">
                <button className="text-gray-500 hover:text-gray-700">
                  <Palette className="w-4 h-4" />
                </button>
                <button className="text-gray-500 hover:text-gray-700">
                  <Globe className="w-4 h-4" />
                </button>
              </div>
            </div>
            <div className="h-[60vh] sm:h-screen overflow-y-auto">
              <iframe
                srcDoc={generatedWebsite}
                className="w-full h-full"
                title="Website Preview"
              />
            </div>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-full mx-auto bg-gray-900 rounded-lg shadow-2xl overflow-hidden"
          >
            <div className="bg-gray-800 p-2 sm:p-4 flex items-center justify-between border-b border-gray-700">
              <div className="flex items-center space-x-2">
                <Code className="w-3 sm:w-4 h-3 sm:h-4 text-green-400" />
                <span className="text-gray-300 text-xs sm:text-sm">index.html</span>
              </div>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(generatedWebsite);
                  toast.success('Code copied to clipboard!');
                }}
                className="bg-gray-700 hover:bg-gray-600 text-white px-2 sm:px-3 py-1 rounded text-xs sm:text-sm"
              >
                Copy Code
              </button>
            </div>
            <div className="p-3 sm:p-6 overflow-auto h-[60vh] sm:h-screen">
              <pre className="text-green-400 text-xs sm:text-sm font-mono whitespace-pre-wrap">
                {generatedWebsite}
              </pre>
            </div>
          </motion.div>
        )}
      </div>

      {/* Floating Contact Icons */}
      <div className="fixed right-3 sm:right-5 bottom-20 sm:bottom-24 flex flex-col gap-3 sm:gap-4 z-50">
        <a
          href="tel:7891159369"
          className="bg-red-500 hover:bg-red-600 text-white p-3 sm:p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce"
          style={{ animationDelay: '0.5s' }}
        >
          <Phone className="w-5 sm:w-6 h-5 sm:h-6" />
        </a>
        <a
          href="https://wa.me/917891159369"
          className="bg-green-500 hover:bg-green-600 text-white p-3 sm:p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce"
        >
          <MessageCircle className="w-5 sm:w-6 h-5 sm:h-6" />
        </a>
      </div>
    </div>
  );
};

export default WebsiteBuilder;