import React, { useState, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Sparkles, Target, Palette, Zap, Phone, MessageCircle } from 'lucide-react';
import { BusinessData } from '../types/business';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

interface BusinessIdeaFlowProps {
  onComplete: (data: BusinessData) => void;
  onBack: () => void;
}

const BusinessIdeaFlow: React.FC<BusinessIdeaFlowProps> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    businessIdea: '',
    niche: '',
    targetAudience: '',
    serviceType: 'service' as 'product' | 'service' | 'both',
    businessName: '',
    brandTone: 'professional' as 'professional' | 'friendly' | 'bold' | 'minimalist',
    primaryColor: '#0db2e9',
    secondaryColor: '#b2fefa',
    industry: '',
    goals: [] as string[],
    uniqueValue: '',
    contactEmail: '',
    contactPhone: '',
    budget: '',
    timeline: ''
  });

  // Animated background effect
  useEffect(() => {
    const canvas = document.getElementById('bg-canvas-flow') as HTMLCanvasElement;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      dx: number;
      dy: number;
      size: number;
      opacity: number;
    }> = [];

    for (let i = 0; i < 30; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        dx: (Math.random() - 0.5) * 0.3,
        dy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.3 + 0.1
      });
    }

    function animate() {
      if (!ctx || !canvas) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        particle.x += particle.dx;
        particle.y += particle.dy;
        
        if (particle.x < 0 || particle.x > canvas.width) particle.dx *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.dy *= -1;
        
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(13, 178, 233, ${particle.opacity})`;
        ctx.fill();
      });
      
      requestAnimationFrame(animate);
    }
    
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const handleOrientationChange = () => {
      setTimeout(() => {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }, 100);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleOrientationChange);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleOrientationChange);
    };
  }, []);

  const steps = [
    {
      title: 'Tell us your business idea',
      description: 'What product or service do you want to offer?',
      icon: <Sparkles className="w-8 h-8" />
    },
    {
      title: 'Define your niche & industry',
      description: 'What specific market are you targeting?',
      icon: <Target className="w-8 h-8" />
    },
    {
      title: 'Brand personality & design',
      description: 'How do you want your brand to feel and look?',
      icon: <Palette className="w-8 h-8" />
    },
    {
      title: 'Business goals & contact',
      description: 'Let\'s complete your business profile',
      icon: <Zap className="w-8 h-8" />
    }
  ];

  const industries = [
    'Fitness & Health', 'E-commerce', 'Education', 'Technology', 'Finance',
    'Real Estate', 'Food & Beverage', 'Beauty & Fashion', 'Consulting',
    'Entertainment', 'Non-profit', 'Healthcare', 'Digital Marketing', 'Other'
  ];

  const businessGoals = [
    'Generate leads', 'Increase sales', 'Build brand awareness', 'Educate customers',
    'Provide customer support', 'Sell products online', 'Book appointments',
    'Showcase portfolio', 'Collect donations', 'Build community'
  ];

  const budgetRanges = [
    'Under $1,000', '$1,000 - $5,000', '$5,000 - $10,000', 
    '$10,000 - $25,000', '$25,000 - $50,000', 'Over $50,000'
  ];

  const timelineOptions = [
    'ASAP (Rush)', '1-2 weeks', '2-4 weeks', '1-2 months', '2-3 months', 'Flexible'
  ];

  const handleInputChange = (field: keyof typeof formData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleGoalToggle = (goal: string) => {
    setFormData(prev => ({
      ...prev,
      goals: prev.goals.includes(goal)
        ? prev.goals.filter(g => g !== goal)
        : [...prev.goals, goal]
    }));
  };

  const sendEmailNotification = async (data: BusinessData) => {
    try {
      const response = await fetch('/api/send-business-inquiry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        toast.success('Business inquiry sent successfully!');
      } else {
        toast.error('Failed to send inquiry. Please try again.');
      }
    } catch (error) {
      console.error('Error sending email:', error);
      toast.error('Failed to send inquiry. Please try again.');
    }
  };

  const handleNext = async () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      const businessData = formData as BusinessData;
      await sendEmailNotification(businessData);
      onComplete(businessData);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    } else {
      onBack();
    }
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 0:
        return formData.businessIdea.trim().length > 10 && formData.serviceType;
      case 1:
        return formData.niche.trim().length > 0 && formData.industry.length > 0;
      case 2:
        return formData.businessName.trim().length > 0 && formData.brandTone;
      case 3:
        return formData.targetAudience.trim().length > 0 && 
               formData.goals.length > 0 && 
               formData.contactEmail.trim().length > 0 &&
               formData.budget && formData.timeline;
      default:
        return false;
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4 sm:space-y-6"
          >
            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                Describe your business idea in detail
              </label>
              <textarea
                value={formData.businessIdea}
                onChange={(e) => handleInputChange('businessIdea', e.target.value)}
                placeholder="e.g., I want to start a fitness coaching business that helps busy professionals lose weight and build muscle through personalized workout plans and nutrition guidance..."
                className="w-full h-32 sm:h-40 px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none text-sm sm:text-base"
              />
            </div>
            
            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                What type of business is this?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                {['service', 'product', 'both'].map((type) => (
                  <button
                    key={type}
                    onClick={() => handleInputChange('serviceType', type)}
                    className={`p-3 sm:p-4 rounded-xl border-2 transition-all text-sm sm:text-base ${
                      formData.serviceType === type
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold capitalize">{type}</div>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        );

      case 1:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4 sm:space-y-6"
          >
            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                What's your specific niche or specialty?
              </label>
              <input
                type="text"
                value={formData.niche}
                onChange={(e) => handleInputChange('niche', e.target.value)}
                placeholder="e.g., Weight loss for busy professionals, Organic skincare for teens, etc."
                className="w-full px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent text-sm sm:text-base"
              />
            </div>

            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                Which industry best describes your business?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3">
                {industries.map((industry) => (
                  <button
                    key={industry}
                    onClick={() => handleInputChange('industry', industry)}
                    className={`p-2 sm:p-3 rounded-lg border transition-all text-xs sm:text-sm ${
                      formData.industry === industry
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {industry}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4 sm:space-y-6"
          >
            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                What's your business name?
              </label>
              <input
                type="text"
                value={formData.businessName}
                onChange={(e) => handleInputChange('businessName', e.target.value)}
                placeholder="Enter your business name"
                className="w-full px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent text-sm sm:text-base"
              />
            </div>

            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                What's your brand personality?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                {[
                  { value: 'professional', label: 'Professional', desc: 'Clean, corporate, trustworthy' },
                  { value: 'friendly', label: 'Friendly', desc: 'Warm, approachable, casual' },
                  { value: 'bold', label: 'Bold', desc: 'Edgy, confident, attention-grabbing' },
                  { value: 'minimalist', label: 'Minimalist', desc: 'Simple, elegant, refined' }
                ].map((tone) => (
                  <button
                    key={tone.value}
                    onClick={() => handleInputChange('brandTone', tone.value)}
                    className={`p-3 sm:p-4 rounded-xl border-2 transition-all text-left ${
                      formData.brandTone === tone.value
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    <div className="font-semibold text-sm sm:text-base">{tone.label}</div>
                    <div className="text-xs sm:text-sm opacity-70">{tone.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                Choose your brand colors
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <label className="block text-white/80 text-xs sm:text-sm mb-2">Primary Color</label>
                  <input
                    type="color"
                    value={formData.primaryColor}
                    onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                    className="w-full h-10 sm:h-12 bg-white/10 border border-white/20 rounded-lg cursor-pointer"
                  />
                </div>
                <div>
                  <label className="block text-white/80 text-xs sm:text-sm mb-2">Secondary Color</label>
                  <input
                    type="color"
                    value={formData.secondaryColor}
                    onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                    className="w-full h-10 sm:h-12 bg-white/10 border border-white/20 rounded-lg cursor-pointer"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 3:
        return (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4 sm:space-y-6"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              <div>
                <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                  Your Email Address *
                </label>
                <input
                  type="email"
                  value={formData.contactEmail}
                  onChange={(e) => handleInputChange('contactEmail', e.target.value)}
                  placeholder="your@email.com"
                  className="w-full px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent text-sm sm:text-base"
                />
              </div>
              
              <div>
                <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                  Phone Number (Optional)
                </label>
                <input
                  type="tel"
                  value={formData.contactPhone}
                  onChange={(e) => handleInputChange('contactPhone', e.target.value)}
                  placeholder="+1 (555) 123-4567"
                  className="w-full px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent text-sm sm:text-base"
                />
              </div>
            </div>

            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                Who is your target audience?
              </label>
              <textarea
                value={formData.targetAudience}
                onChange={(e) => handleInputChange('targetAudience', e.target.value)}
                placeholder="e.g., Busy professionals aged 25-45 who want to lose weight but don't have time for long gym sessions..."
                className="w-full h-28 sm:h-32 px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none text-sm sm:text-base"
              />
            </div>

            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                What are your main business goals? (Select all that apply)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
                {businessGoals.map((goal) => (
                  <button
                    key={goal}
                    onClick={() => handleGoalToggle(goal)}
                    className={`p-2 sm:p-3 rounded-lg border transition-all text-xs sm:text-sm text-left ${
                      formData.goals.includes(goal)
                        ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                        : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                    }`}
                  >
                    {goal}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
              <div>
                <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                  Project Budget
                </label>
                <div className="space-y-1 sm:space-y-2">
                  {budgetRanges.map((budget) => (
                    <button
                      key={budget}
                      onClick={() => handleInputChange('budget', budget)}
                      className={`w-full p-2 sm:p-3 rounded-lg border transition-all text-xs sm:text-sm text-left ${
                        formData.budget === budget
                          ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                          : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                      }`}
                    >
                      {budget}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                  Timeline
                </label>
                <div className="space-y-1 sm:space-y-2">
                  {timelineOptions.map((timeline) => (
                    <button
                      key={timeline}
                      onClick={() => handleInputChange('timeline', timeline)}
                      className={`w-full p-2 sm:p-3 rounded-lg border transition-all text-xs sm:text-sm text-left ${
                        formData.timeline === timeline
                          ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                          : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                      }`}
                    >
                      {timeline}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-white text-base sm:text-lg font-semibold mb-3 sm:mb-4">
                What makes your business unique?
              </label>
              <textarea
                value={formData.uniqueValue}
                onChange={(e) => handleInputChange('uniqueValue', e.target.value)}
                placeholder="e.g., I use a unique 15-minute workout system that's scientifically proven to burn fat faster than traditional methods..."
                className="w-full h-28 sm:h-32 px-3 sm:px-4 py-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] focus:border-transparent resize-none text-sm sm:text-base"
              />
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white relative overflow-x-hidden">
      {/* Animated Background Canvas */}
      <canvas 
        id="bg-canvas-flow" 
        className="fixed top-0 left-0 w-full h-full z-0 pointer-events-none"
      />

      <div className="relative z-10 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto min-h-screen flex flex-col">
          {/* Header */}
          <div className="text-center mb-8 sm:mb-12">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 sm:w-10 h-8 sm:h-10 bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] rounded-xl flex items-center justify-center">
                <Sparkles className="w-4 sm:w-6 h-4 sm:h-6 text-black" />
              </div>
              <span className="text-xl sm:text-2xl font-bold text-[#0db2e9]">Vyomexa.ai™</span>
            </div>
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-3 sm:mb-4 px-4">
              Let's Build Your Business
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-white/80 px-4">
              We'll create everything you need in just a few minutes
            </p>
          </div>

          {/* Progress Bar */}
          <div className="mb-8 sm:mb-12">
            <div className="flex justify-between items-center mb-3 sm:mb-4 px-2">
              <span className="text-white/80 text-sm sm:text-base">Step {currentStep + 1} of {steps.length}</span>
              <span className="text-white/80 text-sm sm:text-base">{Math.round(((currentStep + 1) / steps.length) * 100)}%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] h-2 rounded-full transition-all duration-500"
                style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Step Content */}
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 p-6 sm:p-8 mb-6 sm:mb-8 flex-1">
            <div className="flex items-center mb-4 sm:mb-6">
              <div className="text-[#0db2e9] mr-3 sm:mr-4 flex-shrink-0">
                {steps[currentStep].icon}
              </div>
              <div>
                <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-white">
                  {steps[currentStep].title}
                </h2>
                <p className="text-white/70 text-sm sm:text-base">
                  {steps[currentStep].description}
                </p>
              </div>
            </div>

            {renderStep()}
          </div>

          {/* Navigation */}
          <div className="flex flex-col sm:flex-row justify-between gap-3 sm:gap-0">
            <button
              onClick={handleBack}
              className="flex items-center justify-center px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-all duration-200 text-sm sm:text-base"
            >
              <ArrowLeft className="w-4 sm:w-5 h-4 sm:h-5 mr-2" />
              Back
            </button>

            <button
              onClick={handleNext}
              disabled={!isStepValid()}
              className={`flex items-center justify-center px-6 py-3 rounded-xl transition-all duration-200 text-sm sm:text-base ${
                isStepValid()
                  ? 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              {currentStep === steps.length - 1 ? 'Generate My Business' : 'Next'}
              <ArrowRight className="w-4 sm:w-5 h-4 sm:h-5 ml-2" />
            </button>
          </div>
        </div>
      </div>

      {/* Floating Contact Icons */}
      <div className="fixed right-3 sm:right-5 bottom-20 sm:bottom-24 flex flex-col gap-3 sm:gap-4 z-50">
        <a
          href="tel:7891159369"
          className="bg-red-500 hover:bg-red-600 text-white p-3 sm:p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce"
          style={{ animationDelay: '0.5s' }}
        >
          <Phone className="w-5 sm:w-6 h-5 sm:h-6" />
        </a>
        <a
          href="https://wa.me/917891159369"
          className="bg-green-500 hover:bg-green-600 text-white p-3 sm:p-4 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce"
        >
          <MessageCircle className="w-5 sm:w-6 h-5 sm:h-6" />
        </a>
      </div>
    </div>
  );
};

export default BusinessIdeaFlow;