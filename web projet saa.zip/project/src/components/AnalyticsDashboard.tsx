import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from 'chart.js';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import { 
  TrendingUp, TrendingDown, Users, Eye, MousePointer, 
  DollarSign, Target, Calendar, Download, RefreshCw 
} from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

interface AnalyticsDashboardProps {
  onBack: () => void;
}

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ onBack }) => {
  const [timeframe, setTimeframe] = useState<'7d' | '30d' | '90d'>('30d');
  const [isLoading, setIsLoading] = useState(false);

  // Mock analytics data
  const analyticsData = {
    overview: {
      totalReach: 125000,
      totalImpressions: 450000,
      totalClicks: 12500,
      totalConversions: 890,
      avgCTR: 2.78,
      avgCPC: 3.45,
      totalSpend: 43125,
      roi: 285
    },
    trends: {
      reach: [8500, 9200, 11000, 12500, 14200, 13800, 15600],
      impressions: [32000, 35000, 41000, 45000, 52000, 48000, 56000],
      clicks: [890, 980, 1150, 1250, 1420, 1380, 1560],
      conversions: [45, 52, 68, 89, 95, 87, 102]
    },
    platforms: {
      Instagram: { reach: 45000, engagement: 3.2, conversions: 320 },
      Facebook: { reach: 38000, engagement: 2.8, conversions: 280 },
      LinkedIn: { reach: 25000, engagement: 4.1, conversions: 180 },
      YouTube: { reach: 17000, engagement: 5.5, conversions: 110 }
    },
    demographics: {
      age: {
        '18-24': 15,
        '25-34': 35,
        '35-44': 28,
        '45-54': 15,
        '55+': 7
      },
      gender: {
        Male: 52,
        Female: 45,
        Other: 3
      }
    }
  };

  const refreshData = () => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 1500);
  };

  // Chart configurations
  const lineChartData = {
    labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4', 'Week 5', 'Week 6', 'Week 7'],
    datasets: [
      {
        label: 'Reach',
        data: analyticsData.trends.reach,
        borderColor: '#0db2e9',
        backgroundColor: 'rgba(13, 178, 233, 0.1)',
        tension: 0.4,
      },
      {
        label: 'Conversions',
        data: analyticsData.trends.conversions,
        borderColor: '#b2fefa',
        backgroundColor: 'rgba(178, 254, 250, 0.1)',
        tension: 0.4,
      }
    ]
  };

  const barChartData = {
    labels: Object.keys(analyticsData.platforms),
    datasets: [
      {
        label: 'Reach',
        data: Object.values(analyticsData.platforms).map(p => p.reach),
        backgroundColor: 'rgba(13, 178, 233, 0.8)',
      },
      {
        label: 'Conversions',
        data: Object.values(analyticsData.platforms).map(p => p.conversions),
        backgroundColor: 'rgba(178, 254, 250, 0.8)',
      }
    ]
  };

  const doughnutData = {
    labels: Object.keys(analyticsData.demographics.age),
    datasets: [
      {
        data: Object.values(analyticsData.demographics.age),
        backgroundColor: [
          '#0db2e9',
          '#b2fefa',
          '#4ade80',
          '#f59e0b',
          '#ef4444'
        ],
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        labels: {
          color: '#ffffff'
        }
      }
    },
    scales: {
      x: {
        ticks: {
          color: '#ffffff'
        },
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        }
      },
      y: {
        ticks: {
          color: '#ffffff'
        },
        grid: {
          color: 'rgba(255, 255, 255, 0.1)'
        }
      }
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
          <div>
            <div className="flex items-center mb-4">
              <button
                onClick={onBack}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center mr-4"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Back to Home
              </button>
            </div>
            <h1 className="text-4xl font-bold text-[#0db2e9] mb-2">Analytics Dashboard</h1>
            <p className="text-white/80">Track your campaign performance and insights</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            <select
              value={timeframe}
              onChange={(e) => setTimeframe(e.target.value as any)}
              className="bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
            >
              <option value="7d" className="bg-gray-800">Last 7 days</option>
              <option value="30d" className="bg-gray-800">Last 30 days</option>
              <option value="90d" className="bg-gray-800">Last 90 days</option>
            </select>
            
            <button
              onClick={refreshData}
              disabled={isLoading}
              className="bg-[#0db2e9] hover:bg-[#0aa3d1] text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            
            <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center">
              <Download className="w-4 h-4 mr-2" />
              Export
            </button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { 
              title: 'Total Reach', 
              value: analyticsData.overview.totalReach.toLocaleString(), 
              change: '+12.5%', 
              icon: <Users className="w-6 h-6" />,
              positive: true 
            },
            { 
              title: 'Impressions', 
              value: analyticsData.overview.totalImpressions.toLocaleString(), 
              change: '+8.3%', 
              icon: <Eye className="w-6 h-6" />,
              positive: true 
            },
            { 
              title: 'Click Rate', 
              value: `${analyticsData.overview.avgCTR}%`, 
              change: '+2.1%', 
              icon: <MousePointer className="w-6 h-6" />,
              positive: true 
            },
            { 
              title: 'ROI', 
              value: `${analyticsData.overview.roi}%`, 
              change: '+15.7%', 
              icon: <DollarSign className="w-6 h-6" />,
              positive: true 
            }
          ].map((metric, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="text-[#0db2e9]">{metric.icon}</div>
                <div className={`flex items-center text-sm ${
                  metric.positive ? 'text-green-400' : 'text-red-400'
                }`}>
                  {metric.positive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                  {metric.change}
                </div>
              </div>
              <h3 className="text-white/70 text-sm mb-2">{metric.title}</h3>
              <p className="text-2xl font-bold text-white">{metric.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Performance Trends */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-xl font-bold text-white mb-6">Performance Trends</h3>
            <Line data={lineChartData} options={chartOptions} />
          </motion.div>

          {/* Platform Performance */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-xl font-bold text-white mb-6">Platform Performance</h3>
            <Bar data={barChartData} options={chartOptions} />
          </motion.div>
        </div>

        {/* Demographics and Insights */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Age Demographics */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-xl font-bold text-white mb-6">Age Demographics</h3>
            <Doughnut 
              data={doughnutData} 
              options={{
                responsive: true,
                plugins: {
                  legend: {
                    labels: {
                      color: '#ffffff'
                    }
                  }
                }
              }} 
            />
          </motion.div>

          {/* Top Performing Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-xl font-bold text-white mb-6">Top Performing Content</h3>
            <div className="space-y-4">
              {[
                { title: 'AI Business Automation Guide', engagement: '4.2K', type: 'Video' },
                { title: '5 Marketing Trends for 2025', engagement: '3.8K', type: 'Post' },
                { title: 'Behind the Scenes: AI Creation', engagement: '3.1K', type: 'Story' },
                { title: 'Customer Success Story', engagement: '2.9K', type: 'Carousel' }
              ].map((content, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <div>
                    <p className="text-white font-medium text-sm">{content.title}</p>
                    <p className="text-white/60 text-xs">{content.type}</p>
                  </div>
                  <div className="text-[#0db2e9] font-semibold text-sm">{content.engagement}</div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Key Insights */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6"
          >
            <h3 className="text-xl font-bold text-white mb-6">Key Insights</h3>
            <div className="space-y-4">
              <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                <div className="flex items-center mb-2">
                  <TrendingUp className="w-4 h-4 text-green-400 mr-2" />
                  <span className="text-green-400 font-medium text-sm">Best Performance</span>
                </div>
                <p className="text-white/80 text-sm">Video content performs 40% better than static posts</p>
              </div>
              
              <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                <div className="flex items-center mb-2">
                  <Target className="w-4 h-4 text-blue-400 mr-2" />
                  <span className="text-blue-400 font-medium text-sm">Optimization</span>
                </div>
                <p className="text-white/80 text-sm">Peak engagement: 6-8 PM weekdays</p>
              </div>
              
              <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                <div className="flex items-center mb-2">
                  <Calendar className="w-4 h-4 text-yellow-400 mr-2" />
                  <span className="text-yellow-400 font-medium text-sm">Recommendation</span>
                </div>
                <p className="text-white/80 text-sm">Increase posting frequency on LinkedIn</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;