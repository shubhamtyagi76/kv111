import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Calendar, Play, Pause, BarChart3, Settings, Plus, 
  Target, TrendingUp, Users, DollarSign, Eye, Edit,
  Clock, CheckCircle, AlertCircle, XCircle
} from 'lucide-react';
import { Campaign, CampaignSchedule, AnalyticsData, AIRecommendation } from '../types/marketing';
import { campaignService } from '../services/campaignService';
import { aiService } from '../services/aiService';
import toast from 'react-hot-toast';

interface CampaignManagerProps {
  onBack: () => void;
}

const CampaignManager: React.FC<CampaignManagerProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState<'campaigns' | 'analytics' | 'calendar'>('campaigns');
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [analytics, setAnalytics] = useState<AnalyticsData[]>([]);
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(true);

  const [newCampaign, setNewCampaign] = useState({
    name: '',
    type: 'post' as Campaign['type'],
    platforms: [] as string[],
    budget: 1000,
    schedule: {
      type: 'scheduled' as CampaignSchedule['type'],
      startDate: new Date().toISOString().split('T')[0],
      times: ['09:00'],
      timezone: 'UTC'
    }
  });

  useEffect(() => {
    loadCampaigns();
  }, []);

  const loadCampaigns = async () => {
    setLoading(true);
    try {
      const campaignData = await campaignService.getCampaigns();
      setCampaigns(campaignData);
      
      // Load analytics for active campaigns
      const analyticsPromises = campaignData
        .filter(c => c.status === 'active')
        .map(c => campaignService.getAnalytics(c.id));
      
      const analyticsData = await Promise.all(analyticsPromises);
      setAnalytics(analyticsData);

      // Generate AI recommendations
      if (campaignData.length > 0) {
        const recommendations = await aiService.generateRecommendations(campaignData);
        setRecommendations(recommendations);
      }
    } catch (error) {
      console.error('Error loading campaigns:', error);
      toast.error('Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  };

  const createCampaign = async () => {
    if (!newCampaign.name.trim() || newCampaign.platforms.length === 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    try {
      const campaign = await campaignService.createCampaign({
        name: newCampaign.name,
        type: newCampaign.type,
        platforms: newCampaign.platforms,
        budget: newCampaign.budget,
        schedule: {
          ...newCampaign.schedule,
          startDate: new Date(newCampaign.schedule.startDate).toISOString()
        }
      });

      setCampaigns(prev => [campaign, ...prev]);
      setIsCreating(false);
      setNewCampaign({
        name: '',
        type: 'post',
        platforms: [],
        budget: 1000,
        schedule: {
          type: 'scheduled',
          startDate: new Date().toISOString().split('T')[0],
          times: ['09:00'],
          timezone: 'UTC'
        }
      });
      toast.success('Campaign created successfully!');
    } catch (error) {
      console.error('Error creating campaign:', error);
      toast.error('Failed to create campaign');
    }
  };

  const toggleCampaign = async (campaign: Campaign) => {
    try {
      if (campaign.status === 'active') {
        await campaignService.pauseCampaign(campaign.id);
        toast.success('Campaign paused');
      } else if (campaign.status === 'paused') {
        await campaignService.resumeCampaign(campaign.id);
        toast.success('Campaign resumed');
      } else if (campaign.status === 'draft' || campaign.status === 'scheduled') {
        await campaignService.scheduleCampaign(campaign.id, campaign.schedule);
        toast.success('Campaign started');
      }
      loadCampaigns();
    } catch (error) {
      console.error('Error toggling campaign:', error);
      toast.error('Failed to update campaign');
    }
  };

  const getStatusIcon = (status: Campaign['status']) => {
    switch (status) {
      case 'active':
        return <Play className="w-4 h-4 text-green-400" />;
      case 'paused':
        return <Pause className="w-4 h-4 text-yellow-400" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-400" />;
      case 'scheduled':
        return <Clock className="w-4 h-4 text-purple-400" />;
      default:
        return <XCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: Campaign['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-400';
      case 'paused':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'completed':
        return 'bg-blue-500/20 text-blue-400';
      case 'scheduled':
        return 'bg-purple-500/20 text-purple-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const platforms = ['Instagram', 'Facebook', 'LinkedIn', 'YouTube', 'TikTok', 'Twitter'];

  if (loading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] rounded-full flex items-center justify-center mx-auto mb-4 animate-spin">
            <BarChart3 className="w-8 h-8 text-black" />
          </div>
          <p className="text-white/80">Loading campaigns...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <div className="flex items-center mb-4">
              <button
                onClick={onBack}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center mr-4"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </button>
            </div>
            <h1 className="text-4xl font-bold text-[#0db2e9] mb-2">Campaign Manager</h1>
            <p className="text-white/80">Schedule, monitor, and optimize your marketing campaigns</p>
          </div>
          <button
            onClick={() => setIsCreating(true)}
            className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-6 py-3 rounded-lg transition-all duration-200 flex items-center font-medium"
          >
            <Plus className="w-5 h-5 mr-2" />
            New Campaign
          </button>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white/10 rounded-lg p-1">
            {[
              { key: 'campaigns', label: 'Campaigns', icon: <Target className="w-4 h-4" /> },
              { key: 'analytics', label: 'Analytics', icon: <BarChart3 className="w-4 h-4" /> },
              { key: 'calendar', label: 'Calendar', icon: <Calendar className="w-4 h-4" /> }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key as any)}
                className={`px-6 py-3 rounded-md transition-all flex items-center ${
                  activeTab === tab.key
                    ? 'bg-white/20 text-white'
                    : 'text-white/70 hover:text-white'
                }`}
              >
                {tab.icon}
                <span className="ml-2">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        {activeTab === 'campaigns' && (
          <div>
            {/* Campaign Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Total Campaigns</p>
                    <p className="text-3xl font-bold text-white">{campaigns.length}</p>
                  </div>
                  <Target className="w-8 h-8 text-[#0db2e9]" />
                </div>
              </div>
              
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Active</p>
                    <p className="text-3xl font-bold text-white">
                      {campaigns.filter(c => c.status === 'active').length}
                    </p>
                  </div>
                  <Play className="w-8 h-8 text-green-500" />
                </div>
              </div>
              
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Total Reach</p>
                    <p className="text-3xl font-bold text-white">
                      {campaigns.reduce((sum, c) => sum + c.performance.reach, 0).toLocaleString()}
                    </p>
                  </div>
                  <Users className="w-8 h-8 text-blue-500" />
                </div>
              </div>
              
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/70 text-sm">Total Spent</p>
                    <p className="text-3xl font-bold text-white">
                      ${campaigns.reduce((sum, c) => sum + (c.budget || 0), 0).toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="w-8 h-8 text-yellow-500" />
                </div>
              </div>
            </div>

            {/* Campaigns List */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden">
              <div className="p-6 border-b border-white/10">
                <h2 className="text-2xl font-bold text-white">All Campaigns</h2>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-white/5">
                    <tr>
                      <th className="text-left p-4 text-white/80 font-semibold">Campaign</th>
                      <th className="text-left p-4 text-white/80 font-semibold">Status</th>
                      <th className="text-left p-4 text-white/80 font-semibold">Platforms</th>
                      <th className="text-left p-4 text-white/80 font-semibold">Performance</th>
                      <th className="text-left p-4 text-white/80 font-semibold">Budget</th>
                      <th className="text-left p-4 text-white/80 font-semibold">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {campaigns.map((campaign, index) => (
                      <motion.tr
                        key={campaign.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="border-b border-white/10 hover:bg-white/5"
                      >
                        <td className="p-4">
                          <div>
                            <p className="text-white font-semibold">{campaign.name}</p>
                            <p className="text-white/60 text-sm capitalize">{campaign.type}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center">
                            {getStatusIcon(campaign.status)}
                            <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(campaign.status)}`}>
                              {campaign.status}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex flex-wrap gap-1">
                            {campaign.platforms.map((platform) => (
                              <span key={platform} className="bg-[#0db2e9]/20 text-[#0db2e9] px-2 py-1 rounded text-xs">
                                {platform}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="text-sm">
                            <div className="text-white">Reach: {campaign.performance.reach.toLocaleString()}</div>
                            <div className="text-white/60">CTR: {campaign.performance.ctr.toFixed(2)}%</div>
                          </div>
                        </td>
                        <td className="p-4 text-white">
                          ${campaign.budget?.toLocaleString() || 'N/A'}
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <button
                              onClick={() => setSelectedCampaign(campaign)}
                              className="bg-white/10 hover:bg-white/20 text-white px-3 py-1 rounded text-sm flex items-center"
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </button>
                            <button
                              onClick={() => toggleCampaign(campaign)}
                              className={`px-3 py-1 rounded text-sm flex items-center ${
                                campaign.status === 'active'
                                  ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                                  : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                              }`}
                            >
                              {campaign.status === 'active' ? (
                                <>
                                  <Pause className="w-4 h-4 mr-1" />
                                  Pause
                                </>
                              ) : (
                                <>
                                  <Play className="w-4 h-4 mr-1" />
                                  Start
                                </>
                              )}
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-8">
            {/* Analytics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Total Impressions</h3>
                <p className="text-3xl font-bold text-[#0db2e9]">
                  {analytics.reduce((sum, a) => sum + (a.metrics.impressions || 0), 0).toLocaleString()}
                </p>
              </div>
              
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Average CTR</h3>
                <p className="text-3xl font-bold text-green-400">
                  {analytics.length > 0 
                    ? (analytics.reduce((sum, a) => sum + (a.metrics.ctr || 0), 0) / analytics.length).toFixed(2)
                    : '0.00'
                  }%
                </p>
              </div>
              
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Total ROI</h3>
                <p className="text-3xl font-bold text-yellow-400">
                  {analytics.reduce((sum, a) => sum + (a.metrics.roi || 0), 0).toFixed(0)}%
                </p>
              </div>
            </div>

            {/* AI Recommendations */}
            {recommendations.length > 0 && (
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
                  <TrendingUp className="w-6 h-6 mr-3 text-[#0db2e9]" />
                  AI Recommendations
                </h3>
                <div className="space-y-4">
                  {recommendations.map((rec, index) => (
                    <div key={index} className="bg-white/10 p-4 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="text-lg font-semibold text-white">{rec.title}</h4>
                        <div className="flex gap-2">
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            rec.impact === 'high' ? 'bg-red-500/20 text-red-400' :
                            rec.impact === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-green-500/20 text-green-400'
                          }`}>
                            {rec.impact} impact
                          </span>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${
                            rec.effort === 'complex' ? 'bg-red-500/20 text-red-400' :
                            rec.effort === 'moderate' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-green-500/20 text-green-400'
                          }`}>
                            {rec.effort}
                          </span>
                        </div>
                      </div>
                      <p className="text-white/80 mb-3">{rec.description}</p>
                      <p className="text-[#0db2e9] text-sm mb-3">{rec.expectedImprovement}</p>
                      <div>
                        <h5 className="text-white font-medium mb-2">Action Items:</h5>
                        <ul className="space-y-1">
                          {rec.actionItems.map((item, i) => (
                            <li key={i} className="text-white/70 text-sm flex items-start">
                              <span className="text-[#0db2e9] mr-2">•</span>
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'calendar' && (
          <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
            <h3 className="text-2xl font-bold text-white mb-6">Campaign Calendar</h3>
            <div className="grid grid-cols-7 gap-4">
              {/* Calendar implementation would go here */}
              <div className="col-span-7 text-center py-12">
                <Calendar className="w-16 h-16 text-white/40 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Calendar View</h3>
                <p className="text-white/70">Campaign calendar coming soon</p>
              </div>
            </div>
          </div>
        )}

        {/* Create Campaign Modal */}
        {isCreating && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-white/10">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold text-white">Create New Campaign</h3>
                  <button
                    onClick={() => setIsCreating(false)}
                    className="text-white/60 hover:text-white text-2xl p-2"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6 space-y-6">
                <div>
                  <label className="block text-white text-sm font-medium mb-2">Campaign Name</label>
                  <input
                    type="text"
                    value={newCampaign.name}
                    onChange={(e) => setNewCampaign(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Enter campaign name..."
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-white text-sm font-medium mb-2">Campaign Type</label>
                    <select
                      value={newCampaign.type}
                      onChange={(e) => setNewCampaign(prev => ({ ...prev, type: e.target.value as Campaign['type'] }))}
                      className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    >
                      <option value="post" className="bg-gray-800">Social Post</option>
                      <option value="ad" className="bg-gray-800">Advertisement</option>
                      <option value="email" className="bg-gray-800">Email Campaign</option>
                      <option value="story" className="bg-gray-800">Story Campaign</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-white text-sm font-medium mb-2">Budget ($)</label>
                    <input
                      type="number"
                      value={newCampaign.budget}
                      onChange={(e) => setNewCampaign(prev => ({ ...prev, budget: parseInt(e.target.value) }))}
                      min="0"
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white text-sm font-medium mb-2">Platforms</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {platforms.map((platform) => (
                      <button
                        key={platform}
                        onClick={() => {
                          setNewCampaign(prev => ({
                            ...prev,
                            platforms: prev.platforms.includes(platform)
                              ? prev.platforms.filter(p => p !== platform)
                              : [...prev.platforms, platform]
                          }));
                        }}
                        className={`p-3 rounded-lg border transition-all ${
                          newCampaign.platforms.includes(platform)
                            ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                            : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                        }`}
                      >
                        {platform}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white text-sm font-medium mb-2">Start Date</label>
                  <input
                    type="date"
                    value={newCampaign.schedule.startDate}
                    onChange={(e) => setNewCampaign(prev => ({
                      ...prev,
                      schedule: { ...prev.schedule, startDate: e.target.value }
                    }))}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => setIsCreating(false)}
                    className="flex-1 bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={createCampaign}
                    className="flex-1 bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-6 py-3 rounded-lg transition-all font-medium"
                  >
                    Create Campaign
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {/* Campaign Detail Modal */}
        {selectedCampaign && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-white/10">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold text-white">{selectedCampaign.name}</h3>
                  <button
                    onClick={() => setSelectedCampaign(null)}
                    className="text-white/60 hover:text-white text-2xl p-2"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div className="bg-white/5 p-4 rounded-lg">
                    <h4 className="text-lg font-semibold text-white mb-3">Campaign Details</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/70">Type:</span>
                        <span className="text-white capitalize">{selectedCampaign.type}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Status:</span>
                        <span className={`px-2 py-1 rounded text-xs ${getStatusColor(selectedCampaign.status)}`}>
                          {selectedCampaign.status}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Budget:</span>
                        <span className="text-white">${selectedCampaign.budget?.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Created:</span>
                        <span className="text-white">{new Date(selectedCampaign.createdAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 p-4 rounded-lg">
                    <h4 className="text-lg font-semibold text-white mb-3">Performance</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/70">Reach:</span>
                        <span className="text-white">{selectedCampaign.performance.reach.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Impressions:</span>
                        <span className="text-white">{selectedCampaign.performance.impressions.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">Clicks:</span>
                        <span className="text-white">{selectedCampaign.performance.clicks.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">CTR:</span>
                        <span className="text-white">{selectedCampaign.performance.ctr.toFixed(2)}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/70">ROI:</span>
                        <span className="text-white">{selectedCampaign.performance.roi.toFixed(0)}%</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 p-4 rounded-lg mb-6">
                  <h4 className="text-lg font-semibold text-white mb-3">Platforms</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedCampaign.platforms.map((platform) => (
                      <span key={platform} className="bg-[#0db2e9]/20 text-[#0db2e9] px-3 py-1 rounded-full text-sm">
                        {platform}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => toggleCampaign(selectedCampaign)}
                    className={`px-6 py-3 rounded-lg transition-all flex items-center ${
                      selectedCampaign.status === 'active'
                        ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                        : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                    }`}
                  >
                    {selectedCampaign.status === 'active' ? (
                      <>
                        <Pause className="w-5 h-5 mr-2" />
                        Pause Campaign
                      </>
                    ) : (
                      <>
                        <Play className="w-5 h-5 mr-2" />
                        Start Campaign
                      </>
                    )}
                  </button>
                  <button className="bg-white/10 hover:bg-white/20 text-white px-6 py-3 rounded-lg transition-all flex items-center">
                    <Edit className="w-5 h-5 mr-2" />
                    Edit Campaign
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CampaignManager;