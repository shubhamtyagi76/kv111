import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Image, Video, FileText, Mic, Palette, Download, Play, 
  Settings, Wand2, Upload, Eye, Share2 
} from 'lucide-react';
import { MediaCreationInput, GeneratedContent, VoiceoverOptions, BrandKit } from '../types/marketing';
import { aiService } from '../services/aiService';
import toast from 'react-hot-toast';

interface MediaCreationStudioProps {
  onBack: () => void;
  onNavigateToCampaigns?: () => void;
}

const MediaCreationStudio: React.FC<MediaCreationStudioProps> = ({ onBack, onNavigateToCampaigns }) => {
  const [activeTab, setActiveTab] = useState<'create' | 'library'>('create');
  const [contentType, setContentType] = useState<'post' | 'reel' | 'blog' | 'ad' | 'story' | 'video'>('post');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState<GeneratedContent[]>([]);
  const [selectedContent, setSelectedContent] = useState<GeneratedContent | null>(null);
  
  const [formData, setFormData] = useState<MediaCreationInput>({
    type: 'post',
    topic: '',
    platform: 'Instagram',
    tone: 'professional',
    cta: '',
    branding: {
      primaryColor: '#0db2e9',
      secondaryColor: '#b2fefa',
      fonts: ['Poppins'],
      style: 'modern',
      voiceGuidelines: 'Professional, friendly, and informative'
    },
    dimensions: '1080x1080'
  });

  const [voiceoverOptions, setVoiceoverOptions] = useState<VoiceoverOptions>({
    gender: 'female',
    language: 'en-US',
    emotion: 'neutral',
    speed: 1.0,
    pitch: 1.0,
    effects: []
  });

  const contentTypes = [
    { value: 'post', label: 'Social Post', icon: <Image className="w-5 h-5" />, desc: 'Instagram/Facebook posts' },
    { value: 'story', label: 'Story', icon: <Image className="w-5 h-5" />, desc: 'Instagram/Facebook stories' },
    { value: 'reel', label: 'Reel/Video', icon: <Video className="w-5 h-5" />, desc: 'Short-form videos' },
    { value: 'blog', label: 'Blog Post', icon: <FileText className="w-5 h-5" />, desc: 'Long-form content' },
    { value: 'ad', label: 'Advertisement', icon: <Wand2 className="w-5 h-5" />, desc: 'Paid ad content' },
    { value: 'video', label: 'Video', icon: <Video className="w-5 h-5" />, desc: 'Long-form videos' }
  ];

  const platforms = ['Instagram', 'Facebook', 'LinkedIn', 'YouTube', 'TikTok', 'Twitter', 'Pinterest'];
  const tones = ['professional', 'casual', 'humorous', 'inspirational', 'educational'];
  const styles = ['modern', 'classic', 'minimalist', 'bold', 'playful'];

  const handleInputChange = (field: keyof MediaCreationInput, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleBrandingChange = (field: keyof BrandKit, value: any) => {
    setFormData(prev => ({
      ...prev,
      branding: { ...prev.branding, [field]: value }
    }));
  };

  const generateContent = async () => {
    if (!formData.topic.trim()) {
      toast.error('Please enter a topic for your content');
      return;
    }

    setIsGenerating(true);
    try {
      const content: GeneratedContent = {
        id: Date.now().toString(),
        type: formData.type,
        title: `${formData.type} - ${formData.topic}`,
        content: '',
        status: 'generating',
        platform: formData.platform,
        format: getFormatForType(formData.type),
        createdAt: new Date().toISOString(),
        metadata: {
          prompt: formData.topic,
          aiModel: 'gpt-4',
          processingTime: 0
        }
      };

      setGeneratedContent(prev => [content, ...prev]);

      const startTime = Date.now();

      // Generate text content
      const textContent = await aiService.generateTextContent(formData);
      content.content = textContent;

      // Generate visual content if needed
      if (['post', 'story', 'ad'].includes(formData.type)) {
        const imagePrompt = `Create a ${formData.branding.style} style image for ${formData.platform} about ${formData.topic}. Brand colors: ${formData.branding.primaryColor} and ${formData.branding.secondaryColor}`;
        content.mediaUrl = await aiService.generateImage(imagePrompt, formData.dimensions);
        content.thumbnailUrl = content.mediaUrl;
      }

      // Generate video if needed
      if (['reel', 'video'].includes(formData.type)) {
        content.mediaUrl = await aiService.generateVideo(textContent, formData.duration || 30, formData.branding.style);
        content.duration = formData.duration || 30;
      }

      // Generate voiceover if needed
      if (['reel', 'video'].includes(formData.type) && textContent) {
        // Extract script from content for voiceover
        const script = extractScriptFromContent(textContent);
        if (script) {
          const audioUrl = await aiService.generateVoiceover(script, voiceoverOptions);
          content.metadata = { ...content.metadata, audioUrl };
        }
      }

      content.status = 'ready';
      content.metadata.processingTime = Date.now() - startTime;

      setGeneratedContent(prev => 
        prev.map(c => c.id === content.id ? content : c)
      );

      toast.success('Content generated successfully!');
    } catch (error) {
      console.error('Content generation error:', error);
      toast.error('Failed to generate content. Please try again.');
      
      setGeneratedContent(prev => 
        prev.map(c => c.id === Date.now().toString() ? { ...c, status: 'failed' } : c)
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const getFormatForType = (type: string): string => {
    switch (type) {
      case 'post':
      case 'story':
      case 'ad':
        return 'image/jpeg';
      case 'reel':
      case 'video':
        return 'video/mp4';
      case 'blog':
        return 'text/html';
      default:
        return 'text/plain';
    }
  };

  const extractScriptFromContent = (content: string): string => {
    // Extract script portions from content for voiceover
    const lines = content.split('\n');
    return lines
      .filter(line => !line.startsWith('#') && !line.startsWith('**') && line.trim())
      .join(' ')
      .substring(0, 500); // Limit for voiceover
  };

  const downloadContent = (content: GeneratedContent) => {
    if (content.type === 'blog') {
      const blob = new Blob([content.content], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${content.title}.html`;
      a.click();
      URL.revokeObjectURL(url);
    } else if (content.mediaUrl) {
      const a = document.createElement('a');
      a.href = content.mediaUrl;
      a.download = `${content.title}.${content.format.split('/')[1]}`;
      a.click();
    }
    toast.success('Content downloaded!');
  };

  const shareContent = (content: GeneratedContent) => {
    if (navigator.share) {
      navigator.share({
        title: content.title,
        text: content.content.substring(0, 100) + '...',
        url: content.mediaUrl || window.location.href
      });
    } else {
      navigator.clipboard.writeText(content.content);
      toast.success('Content copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={onBack}
              className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </button>
            {onNavigateToCampaigns && (
              <button
                onClick={onNavigateToCampaigns}
                className="bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black px-4 py-2 rounded-lg transition-all duration-200 flex items-center font-medium"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Campaign Manager
              </button>
            )}
          </div>
          <h1 className="text-4xl font-bold text-[#0db2e9] mb-4">AI Media Creation Studio</h1>
          <p className="text-white/80 text-lg">
            Create professional content with AI - posts, videos, blogs, and more
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white/10 rounded-lg p-1">
            <button
              onClick={() => setActiveTab('create')}
              className={`px-6 py-3 rounded-md transition-all ${
                activeTab === 'create'
                  ? 'bg-white/20 text-white'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              Create Content
            </button>
            <button
              onClick={() => setActiveTab('library')}
              className={`px-6 py-3 rounded-md transition-all ${
                activeTab === 'library'
                  ? 'bg-white/20 text-white'
                  : 'text-white/70 hover:text-white'
              }`}
            >
              Content Library ({generatedContent.length})
            </button>
          </div>
        </div>

        {activeTab === 'create' ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Content Type Selection */}
            <div className="lg:col-span-1">
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6 mb-6">
                <h3 className="text-xl font-bold text-white mb-4">Content Type</h3>
                <div className="space-y-3">
                  {contentTypes.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => {
                        setContentType(type.value as any);
                        handleInputChange('type', type.value);
                      }}
                      className={`w-full p-4 rounded-lg border transition-all text-left ${
                        contentType === type.value
                          ? 'bg-[#0db2e9]/20 border-[#0db2e9] text-[#0db2e9]'
                          : 'bg-white/5 border-white/20 text-white hover:border-white/40'
                      }`}
                    >
                      <div className="flex items-center mb-2">
                        {type.icon}
                        <span className="ml-3 font-semibold">{type.label}</span>
                      </div>
                      <p className="text-sm opacity-70">{type.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Brand Settings */}
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <Palette className="w-5 h-5 mr-2" />
                  Brand Settings
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-white text-sm font-medium mb-2">Style</label>
                    <select
                      value={formData.branding.style}
                      onChange={(e) => handleBrandingChange('style', e.target.value)}
                      className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    >
                      {styles.map(style => (
                        <option key={style} value={style} className="bg-gray-800">
                          {style.charAt(0).toUpperCase() + style.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-white text-sm font-medium mb-2">Primary Color</label>
                      <input
                        type="color"
                        value={formData.branding.primaryColor}
                        onChange={(e) => handleBrandingChange('primaryColor', e.target.value)}
                        className="w-full h-10 bg-white/10 border border-white/20 rounded-lg cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-white text-sm font-medium mb-2">Secondary Color</label>
                      <input
                        type="color"
                        value={formData.branding.secondaryColor}
                        onChange={(e) => handleBrandingChange('secondaryColor', e.target.value)}
                        className="w-full h-10 bg-white/10 border border-white/20 rounded-lg cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Content Creation Form */}
            <div className="lg:col-span-2">
              <div className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 p-6">
                <h3 className="text-xl font-bold text-white mb-6">Create {contentTypes.find(t => t.value === contentType)?.label}</h3>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-white text-sm font-medium mb-2">Platform</label>
                      <select
                        value={formData.platform}
                        onChange={(e) => handleInputChange('platform', e.target.value)}
                        className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                      >
                        {platforms.map(platform => (
                          <option key={platform} value={platform} className="bg-gray-800">
                            {platform}
                          </option>
                        ))}
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-white text-sm font-medium mb-2">Tone</label>
                      <select
                        value={formData.tone}
                        onChange={(e) => handleInputChange('tone', e.target.value)}
                        className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                      >
                        {tones.map(tone => (
                          <option key={tone} value={tone} className="bg-gray-800">
                            {tone.charAt(0).toUpperCase() + tone.slice(1)}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-white text-sm font-medium mb-2">Topic/Subject</label>
                    <textarea
                      value={formData.topic}
                      onChange={(e) => handleInputChange('topic', e.target.value)}
                      placeholder="Describe what you want to create content about..."
                      className="w-full h-32 px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9] resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-white text-sm font-medium mb-2">Call to Action</label>
                    <input
                      type="text"
                      value={formData.cta}
                      onChange={(e) => handleInputChange('cta', e.target.value)}
                      placeholder="e.g., Visit our website, Sign up now, Learn more..."
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                    />
                  </div>

                  {/* Video-specific options */}
                  {['reel', 'video'].includes(contentType) && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">Duration (seconds)</label>
                        <input
                          type="number"
                          value={formData.duration || 30}
                          onChange={(e) => handleInputChange('duration', parseInt(e.target.value))}
                          min="15"
                          max="300"
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-white text-sm font-medium mb-2">Voice Gender</label>
                        <select
                          value={voiceoverOptions.gender}
                          onChange={(e) => setVoiceoverOptions(prev => ({ ...prev, gender: e.target.value as 'male' | 'female' }))}
                          className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                        >
                          <option value="female" className="bg-gray-800">Female</option>
                          <option value="male" className="bg-gray-800">Male</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Image-specific options */}
                  {['post', 'story', 'ad'].includes(contentType) && (
                    <div>
                      <label className="block text-white text-sm font-medium mb-2">Dimensions</label>
                      <select
                        value={formData.dimensions}
                        onChange={(e) => handleInputChange('dimensions', e.target.value)}
                        className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-[#0db2e9]"
                      >
                        <option value="1080x1080" className="bg-gray-800">Square (1080x1080)</option>
                        <option value="1080x1350" className="bg-gray-800">Portrait (1080x1350)</option>
                        <option value="1920x1080" className="bg-gray-800">Landscape (1920x1080)</option>
                        <option value="1080x1920" className="bg-gray-800">Story (1080x1920)</option>
                      </select>
                    </div>
                  )}

                  <button
                    onClick={generateContent}
                    disabled={isGenerating || !formData.topic.trim()}
                    className={`w-full py-4 rounded-lg transition-all duration-200 flex items-center justify-center ${
                      isGenerating || !formData.topic.trim()
                        ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-[#0db2e9] to-[#b2fefa] hover:from-[#0aa3d1] hover:to-[#9ef5f1] text-black font-medium'
                    }`}
                  >
                    {isGenerating ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-black mr-3"></div>
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-5 h-5 mr-3" />
                        Generate Content
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Content Library */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {generatedContent.map((content) => (
              <motion.div
                key={content.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 overflow-hidden"
              >
                {/* Content Preview */}
                <div className="aspect-video bg-white/10 relative">
                  {content.mediaUrl ? (
                    content.format.startsWith('video/') ? (
                      <video
                        src={content.mediaUrl}
                        className="w-full h-full object-cover"
                        controls={false}
                        muted
                      />
                    ) : (
                      <img
                        src={content.mediaUrl}
                        alt={content.title}
                        className="w-full h-full object-cover"
                      />
                    )
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <FileText className="w-12 h-12 text-white/40" />
                    </div>
                  )}
                  
                  {/* Status Overlay */}
                  <div className="absolute top-2 right-2">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      content.status === 'ready' ? 'bg-green-500/20 text-green-400' :
                      content.status === 'generating' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {content.status}
                    </span>
                  </div>
                </div>

                {/* Content Info */}
                <div className="p-4">
                  <h3 className="text-white font-semibold mb-2 truncate">{content.title}</h3>
                  <p className="text-white/70 text-sm mb-3 line-clamp-2">
                    {content.content.substring(0, 100)}...
                  </p>
                  
                  <div className="flex items-center justify-between text-xs text-white/60 mb-4">
                    <span>{content.platform}</span>
                    <span>{new Date(content.createdAt).toLocaleDateString()}</span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedContent(content)}
                      className="flex-1 bg-white/10 hover:bg-white/20 text-white px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </button>
                    <button
                      onClick={() => downloadContent(content)}
                      className="bg-[#0db2e9]/20 hover:bg-[#0db2e9]/30 text-[#0db2e9] px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => shareContent(content)}
                      className="bg-green-500/20 hover:bg-green-500/30 text-green-400 px-3 py-2 rounded-lg transition-all text-sm flex items-center justify-center"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}

            {generatedContent.length === 0 && (
              <div className="col-span-full text-center py-12">
                <FileText className="w-16 h-16 text-white/40 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">No content yet</h3>
                <p className="text-white/70">Create your first piece of content to get started</p>
              </div>
            )}
          </div>
        )}

        {/* Content Preview Modal */}
        {selectedContent && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="p-6 border-b border-white/10">
                <div className="flex justify-between items-center">
                  <h3 className="text-2xl font-bold text-white">{selectedContent.title}</h3>
                  <button
                    onClick={() => setSelectedContent(null)}
                    className="text-white/60 hover:text-white text-2xl p-2"
                  >
                    ×
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                {selectedContent.mediaUrl && (
                  <div className="mb-6">
                    {selectedContent.format.startsWith('video/') ? (
                      <video
                        src={selectedContent.mediaUrl}
                        className="w-full max-h-96 object-contain rounded-lg"
                        controls
                      />
                    ) : (
                      <img
                        src={selectedContent.mediaUrl}
                        alt={selectedContent.title}
                        className="w-full max-h-96 object-contain rounded-lg"
                      />
                    )}
                  </div>
                )}
                
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="text-lg font-semibold text-white mb-3">Content</h4>
                  <div className="text-white/80 whitespace-pre-wrap">
                    {selectedContent.content}
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <button
                    onClick={() => downloadContent(selectedContent)}
                    className="bg-[#0db2e9] hover:bg-[#0aa3d1] text-white px-6 py-3 rounded-lg transition-all flex items-center"
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download
                  </button>
                  <button
                    onClick={() => shareContent(selectedContent)}
                    className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg transition-all flex items-center"
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    Share
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaCreationStudio;